package com.example.data.firebase

import com.example.base.FirestoreEmulatorTestBase
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.runBlocking
import kotlinx.coroutines.withTimeout
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertTrue
import org.junit.Test

class ReadyAiFirestoreRepositoryRuleTest : FirestoreEmulatorTestBase() {

    @Test
    fun saveUserProfile_authenticatedUser_success() = runBlocking {
        val uid = signInTestUser("test_user_readyai@example.com")
        val repo = ReadyAiFirestoreRepository(firestore, auth)

        val profile = FirestoreUserProfile(
            userId = uid,
            email = "test_user_readyai@example.com",
            displayName = "Juan Dela Cruz",
            phone = "+639171234567",
            bloodType = "O+",
            regionCode = "NCR"
        )

        val result = withTimeout(5000L) {
            repo.saveUserProfile(profile)
        }
        assertTrue("Save user profile should succeed", result.isSuccess)

        val loadedProfile = withTimeout(5000L) {
            repo.observeUserProfile(uid).first()
        }
        assertNotNull(loadedProfile)
        assertEquals("Juan Dela Cruz", loadedProfile?.displayName)
        assertEquals("NCR", loadedProfile?.regionCode)
    }

    @Test
    fun saveChecklistItem_andObserve_success() = runBlocking {
        val uid = signInTestUser("checklist_tester@example.com")
        val repo = ReadyAiFirestoreRepository(firestore, auth)

        val item = FirestoreChecklistItem(
            id = "test_flash_1",
            userId = uid,
            title = "Water Jugs 5 Gallons",
            category = "Water",
            description = "At least 3 days supply",
            isChecked = false
        )

        val result = withTimeout(5000L) {
            repo.saveChecklistItem(item)
        }
        assertTrue("Save checklist item should succeed", result.isSuccess)

        val items = withTimeout(5000L) {
            repo.observeChecklistItems(uid).first()
        }
        assertTrue("Items list should contain test item", items.any { it.title == "Water Jugs 5 Gallons" })
    }

    @Test
    fun submitFeedback_authenticatedUser_success() = runBlocking {
        val uid = signInTestUser("feedback_tester@example.com")
        val repo = ReadyAiFirestoreRepository(firestore, auth)

        val feedback = FirestoreFeedback(
            id = "fb_test_123",
            userId = uid,
            userName = "Maria Santos",
            category = "Baha",
            message = "Flood subsided in area.",
            rating = 5L
        )

        val result = withTimeout(5000L) {
            repo.submitFeedback(feedback)
        }
        if (result.isFailure) {
            val ex = result.exceptionOrNull()
            System.err.println("TEST FAILURE EXCEPTION: $ex")
            ex?.printStackTrace()
        }
        assertTrue("Feedback submission should succeed: ${result.exceptionOrNull()}", result.isSuccess)
    }

    @Test
    fun unauthenticatedAccess_failsFast() = runBlocking {
        auth.signOut()
        val repo = ReadyAiFirestoreRepository(firestore, auth)

        val profile = FirestoreUserProfile(
            userId = "anon_user",
            email = "anon@example.com",
            displayName = "Anon"
        )

        var failed = false
        try {
            repo.saveUserProfile(profile)
        } catch (e: IllegalStateException) {
            failed = true
        }
        assertTrue("Unauthenticated access must fail fast", failed)
    }
}
