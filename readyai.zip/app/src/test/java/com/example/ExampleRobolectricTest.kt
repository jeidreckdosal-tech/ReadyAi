package com.example

import android.content.Context
import androidx.test.core.app.ApplicationProvider
import com.example.data.DisasterRepository
import com.example.data.local.AppDatabase
import com.example.data.local.ReadyAiLocalRepository
import com.example.data.local.UserEntity
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.runBlocking
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertTrue
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [34])
class ExampleRobolectricTest {

  @Test
  fun `read string from context`() {
    val context = ApplicationProvider.getApplicationContext<Context>()
    val appName = context.getString(R.string.app_name)
    assertEquals("ReadyAI", appName)
  }

  @Test
  fun `verify emergency categories count and content`() {
    val categories = DisasterRepository.categories
    assertEquals(8, categories.size)
    val ids = categories.map { it.id }
    assertTrue(ids.contains("typhoon"))
    assertTrue(ids.contains("flood"))
    assertTrue(ids.contains("earthquake"))
    assertTrue(ids.contains("fire"))
    assertTrue(ids.contains("landslide"))
    assertTrue(ids.contains("tsunami"))
    assertTrue(ids.contains("volcano"))
    assertTrue(ids.contains("power_outage"))
  }

  @Test
  fun `verify philippine regions count`() {
    val regions = DisasterRepository.philippineRegions
    assertEquals(17, regions.size)
    val ncr = regions.firstOrNull { it.code == "NCR" }
    assertNotNull(ncr)
    assertTrue(ncr?.rdrrmcHotline?.isNotBlank() == true)
  }

  @Test
  fun `verify national emergency contacts include 911`() {
    val contacts = DisasterRepository.nationalContacts
    val hotline911 = contacts.firstOrNull { it.primaryNumber == "911" }
    assertNotNull(hotline911)
  }

  @Test
  fun `verify checklist items contains 11 essential items`() {
    val items = DisasterRepository.defaultChecklist
    assertEquals(11, items.size)
  }

  @Test
  fun `verify database repository and user authentication`() = runBlocking {
    val context = ApplicationProvider.getApplicationContext<Context>()
    val inMemoryDb = AppDatabase.createInMemoryDatabase(context)
    val repository = ReadyAiLocalRepository(inMemoryDb, autoSeed = false)
    repository.seedInitialDataIfEmpty()

    // Register a new test user
    val registerResult = repository.registerUser("Maria Santos", "maria@readyai.ph", "pass123", "USER")
    assertTrue(registerResult.isSuccess)
    val user = registerResult.getOrNull()
    assertNotNull(user)
    assertEquals("USER", user?.role)

    // Login test
    val loginResult = repository.loginUser("maria@readyai.ph", "pass123")
    assertTrue(loginResult.isSuccess)
    assertEquals("Maria Santos", loginResult.getOrNull()?.name)

    // Verify guides flow returns non-empty list
    val guides = repository.getGuidesFlow().first()
    assertTrue(guides.isNotEmpty())

    // Verify Disaster Alerts seeded and unread count
    val alerts = repository.getAllAlertsFlow().first()
    assertTrue(alerts.isNotEmpty())
    val unreadCount = repository.getUnreadAlertCountFlow().first()
    assertTrue(unreadCount > 0)

    // Mark first alert as read
    val firstAlert = alerts.first()
    repository.markAlertAsRead(firstAlert.id)
    val newUnread = repository.getUnreadAlertCountFlow().first()
    assertEquals(unreadCount - 1, newUnread)

    inMemoryDb.close()
  }
}
