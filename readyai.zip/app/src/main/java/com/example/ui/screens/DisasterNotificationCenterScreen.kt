package com.example.ui.screens

import android.content.Context
import android.content.Intent
import android.net.Uri
import android.widget.Toast
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.animateContentSize
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.OpenInNew
import androidx.compose.material.icons.automirrored.filled.VolumeUp
import androidx.compose.material.icons.filled.Call
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Clear
import androidx.compose.material.icons.filled.Cyclone
import androidx.compose.material.icons.filled.FilterList
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.KeyboardArrowDown
import androidx.compose.material.icons.filled.KeyboardArrowUp
import androidx.compose.material.icons.filled.Landscape
import androidx.compose.material.icons.filled.LocalFireDepartment
import androidx.compose.material.icons.filled.LocationOn
import androidx.compose.material.icons.filled.MyLocation
import androidx.compose.material.icons.filled.Notifications
import androidx.compose.material.icons.filled.NotificationsActive
import androidx.compose.material.icons.filled.NotificationsOff
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Shield
import androidx.compose.material.icons.filled.Tsunami
import androidx.compose.material.icons.filled.Volcano
import androidx.compose.material.icons.filled.VolumeUp
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material.icons.filled.Water
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.local.DisasterAlertEntity
import com.example.data.model.DisasterType
import com.example.ui.components.LargeCall911Button
import com.example.ui.theme.AlertAmber
import com.example.ui.theme.DisasterNavy
import com.example.ui.theme.EmergencyRed
import com.example.ui.theme.OceanBlue
import com.example.ui.theme.SafeGreen
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@Composable
fun DisasterNotificationCenterScreen(
    alerts: List<DisasterAlertEntity>,
    unreadCount: Int,
    selectedTypeFilter: String,
    selectedSeverityFilter: String,
    selectedLocationFilter: String,
    onlyNearby: Boolean,
    searchQuery: String,
    userCityName: String,
    userLatitude: Double,
    userLongitude: Double,
    isSoundAlertsEnabled: Boolean,
    selectedAlertForDetail: DisasterAlertEntity?,
    onSetTypeFilter: (String) -> Unit,
    onSetSeverityFilter: (String) -> Unit,
    onSetLocationFilter: (String) -> Unit,
    onSetOnlyNearby: (Boolean) -> Unit,
    onSetSearchQuery: (String) -> Unit,
    onSelectAlertForDetail: (DisasterAlertEntity?) -> Unit,
    onMarkAsRead: (String) -> Unit,
    onMarkAllAsRead: () -> Unit,
    onSetSoundAlertsEnabled: (Boolean) -> Unit,
    onPreviewSound: () -> Unit,
    onUpdateLocation: (Double, Double, String) -> Unit,
    onCall911: () -> Unit
) {
    val context = LocalContext.current
    var showLocationDialog by remember { mutableStateOf(false) }
    var showSourceNoticeDialog by remember { mutableStateOf<String?>(null) }

    // Philippine Major Cities coordinate lookup for location switching
    val phCities = listOf(
        Triple("Quezon City, NCR", 14.6349, 121.0028),
        Triple("Manila, NCR", 14.5995, 120.9842),
        Triple("Pasig City, NCR", 14.5764, 121.0851),
        Triple("Makati City, NCR", 14.5547, 121.0244),
        Triple("Baguio City, CAR", 16.4023, 120.5960),
        Triple("Tuguegarao, Region II", 17.6132, 121.7270),
        Triple("San Fernando, Region III", 15.0286, 120.6896),
        Triple("Batangas City, Region IV-A", 13.7565, 121.0583),
        Triple("Legazpi City, Region V", 13.1391, 123.7438),
        Triple("Cebu City, Region VII", 10.3157, 123.8854),
        Triple("Davao City, Region XI", 7.1907, 125.4553)
    )

    // Filter computation
    val filteredAlerts = alerts.filter { alert ->
        val matchesType = when (selectedTypeFilter.lowercase()) {
            "all" -> true
            "bagyo", "typhoon" -> alert.disasterType.equals("Typhoon", true) || alert.disasterType.equals("Bagyo", true)
            "lindol", "earthquake" -> alert.disasterType.equals("Earthquake", true) || alert.disasterType.equals("Lindol", true)
            "sunog", "fire" -> alert.disasterType.equals("Fire", true) || alert.disasterType.equals("Sunog", true)
            "baha", "flood" -> alert.disasterType.equals("Flood", true) || alert.disasterType.equals("Baha", true)
            "volcano", "bulkan" -> alert.disasterType.equals("Volcano", true) || alert.disasterType.equals("Bulkan", true)
            "landslide" -> alert.disasterType.equals("Landslide", true)
            else -> alert.disasterType.equals(selectedTypeFilter, ignoreCase = true)
        }

        val matchesSeverity = when (selectedSeverityFilter) {
            "ALL" -> true
            "ARCHIVED" -> alert.isArchived || alert.severity == "EXPIRED"
            else -> !alert.isArchived && alert.severity.equals(selectedSeverityFilter, ignoreCase = true)
        }

        val matchesLocation = when (selectedLocationFilter) {
            "ALL" -> true
            else -> alert.affectedRegion.equals(selectedLocationFilter, ignoreCase = true) ||
                    alert.locationProvince.contains(selectedLocationFilter, ignoreCase = true) ||
                    alert.locationCity.contains(selectedLocationFilter, ignoreCase = true)
        }

        val matchesSearch = if (searchQuery.isBlank()) true else {
            alert.title.contains(searchQuery, ignoreCase = true) ||
                    alert.shortDescription.contains(searchQuery, ignoreCase = true) ||
                    alert.locationCity.contains(searchQuery, ignoreCase = true) ||
                    alert.locationBarangay.contains(searchQuery, ignoreCase = true) ||
                    alert.sourceName.contains(searchQuery, ignoreCase = true)
        }

        val distanceKm = calculateHaversine(userLatitude, userLongitude, alert.latitude, alert.longitude)
        val matchesNearby = if (!onlyNearby) true else {
            distanceKm <= 50.0 || alert.locationCity.isNotBlank() && userCityName.contains(alert.locationCity, ignoreCase = true)
        }

        matchesType && matchesSeverity && matchesLocation && matchesSearch && matchesNearby
    }

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .testTag("disaster_notification_center_screen"),
        contentPadding = PaddingValues(horizontal = 16.dp, vertical = 14.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        // CALL 911 button at top
        item {
            LargeCall911Button(
                onClick = onCall911,
                label = "CALL 911"
            )
        }

        // Section A Header Card: Notification Center & Unread Count
        item {
            Card(
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = DisasterNavy),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(16.dp)
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Box(
                                modifier = Modifier
                                    .size(42.dp)
                                    .background(EmergencyRed, CircleShape),
                                contentAlignment = Alignment.Center
                            ) {
                                Icon(
                                    imageVector = Icons.Default.NotificationsActive,
                                    contentDescription = null,
                                    tint = Color.White,
                                    modifier = Modifier.size(24.dp)
                                )
                            }
                            Spacer(modifier = Modifier.width(12.dp))
                            Column {
                                Text(
                                    text = "Disaster Notification Center",
                                    fontSize = 17.sp,
                                    fontWeight = FontWeight.Black,
                                    color = Color.White
                                )
                                Text(
                                    text = "Real-Time Philippine Incident Alerts",
                                    fontSize = 12.sp,
                                    color = Color.White.copy(alpha = 0.8f)
                                )
                            }
                        }

                        if (unreadCount > 0) {
                            Surface(
                                color = EmergencyRed,
                                shape = RoundedCornerShape(12.dp)
                            ) {
                                Text(
                                    text = "$unreadCount UNREAD",
                                    fontSize = 11.sp,
                                    fontWeight = FontWeight.Black,
                                    color = Color.White,
                                    modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                                )
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(14.dp))
                    HorizontalDivider(color = Color.White.copy(alpha = 0.15f))
                    Spacer(modifier = Modifier.height(12.dp))

                    // Sound notification toggle and quick actions
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(
                                imageVector = if (isSoundAlertsEnabled) Icons.AutoMirrored.Filled.VolumeUp else Icons.Default.NotificationsOff,
                                contentDescription = null,
                                tint = if (isSoundAlertsEnabled) SafeGreen else Color.White.copy(alpha = 0.6f),
                                modifier = Modifier.size(18.dp)
                            )
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(
                                text = if (isSoundAlertsEnabled) "Alert Sounds ON" else "Alert Sounds OFF",
                                fontSize = 12.sp,
                                fontWeight = FontWeight.SemiBold,
                                color = Color.White
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                            Switch(
                                checked = isSoundAlertsEnabled,
                                onCheckedChange = onSetSoundAlertsEnabled,
                                colors = SwitchDefaults.colors(
                                    checkedThumbColor = Color.White,
                                    checkedTrackColor = SafeGreen,
                                    uncheckedThumbColor = Color.LightGray,
                                    uncheckedTrackColor = Color.DarkGray
                                ),
                                modifier = Modifier.testTag("sound_alerts_switch")
                            )
                        }

                        Row {
                            TextButton(
                                onClick = onPreviewSound,
                                modifier = Modifier.testTag("test_sound_button")
                            ) {
                                Text(
                                    text = "Test Sound",
                                    color = AlertAmber,
                                    fontSize = 12.sp,
                                    fontWeight = FontWeight.Bold
                                )
                            }

                            if (unreadCount > 0) {
                                TextButton(
                                    onClick = onMarkAllAsRead,
                                    modifier = Modifier.testTag("mark_all_read_button")
                                ) {
                                    Text(
                                        text = "Read All",
                                        color = Color.White,
                                        fontSize = 12.sp,
                                        fontWeight = FontWeight.Bold
                                    )
                                }
                            }
                        }
                    }
                }
            }
        }

        // Section C: User Location & Nearby Detection Banner
        item {
            Card(
                shape = RoundedCornerShape(14.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                border = androidx.compose.foundation.BorderStroke(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.2f)),
                modifier = Modifier.fillMaxWidth()
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(12.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        modifier = Modifier.weight(1f)
                    ) {
                        Box(
                            modifier = Modifier
                                .size(34.dp)
                                .background(OceanBlue.copy(alpha = 0.15f), CircleShape),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(
                                imageVector = Icons.Default.MyLocation,
                                contentDescription = null,
                                tint = OceanBlue,
                                modifier = Modifier.size(18.dp)
                            )
                        }
                        Spacer(modifier = Modifier.width(10.dp))
                        Column {
                            Text(
                                text = "Your Monitored Location",
                                fontSize = 11.sp,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                            Text(
                                text = userCityName,
                                fontSize = 14.sp,
                                fontWeight = FontWeight.Bold,
                                color = MaterialTheme.colorScheme.onSurface
                            )
                        }
                    }

                    OutlinedButton(
                        onClick = { showLocationDialog = true },
                        modifier = Modifier.testTag("change_location_button"),
                        shape = RoundedCornerShape(8.dp),
                        contentPadding = PaddingValues(horizontal = 10.dp, vertical = 6.dp)
                    ) {
                        Text("Change", fontSize = 12.sp)
                    }
                }
            }
        }

        // Section B: Official Data Sources and External Links Hub
        item {
            Text(
                text = "Official Disaster Information Feeds",
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.Bold,
                color = MaterialTheme.colorScheme.onSurface
            )
            Spacer(modifier = Modifier.height(4.dp))
            Text(
                text = "Direct verified portals for Fire, Earthquake, Typhoon, and Flood",
                fontSize = 12.sp,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
            Spacer(modifier = Modifier.height(8.dp))

            // TXT FIRE Button & In-App Notice
            Card(
                shape = RoundedCornerShape(12.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.6f)),
                border = androidx.compose.foundation.BorderStroke(1.dp, EmergencyRed.copy(alpha = 0.35f)),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(12.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(
                                imageVector = Icons.Default.LocalFireDepartment,
                                contentDescription = null,
                                tint = EmergencyRed,
                                modifier = Modifier.size(20.dp)
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(
                                text = "TXT FIRE Philippines (Fire / Sunog)",
                                fontWeight = FontWeight.Bold,
                                fontSize = 13.sp,
                                color = MaterialTheme.colorScheme.onSurface
                            )
                        }

                        Button(
                            onClick = {
                                openWebUrl(context, "https://www.facebook.com/txtfire")
                            },
                            colors = ButtonDefaults.buttonColors(containerColor = EmergencyRed),
                            shape = RoundedCornerShape(8.dp),
                            contentPadding = PaddingValues(horizontal = 10.dp, vertical = 6.dp),
                            modifier = Modifier.testTag("view_txt_fire_button")
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Text("View TXT FIRE Updates", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                                Spacer(modifier = Modifier.width(4.dp))
                                Icon(Icons.AutoMirrored.Filled.OpenInNew, contentDescription = null, modifier = Modifier.size(12.dp))
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(8.dp))
                    Surface(
                        color = EmergencyRed.copy(alpha = 0.08f),
                        shape = RoundedCornerShape(6.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Row(
                            modifier = Modifier.padding(8.dp),
                            verticalAlignment = Alignment.Top
                        ) {
                            Icon(
                                imageVector = Icons.Default.Info,
                                contentDescription = null,
                                tint = EmergencyRed,
                                modifier = Modifier
                                    .size(16.dp)
                                    .padding(top = 1.dp)
                            )
                            Spacer(modifier = Modifier.width(6.dp))
                            Column {
                                Text(
                                    text = "NOTICE: TXT FIRE is a community-driven volunteer fire reporting system. Details and alarms must be officially confirmed by the Bureau of Fire Protection (BFP).",
                                    fontSize = 11.sp,
                                    lineHeight = 15.sp,
                                    color = MaterialTheme.colorScheme.onSurface
                                )
                                Spacer(modifier = Modifier.height(6.dp))
                                OutlinedButton(
                                    onClick = { dialPhone(context, "(02) 8426-0219") },
                                    modifier = Modifier.testTag("call_bfp_quick_button"),
                                    shape = RoundedCornerShape(6.dp),
                                    contentPadding = PaddingValues(horizontal = 8.dp, vertical = 4.dp)
                                ) {
                                    Icon(Icons.Default.Call, contentDescription = null, modifier = Modifier.size(13.dp))
                                    Spacer(modifier = Modifier.width(4.dp))
                                    Text("Call BFP Hotline: (02) 8426-0219", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                                }
                            }
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(8.dp))

            // Other Official Agency Quick Links: PHIVOLCS, PAGASA, MMDA/NOAH
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                // PHIVOLCS Quakes
                OfficialAgencyCard(
                    title = "PHIVOLCS",
                    subtitle = "Earthquake & Volcano",
                    icon = Icons.Default.Landscape,
                    buttonLabel = "View PHIVOLCS Bulletins",
                    color = AlertAmber,
                    testTag = "view_phivolcs_button",
                    modifier = Modifier.weight(1f),
                    onClick = { openWebUrl(context, "https://earthquake.phivolcs.dost.gov.ph/") }
                )

                // PAGASA Weather
                OfficialAgencyCard(
                    title = "PAGASA",
                    subtitle = "Typhoon & Weather",
                    icon = Icons.Default.Cyclone,
                    buttonLabel = "View PAGASA Weather",
                    color = OceanBlue,
                    testTag = "view_pagasa_button",
                    modifier = Modifier.weight(1f),
                    onClick = { openWebUrl(context, "https://bagong.pagasa.dost.gov.ph/") }
                )
            }

            Spacer(modifier = Modifier.height(8.dp))

            // MMDA Flood & Project NOAH
            Card(
                shape = RoundedCornerShape(12.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                border = androidx.compose.foundation.BorderStroke(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.2f)),
                modifier = Modifier.fillMaxWidth()
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(10.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Default.Water, contentDescription = null, tint = OceanBlue, modifier = Modifier.size(18.dp))
                        Spacer(modifier = Modifier.width(8.dp))
                        Column {
                            Text("Flood Monitoring (Baha) — Project NOAH & MMDA", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                            Text("Real-time water levels & flooded street advisories", fontSize = 10.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        }
                    }
                    Button(
                        onClick = { openWebUrl(context, "https://noah.up.edu.ph/") },
                        colors = ButtonDefaults.buttonColors(containerColor = OceanBlue),
                        shape = RoundedCornerShape(6.dp),
                        contentPadding = PaddingValues(horizontal = 8.dp, vertical = 4.dp),
                        modifier = Modifier.testTag("view_flood_monitoring_button")
                    ) {
                        Text("View Flood Monitoring Updates", fontSize = 10.sp, fontWeight = FontWeight.Bold)
                    }
                }
            }
        }

        // Section A: Search and Filter Bar
        item {
            Column(modifier = Modifier.fillMaxWidth()) {
                // Search input
                OutlinedTextField(
                    value = searchQuery,
                    onValueChange = onSetSearchQuery,
                    placeholder = { Text("Search by barangay, city, disaster, or source...", fontSize = 13.sp) },
                    leadingIcon = { Icon(Icons.Default.Search, contentDescription = null, modifier = Modifier.size(18.dp)) },
                    trailingIcon = {
                        if (searchQuery.isNotEmpty()) {
                            IconButton(onClick = { onSetSearchQuery("") }) {
                                Icon(Icons.Default.Clear, contentDescription = "Clear")
                            }
                        }
                    },
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("alerts_search_input"),
                    shape = RoundedCornerShape(12.dp),
                    singleLine = true
                )

                Spacer(modifier = Modifier.height(10.dp))

                // Disaster Type Filters (Horizontal scroll)
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .horizontalScroll(rememberScrollState()),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    val types = listOf(
                        "ALL" to "All Disasters",
                        "Typhoon" to "🌀 Typhoon (Bagyo)",
                        "Earthquake" to "🌋 Earthquake (Lindol)",
                        "Fire" to "🔥 Fire (Sunog)",
                        "Flood" to "🌊 Flood (Baha)",
                        "Volcano" to "🌋 Volcano (Bulkan)",
                        "Landslide" to "⛰️ Landslide"
                    )

                    types.forEach { (typeKey, label) ->
                        val isSelected = when (typeKey.lowercase()) {
                            "all" -> selectedTypeFilter.equals("all", true)
                            "typhoon" -> selectedTypeFilter.equals("typhoon", true) || selectedTypeFilter.equals("bagyo", true)
                            "earthquake" -> selectedTypeFilter.equals("earthquake", true) || selectedTypeFilter.equals("lindol", true)
                            "fire" -> selectedTypeFilter.equals("fire", true) || selectedTypeFilter.equals("sunog", true)
                            "flood" -> selectedTypeFilter.equals("flood", true) || selectedTypeFilter.equals("baha", true)
                            "volcano" -> selectedTypeFilter.equals("volcano", true) || selectedTypeFilter.equals("bulkan", true)
                            "landslide" -> selectedTypeFilter.equals("landslide", true)
                            else -> selectedTypeFilter.equals(typeKey, true)
                        }

                        FilterChip(
                            selected = isSelected,
                            onClick = { onSetTypeFilter(typeKey) },
                            label = { Text(label, fontSize = 12.sp) },
                            modifier = Modifier.testTag("filter_type_${typeKey.lowercase()}"),
                            colors = FilterChipDefaults.filterChipColors(
                                selectedContainerColor = EmergencyRed,
                                selectedLabelColor = Color.White
                            )
                        )
                    }
                }

                Spacer(modifier = Modifier.height(8.dp))

                // Severity and Nearby Filters
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .horizontalScroll(rememberScrollState()),
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    FilterChip(
                        selected = onlyNearby,
                        onClick = { onSetOnlyNearby(!onlyNearby) },
                        label = { Text("📍 Nearby Incidents Only", fontSize = 12.sp, fontWeight = FontWeight.Bold) },
                        modifier = Modifier.testTag("filter_nearby_chip"),
                        colors = FilterChipDefaults.filterChipColors(
                            selectedContainerColor = OceanBlue,
                            selectedLabelColor = Color.White
                        )
                    )

                    val severities = listOf(
                        "ALL" to "All Severity",
                        "CRITICAL" to "🔴 Critical",
                        "SERIOUS" to "🟠 Serious",
                        "ADVISORY" to "🟡 Advisory",
                        "ARCHIVED" to "⚪ Archived"
                    )

                    severities.forEach { (sevKey, label) ->
                        FilterChip(
                            selected = selectedSeverityFilter.equals(sevKey, ignoreCase = true),
                            onClick = { onSetSeverityFilter(sevKey) },
                            label = { Text(label, fontSize = 12.sp) },
                            modifier = Modifier.testTag("filter_sev_${sevKey.lowercase()}")
                        )
                    }
                }
            }
        }

        // Section A: Notification list count summary
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Text(
                    text = "Active & Verified Incidents (${filteredAlerts.size})",
                    fontSize = 14.sp,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.onSurface
                )

                if (filteredAlerts.isNotEmpty()) {
                    Text(
                        text = "Updated just now",
                        fontSize = 11.sp,
                        color = SafeGreen,
                        fontWeight = FontWeight.Medium
                    )
                }
            }
        }

        // Empty state
        if (filteredAlerts.isEmpty()) {
            item {
                Card(
                    shape = RoundedCornerShape(14.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(28.dp),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        Icon(
                            imageVector = Icons.Default.CheckCircle,
                            contentDescription = null,
                            tint = SafeGreen,
                            modifier = Modifier.size(48.dp)
                        )
                        Spacer(modifier = Modifier.height(10.dp))
                        Text(
                            text = "No Incidents Matching Filter",
                            fontWeight = FontWeight.Bold,
                            fontSize = 15.sp,
                            color = MaterialTheme.colorScheme.onSurface
                        )
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(
                            text = "No severe warnings or alerts reported for this criteria in the database.",
                            fontSize = 12.sp,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                        Spacer(modifier = Modifier.height(12.dp))
                        OutlinedButton(onClick = {
                            onSetTypeFilter("ALL")
                            onSetSeverityFilter("ALL")
                            onSetLocationFilter("ALL")
                            onSetOnlyNearby(false)
                            onSetSearchQuery("")
                        }) {
                            Text("Reset All Filters")
                        }
                    }
                }
            }
        }

        // Incident Cards
        items(filteredAlerts, key = { it.id }) { alert ->
            val distanceKm = calculateHaversine(userLatitude, userLongitude, alert.latitude, alert.longitude)
            val isNearby = distanceKm <= 40.0 || (alert.locationCity.isNotBlank() && userCityName.contains(alert.locationCity, ignoreCase = true))

            DisasterAlertCard(
                alert = alert,
                distanceKm = distanceKm,
                isNearby = isNearby,
                onCardClick = {
                    onSelectAlertForDetail(alert)
                },
                onMarkRead = {
                    onMarkAsRead(alert.id)
                },
                onOpenSource = {
                    openWebUrl(context, alert.sourceUrl)
                },
                onCallDisasterHotline = {
                    when (alert.disasterType.lowercase()) {
                        "sunog", "fire" -> dialPhone(context, "(02) 8426-0219")
                        "lindol", "earthquake" -> dialPhone(context, "(02) 8426-1468")
                        "bagyo", "typhoon" -> dialPhone(context, "(02) 8284-0800")
                        "baha", "flood" -> dialPhone(context, "136")
                        else -> dialPhone(context, "911")
                    }
                }
            )
        }
    }

    // Modal: Full Alert Detail Dialog
    selectedAlertForDetail?.let { detail ->
        AlertDetailDialog(
            alert = detail,
            distanceKm = calculateHaversine(userLatitude, userLongitude, detail.latitude, detail.longitude),
            onDismiss = { onSelectAlertForDetail(null) },
            onOpenSource = { openWebUrl(context, detail.sourceUrl) },
            onCall911 = onCall911
        )
    }

    // Modal: Location Changer Dialog
    if (showLocationDialog) {
        AlertDialog(
            onDismissRequest = { showLocationDialog = false },
            title = { Text("Set Monitored Philippine City", fontWeight = FontWeight.Bold) },
            text = {
                Column(
                    modifier = Modifier.fillMaxWidth(),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Text(
                        text = "Select your city to receive localized alerts and calculate incident distance from your phone:",
                        fontSize = 12.sp,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                    phCities.forEach { (cityName, lat, lng) ->
                        Surface(
                            shape = RoundedCornerShape(8.dp),
                            color = if (userCityName == cityName) OceanBlue.copy(alpha = 0.15f) else MaterialTheme.colorScheme.surfaceVariant,
                            border = androidx.compose.foundation.BorderStroke(
                                1.dp,
                                if (userCityName == cityName) OceanBlue else Color.Transparent
                            ),
                            modifier = Modifier
                                .fillMaxWidth()
                                .clickable {
                                    onUpdateLocation(lat, lng, cityName)
                                    showLocationDialog = false
                                }
                        ) {
                            Row(
                                modifier = Modifier.padding(horizontal = 12.dp, vertical = 10.dp),
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Icon(Icons.Default.LocationOn, contentDescription = null, tint = OceanBlue, modifier = Modifier.size(16.dp))
                                    Spacer(modifier = Modifier.width(8.dp))
                                    Text(cityName, fontSize = 13.sp, fontWeight = FontWeight.Medium)
                                }
                                if (userCityName == cityName) {
                                    Icon(Icons.Default.Check, contentDescription = null, tint = OceanBlue, modifier = Modifier.size(16.dp))
                                }
                            }
                        }
                    }
                }
            },
            confirmButton = {
                TextButton(onClick = { showLocationDialog = false }) {
                    Text("Close")
                }
            }
        )
    }
}

@Composable
private fun DisasterAlertCard(
    alert: DisasterAlertEntity,
    distanceKm: Double,
    isNearby: Boolean,
    onCardClick: () -> Unit,
    onMarkRead: () -> Unit,
    onOpenSource: () -> Unit,
    onCallDisasterHotline: () -> Unit
) {
    // Official Severity Indicator Colors:
    // Red for critical warnings, Orange for serious alerts, Yellow for advisories, Gray for expired
    val (severityColor, severityLabel) = when {
        alert.isArchived || alert.severity.equals("EXPIRED", ignoreCase = true) -> Color(0xFF757575) to "EXPIRED / ARCHIVED"
        alert.severity.equals("CRITICAL", ignoreCase = true) -> Color(0xFFD32F2F) to "CRITICAL WARNING"
        alert.severity.equals("SERIOUS", ignoreCase = true) -> Color(0xFFE65100) to "SERIOUS ALERT"
        else -> Color(0xFFF57F17) to "OFFICIAL ADVISORY"
    }

    val disasterIcon = when (alert.disasterType.lowercase()) {
        "bagyo", "typhoon" -> Icons.Default.Cyclone
        "lindol", "earthquake" -> Icons.Default.Landscape
        "sunog", "fire" -> Icons.Default.LocalFireDepartment
        "baha", "flood" -> Icons.Default.Water
        "volcano", "bulkan" -> Icons.Default.Volcano
        else -> Icons.Default.Warning
    }

    var isExpanded by remember { mutableStateOf(false) }

    Card(
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(
            containerColor = if (!alert.isRead) severityColor.copy(alpha = 0.05f) else MaterialTheme.colorScheme.surface
        ),
        border = androidx.compose.foundation.BorderStroke(
            if (!alert.isRead) 1.5.dp else 1.dp,
            if (!alert.isRead) severityColor else MaterialTheme.colorScheme.outline.copy(alpha = 0.2f)
        ),
        modifier = Modifier
            .fillMaxWidth()
            .testTag("alert_card_${alert.id}")
            .animateContentSize()
    ) {
        Column(modifier = Modifier.padding(14.dp)) {
            // Severity bar & Type row
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Surface(
                        color = severityColor,
                        shape = RoundedCornerShape(6.dp)
                    ) {
                        Text(
                            text = severityLabel,
                            fontSize = 10.sp,
                            fontWeight = FontWeight.Black,
                            color = Color.White,
                            modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                        )
                    }

                    Spacer(modifier = Modifier.width(6.dp))

                    Surface(
                        color = MaterialTheme.colorScheme.surfaceVariant,
                        shape = RoundedCornerShape(6.dp)
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                        ) {
                            Icon(disasterIcon, contentDescription = null, tint = severityColor, modifier = Modifier.size(12.dp))
                            Spacer(modifier = Modifier.width(4.dp))
                            Text(DisasterType.formatDisasterTypeEnglish(alert.disasterType), fontSize = 10.sp, fontWeight = FontWeight.Bold)
                        }
                    }
                }

                Row(verticalAlignment = Alignment.CenterVertically) {
                    if (isNearby) {
                        Surface(
                            color = EmergencyRed.copy(alpha = 0.15f),
                            shape = RoundedCornerShape(4.dp)
                        ) {
                            Text(
                                text = "NEARBY (${String.format(Locale.US, "%.1f", distanceKm)} km)",
                                fontSize = 10.sp,
                                fontWeight = FontWeight.Black,
                                color = EmergencyRed,
                                modifier = Modifier.padding(horizontal = 4.dp, vertical = 2.dp)
                            )
                        }
                    }

                    if (!alert.isRead) {
                        Spacer(modifier = Modifier.width(6.dp))
                        Box(
                            modifier = Modifier
                                .size(8.dp)
                                .background(EmergencyRed, CircleShape)
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(10.dp))

            // Alert Title
            Text(
                text = alert.title,
                fontSize = 15.sp,
                fontWeight = FontWeight.Bold,
                color = MaterialTheme.colorScheme.onSurface,
                lineHeight = 20.sp
            )

            Spacer(modifier = Modifier.height(4.dp))

            // Location
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(
                    imageVector = Icons.Default.LocationOn,
                    contentDescription = null,
                    tint = MaterialTheme.colorScheme.primary,
                    modifier = Modifier.size(14.dp)
                )
                Spacer(modifier = Modifier.width(4.dp))
                val locText = listOf(alert.locationBarangay, alert.locationCity, alert.locationProvince, alert.affectedRegion)
                    .filter { it.isNotBlank() }
                    .joinToString(", ")
                Text(
                    text = if (locText.isNotEmpty()) locText else "Philippines",
                    fontSize = 12.sp,
                    fontWeight = FontWeight.Medium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }

            Spacer(modifier = Modifier.height(6.dp))

            // Short Description
            Text(
                text = alert.shortDescription,
                fontSize = 13.sp,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                lineHeight = 18.sp
            )

            // Parameter chips if available
            val hasCustomParams = !alert.typhoonSignal.isNullOrBlank() ||
                    !alert.earthquakeMagnitude.isNullOrBlank() ||
                    !alert.fireAlarmLevel.isNullOrBlank() ||
                    !alert.floodLevel.isNullOrBlank()

            if (hasCustomParams) {
                Spacer(modifier = Modifier.height(8.dp))
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .horizontalScroll(rememberScrollState()),
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    alert.typhoonSignal?.let { signal ->
                        ParamChip(label = signal, color = AlertAmber)
                    }
                    alert.earthquakeMagnitude?.let { mag ->
                        ParamChip(label = mag, color = severityColor)
                    }
                    alert.earthquakeDepth?.let { depth ->
                        ParamChip(label = "Depth: $depth", color = OceanBlue)
                    }
                    alert.fireAlarmLevel?.let { alarm ->
                        ParamChip(label = alarm, color = EmergencyRed)
                    }
                    alert.floodLevel?.let { flood ->
                        ParamChip(label = flood, color = OceanBlue)
                    }
                }
            }

            Spacer(modifier = Modifier.height(8.dp))

            // Official Verification Status and Source row
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(
                        imageVector = Icons.Default.Shield,
                        contentDescription = null,
                        tint = SafeGreen,
                        modifier = Modifier.size(13.dp)
                    )
                    Spacer(modifier = Modifier.width(4.dp))
                    Text(
                        text = alert.verificationStatus,
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        color = SafeGreen
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        text = "• ${alert.sourceName}",
                        fontSize = 11.sp,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                }

                Text(
                    text = formatIncidentTime(alert.incidentTime),
                    fontSize = 10.sp,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }

            // Expandable details block
            AnimatedVisibility(visible = isExpanded) {
                Column(modifier = Modifier.padding(top = 10.dp)) {
                    HorizontalDivider(color = MaterialTheme.colorScheme.outline.copy(alpha = 0.15f))
                    Spacer(modifier = Modifier.height(8.dp))

                    Text(
                        text = "Official Safety Advisory & Detailed Actions:",
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.onSurface
                    )
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        text = if (alert.detailedInstructions.isNotBlank()) alert.detailedInstructions else alert.shortDescription,
                        fontSize = 12.sp,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        lineHeight = 17.sp
                    )

                    Spacer(modifier = Modifier.height(8.dp))
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        OutlinedButton(
                            onClick = onOpenSource,
                            modifier = Modifier.weight(1f),
                            shape = RoundedCornerShape(8.dp),
                            contentPadding = PaddingValues(horizontal = 6.dp, vertical = 4.dp)
                        ) {
                            Text("Open Official Link", fontSize = 11.sp)
                            Spacer(modifier = Modifier.width(4.dp))
                            Icon(Icons.AutoMirrored.Filled.OpenInNew, contentDescription = null, modifier = Modifier.size(12.dp))
                        }

                        Button(
                            onClick = onCallDisasterHotline,
                            colors = ButtonDefaults.buttonColors(containerColor = EmergencyRed),
                            modifier = Modifier.weight(1f),
                            shape = RoundedCornerShape(8.dp),
                            contentPadding = PaddingValues(horizontal = 6.dp, vertical = 4.dp)
                        ) {
                            Icon(Icons.Default.Call, contentDescription = null, modifier = Modifier.size(12.dp))
                            Spacer(modifier = Modifier.width(4.dp))
                            Text("Call Agency Hotline", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(8.dp))

            // Bottom actions: View Details expander & Mark as read
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                TextButton(
                    onClick = {
                        isExpanded = !isExpanded
                        if (!alert.isRead) onMarkRead()
                    },
                    modifier = Modifier.testTag("toggle_details_${alert.id}"),
                    contentPadding = PaddingValues(0.dp)
                ) {
                    Text(
                        text = if (isExpanded) "Hide Details" else "View Complete Details",
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Bold,
                        color = OceanBlue
                    )
                    Spacer(modifier = Modifier.width(2.dp))
                    Icon(
                        imageVector = if (isExpanded) Icons.Default.KeyboardArrowUp else Icons.Default.KeyboardArrowDown,
                        contentDescription = null,
                        tint = OceanBlue,
                        modifier = Modifier.size(16.dp)
                    )
                }

                if (!alert.isRead) {
                    OutlinedButton(
                        onClick = onMarkRead,
                        shape = RoundedCornerShape(6.dp),
                        contentPadding = PaddingValues(horizontal = 8.dp, vertical = 2.dp)
                    ) {
                        Icon(Icons.Default.Check, contentDescription = null, modifier = Modifier.size(12.dp))
                        Spacer(modifier = Modifier.width(4.dp))
                        Text("Mark Read", fontSize = 10.sp)
                    }
                }
            }
        }
    }
}

@Composable
private fun ParamChip(label: String, color: Color) {
    Surface(
        color = color.copy(alpha = 0.12f),
        shape = RoundedCornerShape(4.dp),
        border = androidx.compose.foundation.BorderStroke(1.dp, color.copy(alpha = 0.3f))
    ) {
        Text(
            text = label,
            fontSize = 10.sp,
            fontWeight = FontWeight.Bold,
            color = color,
            modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
        )
    }
}

@Composable
private fun OfficialAgencyCard(
    title: String,
    subtitle: String,
    icon: ImageVector,
    buttonLabel: String,
    color: Color,
    testTag: String,
    modifier: Modifier = Modifier,
    onClick: () -> Unit
) {
    Card(
        shape = RoundedCornerShape(12.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        border = androidx.compose.foundation.BorderStroke(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.2f)),
        modifier = modifier
    ) {
        Column(modifier = Modifier.padding(10.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(icon, contentDescription = null, tint = color, modifier = Modifier.size(18.dp))
                Spacer(modifier = Modifier.width(6.dp))
                Column {
                    Text(title, fontWeight = FontWeight.Bold, fontSize = 13.sp)
                    Text(subtitle, fontSize = 10.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
            }
            Spacer(modifier = Modifier.height(8.dp))
            Button(
                onClick = onClick,
                colors = ButtonDefaults.buttonColors(containerColor = color),
                shape = RoundedCornerShape(6.dp),
                contentPadding = PaddingValues(horizontal = 6.dp, vertical = 4.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag(testTag)
            ) {
                Text(buttonLabel, fontSize = 10.sp, fontWeight = FontWeight.Bold, maxLines = 1)
            }
        }
    }
}

@Composable
private fun AlertDetailDialog(
    alert: DisasterAlertEntity,
    distanceKm: Double,
    onDismiss: () -> Unit,
    onOpenSource: () -> Unit,
    onCall911: () -> Unit
) {
    val context = LocalContext.current
    val severityColor = when {
        alert.isArchived || alert.severity.equals("EXPIRED", ignoreCase = true) -> Color(0xFF757575)
        alert.severity.equals("CRITICAL", ignoreCase = true) -> Color(0xFFD32F2F)
        alert.severity.equals("SERIOUS", ignoreCase = true) -> Color(0xFFE65100)
        else -> Color(0xFFF57F17)
    }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = {
            Column {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Surface(color = severityColor, shape = RoundedCornerShape(4.dp)) {
                        Text(
                            text = alert.severity,
                            fontSize = 10.sp,
                            fontWeight = FontWeight.Black,
                            color = Color.White,
                            modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                        )
                    }
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(DisasterType.formatDisasterTypeEnglish(alert.disasterType), fontSize = 12.sp, fontWeight = FontWeight.Bold)
                }
                Spacer(modifier = Modifier.height(4.dp))
                Text(alert.title, fontSize = 16.sp, fontWeight = FontWeight.Bold)
            }
        },
        text = {
            Column(
                modifier = Modifier.fillMaxWidth(),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                // Location & distance
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Default.LocationOn, contentDescription = null, tint = OceanBlue, modifier = Modifier.size(16.dp))
                    Spacer(modifier = Modifier.width(4.dp))
                    Text(
                        text = "${alert.locationBarangay}, ${alert.locationCity}, ${alert.locationProvince} (${String.format(Locale.US, "%.1f", distanceKm)} km away)",
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Medium
                    )
                }

                // Description
                Text(alert.shortDescription, fontSize = 13.sp, lineHeight = 18.sp)

                if (alert.detailedInstructions.isNotBlank()) {
                    Spacer(modifier = Modifier.height(4.dp))
                    Text("Official Actions & Advice:", fontWeight = FontWeight.Bold, fontSize = 12.sp)
                    Text(alert.detailedInstructions, fontSize = 12.sp, lineHeight = 17.sp)
                }

                // Official Parameters
                alert.typhoonSignal?.let { Text("🌀 Signal: $it", fontSize = 12.sp, fontWeight = FontWeight.SemiBold) }
                alert.earthquakeMagnitude?.let { Text("🌋 Magnitude: $it (Depth: ${alert.earthquakeDepth ?: "Tectonic"})", fontSize = 12.sp, fontWeight = FontWeight.SemiBold) }
                alert.fireAlarmLevel?.let { Text("🔥 Fire Alarm: $it", fontSize = 12.sp, fontWeight = FontWeight.SemiBold) }
                alert.floodLevel?.let { Text("🌊 Flood Depth: $it", fontSize = 12.sp, fontWeight = FontWeight.SemiBold) }

                Spacer(modifier = Modifier.height(6.dp))
                Text(
                    text = "Source: ${alert.sourceName} • Status: ${alert.verificationStatus}",
                    fontSize = 11.sp,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
        },
        confirmButton = {
            Button(
                onClick = onCall911,
                colors = ButtonDefaults.buttonColors(containerColor = EmergencyRed)
            ) {
                Text("CALL 911", fontWeight = FontWeight.Bold)
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) {
                Text("Close")
            }
        }
    )
}

// Helpers
private fun formatIncidentTime(timestamp: Long): String {
    val diffMs = System.currentTimeMillis() - timestamp
    val diffMins = diffMs / (60 * 1000L)
    return when {
        diffMins < 1 -> "Just now"
        diffMins < 60 -> "$diffMins mins ago"
        diffMins < 1440 -> "${diffMins / 60} hours ago"
        else -> {
            val sdf = SimpleDateFormat("MMM d, yyyy h:mm a", Locale.getDefault())
            sdf.format(Date(timestamp))
        }
    }
}

private fun calculateHaversine(lat1: Double, lon1: Double, lat2: Double, lon2: Double): Double {
    val r = 6371.0 // Radius of earth in km
    val dLat = Math.toRadians(lat2 - lat1)
    val dLon = Math.toRadians(lon2 - lon1)
    val a = Math.sin(dLat / 2) * Math.sin(dLat / 2) +
            Math.cos(Math.toRadians(lat1)) * Math.cos(Math.toRadians(lat2)) *
            Math.sin(dLon / 2) * Math.sin(dLon / 2)
    val c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a))
    return r * c
}

private fun openWebUrl(context: Context, url: String) {
    try {
        val intent = Intent(Intent.ACTION_VIEW, Uri.parse(url)).apply {
            flags = Intent.FLAG_ACTIVITY_NEW_TASK
        }
        context.startActivity(intent)
    } catch (_: Exception) {
        Toast.makeText(context, "Cannot open browser: $url", Toast.LENGTH_SHORT).show()
    }
}

private fun dialPhone(context: Context, phone: String) {
    try {
        val intent = Intent(Intent.ACTION_DIAL, Uri.parse("tel:${phone.replace(" ", "")}")).apply {
            flags = Intent.FLAG_ACTIVITY_NEW_TASK
        }
        context.startActivity(intent)
    } catch (_: Exception) {
        Toast.makeText(context, "Cannot dial: $phone", Toast.LENGTH_SHORT).show()
    }
}
