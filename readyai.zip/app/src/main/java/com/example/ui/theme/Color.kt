package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// ReadyAI Emergency Color Palette
val EmergencyRed = Color(0xFFC62828)
val EmergencyRedDark = Color(0xFF8E0000)
val EmergencyRedLight = Color(0xFFFFCDD2)
val EmergencyRedSurface = Color(0xFFFFF5F5)

val AlertAmber = Color(0xFFE65100)
val AlertAmberLight = Color(0xFFFFE082)
val AlertAmberContainer = Color(0xFFFFF3E0)

val SafeGreen = Color(0xFF2E7D32)
val SafeGreenLight = Color(0xFFC8E6C9)
val SafeGreenContainer = Color(0xFFE8F5E9)

val OceanBlue = Color(0xFF0277BD)
val OceanBlueLight = Color(0xFFB3E5FC)

val DisasterNavy = Color(0xFF0D1B2A)
val DisasterNavySurface = Color(0xFF1B263B)
val DisasterNavyLight = Color(0xFF415A77)

// Light Theme Tokens
val LightBackground = Color(0xFFF7F9FC)
val LightSurface = Color(0xFFFFFFFF)
val LightSurfaceVariant = Color(0xFFEEF2F6)
val LightOnSurface = Color(0xFF1A1C1E)
val LightOutline = Color(0xFFD0D7DE)

// Dark Theme Tokens
val DarkBackground = Color(0xFF121417)
val DarkSurface = Color(0xFF1E2126)
val DarkSurfaceVariant = Color(0xFF2B3038)
val DarkOnSurface = Color(0xFFE2E4E9)
val DarkOutline = Color(0xFF444A54)
