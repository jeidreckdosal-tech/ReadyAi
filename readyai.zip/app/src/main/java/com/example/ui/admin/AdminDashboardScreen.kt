package com.example.ui.admin

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.automirrored.filled.ExitToApp
import androidx.compose.material.icons.automirrored.filled.VolumeUp
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.AdminPanelSettings
import androidx.compose.material.icons.filled.Campaign
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.ContactPhone
import androidx.compose.material.icons.filled.Dashboard
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.Feedback
import androidx.compose.material.icons.filled.LocationOn
import androidx.compose.material.icons.filled.Menu
import androidx.compose.material.icons.filled.NotificationsActive
import androidx.compose.material.icons.filled.People
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Shield
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.local.AnnouncementEntity
import com.example.data.local.DisasterAlertEntity
import com.example.data.local.FeedbackEntity
import com.example.data.local.UserEntity
import com.example.data.model.DisasterType
import com.example.data.model.ContactCategory
import com.example.data.model.EmergencyCategory
import com.example.data.model.EmergencyContact
import com.example.data.model.PhilippineRegion
import com.example.ui.AdminTab
import com.example.ui.theme.AlertAmber
import com.example.ui.theme.DisasterNavy
import com.example.ui.theme.EmergencyRed
import com.example.ui.theme.OceanBlue
import com.example.ui.theme.SafeGreen

@Composable
fun AdminDashboardScreen(
    currentTab: AdminTab,
    onTabSelected: (AdminTab) -> Unit,
    onExitToUserUi: () -> Unit,
    totalUsers: Int,
    usersList: List<UserEntity>,
    guidesList: List<EmergencyCategory>,
    contactsList: List<EmergencyContact>,
    regionsList: List<PhilippineRegion>,
    announcementsList: List<AnnouncementEntity>,
    feedbackList: List<FeedbackEntity>,
    alertsList: List<DisasterAlertEntity> = emptyList(),
    onSaveGuide: (EmergencyCategory) -> Unit,
    onDeleteGuide: (String) -> Unit,
    onSaveContact: (EmergencyContact) -> Unit,
    onDeleteContact: (String) -> Unit,
    onUpdateRegion: (PhilippineRegion) -> Unit,
    onSaveAnnouncement: (AnnouncementEntity) -> Unit,
    onDeleteAnnouncement: (String) -> Unit,
    onUpdateFeedbackStatus: (String, String) -> Unit,
    onDeleteFeedback: (String) -> Unit,
    onToggleUserRole: (String) -> Unit,
    onDeleteUser: (String) -> Unit,
    onSaveAlert: (DisasterAlertEntity) -> Unit = {},
    onDeleteAlert: (String) -> Unit = {},
    onBroadcastAlert: (DisasterAlertEntity) -> Unit = {}
) {
    var showMobileMenu by remember { mutableStateOf(false) }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(Color(0xFFF4F6F9))
            .testTag("admin_dashboard_root")
    ) {
        // 1. Admin Top Bar
        Surface(
            color = DisasterNavy,
            modifier = Modifier.fillMaxWidth(),
            shadowElevation = 4.dp
        ) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp, vertical = 10.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(
                        modifier = Modifier
                            .size(34.dp)
                            .background(EmergencyRed, RoundedCornerShape(8.dp)),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = Icons.Default.Shield,
                            contentDescription = null,
                            tint = Color.White,
                            modifier = Modifier.size(20.dp)
                        )
                    }
                    Spacer(modifier = Modifier.width(10.dp))
                    Column {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text(
                                text = "ReadyAI Admin Console",
                                fontWeight = FontWeight.Black,
                                fontSize = 16.sp,
                                color = Color.White
                            )
                            Spacer(modifier = Modifier.width(6.dp))
                            Surface(
                                color = EmergencyRed,
                                shape = RoundedCornerShape(4.dp)
                            ) {
                                Text(
                                    text = "LIVE DB",
                                    fontSize = 9.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = Color.White,
                                    modifier = Modifier.padding(horizontal = 4.dp, vertical = 1.dp)
                                )
                            }
                        }
                        Text(
                            text = "Disaster Management & Operations",
                            fontSize = 11.sp,
                            color = Color.White.copy(alpha = 0.7f)
                        )
                    }
                }

                Row(verticalAlignment = Alignment.CenterVertically) {
                    Button(
                        onClick = onExitToUserUi,
                        colors = ButtonDefaults.buttonColors(containerColor = Color.White.copy(alpha = 0.15f)),
                        shape = RoundedCornerShape(8.dp),
                        contentPadding = PaddingValues(horizontal = 10.dp, vertical = 6.dp),
                        modifier = Modifier.testTag("admin_switch_to_user_button")
                    ) {
                        Icon(imageVector = Icons.AutoMirrored.Filled.ExitToApp, contentDescription = null, tint = Color.White, modifier = Modifier.size(14.dp))
                        Spacer(modifier = Modifier.width(4.dp))
                        Text("User View", color = Color.White, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                    }
                }
            }
        }

        // 2. Dashboard Navigation Tabs (Dark Dashboard Sidebar style horizontal on mobile)
        Surface(
            color = Color(0xFF1B263B),
            modifier = Modifier.fillMaxWidth()
        ) {
            LazyRow(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 8.dp, vertical = 6.dp),
                horizontalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                item {
                    AdminNavTabItem("Overview", Icons.Default.Dashboard, currentTab == AdminTab.OVERVIEW) {
                        onTabSelected(AdminTab.OVERVIEW)
                    }
                }
                item {
                    AdminNavTabItem("Alerts", Icons.Default.NotificationsActive, currentTab == AdminTab.ALERTS) {
                        onTabSelected(AdminTab.ALERTS)
                    }
                }
                item {
                    AdminNavTabItem("Guides", Icons.Default.Warning, currentTab == AdminTab.GUIDES) {
                        onTabSelected(AdminTab.GUIDES)
                    }
                }
                item {
                    AdminNavTabItem("Contacts", Icons.Default.ContactPhone, currentTab == AdminTab.CONTACTS) {
                        onTabSelected(AdminTab.CONTACTS)
                    }
                }
                item {
                    AdminNavTabItem("Regions", Icons.Default.LocationOn, currentTab == AdminTab.REGIONS) {
                        onTabSelected(AdminTab.REGIONS)
                    }
                }
                item {
                    AdminNavTabItem("Announce", Icons.Default.Campaign, currentTab == AdminTab.ANNOUNCEMENTS) {
                        onTabSelected(AdminTab.ANNOUNCEMENTS)
                    }
                }
                item {
                    AdminNavTabItem("Feedback", Icons.Default.Feedback, currentTab == AdminTab.FEEDBACK) {
                        onTabSelected(AdminTab.FEEDBACK)
                    }
                }
                item {
                    AdminNavTabItem("Users", Icons.Default.People, currentTab == AdminTab.USERS) {
                        onTabSelected(AdminTab.USERS)
                    }
                }
            }
        }

        // 3. Tab Body Content
        Box(
            modifier = Modifier
                .fillMaxSize()
                .weight(1f)
        ) {
            when (currentTab) {
                AdminTab.OVERVIEW -> AdminOverviewSection(
                    totalUsers = totalUsers,
                    guidesCount = guidesList.size,
                    contactsCount = contactsList.size,
                    announcementsCount = announcementsList.size,
                    feedbackCount = feedbackList.size,
                    alertsCount = alertsList.size,
                    onNavigateTo = onTabSelected
                )
                AdminTab.ALERTS -> AdminAlertsSection(
                    alerts = alertsList,
                    onSaveAlert = onSaveAlert,
                    onDeleteAlert = onDeleteAlert,
                    onBroadcastAlert = onBroadcastAlert
                )
                AdminTab.GUIDES -> AdminGuidesSection(
                    guides = guidesList,
                    onSaveGuide = onSaveGuide,
                    onDeleteGuide = onDeleteGuide
                )
                AdminTab.CONTACTS -> AdminContactsSection(
                    contacts = contactsList,
                    onSaveContact = onSaveContact,
                    onDeleteContact = onDeleteContact
                )
                AdminTab.REGIONS -> AdminRegionsSection(
                    regions = regionsList,
                    onUpdateRegion = onUpdateRegion
                )
                AdminTab.ANNOUNCEMENTS -> AdminAnnouncementsSection(
                    announcements = announcementsList,
                    onSaveAnnouncement = onSaveAnnouncement,
                    onDeleteAnnouncement = onDeleteAnnouncement
                )
                AdminTab.FEEDBACK -> AdminFeedbackSection(
                    feedbackList = feedbackList,
                    onUpdateStatus = onUpdateFeedbackStatus,
                    onDeleteFeedback = onDeleteFeedback
                )
                AdminTab.USERS -> AdminUsersSection(
                    users = usersList,
                    onToggleRole = onToggleUserRole,
                    onDeleteUser = onDeleteUser
                )
            }
        }
    }
}

@Composable
fun AdminNavTabItem(
    title: String,
    icon: ImageVector,
    isSelected: Boolean,
    onClick: () -> Unit
) {
    Surface(
        color = if (isSelected) EmergencyRed else Color.Transparent,
        shape = RoundedCornerShape(8.dp),
        modifier = Modifier
            .clickable { onClick() }
            .testTag("admin_nav_tab_${title.lowercase()}")
    ) {
        Row(
            modifier = Modifier.padding(horizontal = 10.dp, vertical = 8.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Icon(
                imageVector = icon,
                contentDescription = title,
                tint = if (isSelected) Color.White else Color.White.copy(alpha = 0.7f),
                modifier = Modifier.size(16.dp)
            )
            Spacer(modifier = Modifier.width(6.dp))
            Text(
                text = title,
                fontSize = 12.sp,
                fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Medium,
                color = if (isSelected) Color.White else Color.White.copy(alpha = 0.7f)
            )
        }
    }
}

// --- 1. OVERVIEW SECTION ---
@Composable
fun AdminOverviewSection(
    totalUsers: Int,
    guidesCount: Int,
    contactsCount: Int,
    announcementsCount: Int,
    feedbackCount: Int,
    alertsCount: Int = 0,
    onNavigateTo: (AdminTab) -> Unit
) {
    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .testTag("admin_overview_content"),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        item {
            Text(
                text = "System Statistics & Data Overview",
                fontSize = 18.sp,
                fontWeight = FontWeight.Bold,
                color = DisasterNavy
            )
            Text(
                text = "Live database status. Changes made here immediately update for all citizens.",
                fontSize = 12.sp,
                color = Color.Gray
            )
        }

        // Stats Cards Grid
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                AdminStatCard(
                    title = "Disaster Alerts",
                    value = "$alertsCount",
                    icon = Icons.Default.NotificationsActive,
                    color = EmergencyRed,
                    modifier = Modifier.weight(1f),
                    onClick = { onNavigateTo(AdminTab.ALERTS) }
                )
                AdminStatCard(
                    title = "Total Users",
                    value = "$totalUsers",
                    icon = Icons.Default.People,
                    color = OceanBlue,
                    modifier = Modifier.weight(1f),
                    onClick = { onNavigateTo(AdminTab.USERS) }
                )
            }
        }

        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                AdminStatCard(
                    title = "Disaster Guides",
                    value = "$guidesCount",
                    icon = Icons.Default.Warning,
                    color = AlertAmber,
                    modifier = Modifier.weight(1f),
                    onClick = { onNavigateTo(AdminTab.GUIDES) }
                )
                AdminStatCard(
                    title = "Announcements",
                    value = "$announcementsCount",
                    icon = Icons.Default.Campaign,
                    color = EmergencyRed,
                    modifier = Modifier.weight(1f),
                    onClick = { onNavigateTo(AdminTab.ANNOUNCEMENTS) }
                )
            }
        }

        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                AdminStatCard(
                    title = "Emergency Contacts",
                    value = "$contactsCount",
                    icon = Icons.Default.ContactPhone,
                    color = OceanBlue,
                    modifier = Modifier.weight(1f),
                    onClick = { onNavigateTo(AdminTab.CONTACTS) }
                )
                AdminStatCard(
                    title = "User Feedback",
                    value = "$feedbackCount",
                    icon = Icons.Default.Feedback,
                    color = SafeGreen,
                    modifier = Modifier.weight(1f),
                    onClick = { onNavigateTo(AdminTab.FEEDBACK) }
                )
            }
        }

        // Quick Management Shortcuts Card
        item {
            Card(
                shape = RoundedCornerShape(14.dp),
                colors = CardDefaults.cardColors(containerColor = Color.White),
                elevation = CardDefaults.cardElevation(defaultElevation = 1.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text(
                        text = "Real-Time Synchronization Rules",
                        fontWeight = FontWeight.Bold,
                        fontSize = 14.sp,
                        color = DisasterNavy
                    )
                    Spacer(modifier = Modifier.height(6.dp))
                    Text(
                        text = "• Admin updates emergency contact → Data is saved in Database → User sees the updated contact automatically.\n• Add official storm bulletins to reach all active users instantaneously.\n• Manage regional disaster risk reduction and local LGU telephone numbers directly without redeploying the app.",
                        fontSize = 12.sp,
                        color = Color.DarkGray,
                        lineHeight = 18.sp
                    )
                }
            }
        }
    }
}

@Composable
fun AdminStatCard(
    title: String,
    value: String,
    icon: ImageVector,
    color: Color,
    modifier: Modifier = Modifier,
    onClick: () -> Unit
) {
    Card(
        shape = RoundedCornerShape(14.dp),
        colors = CardDefaults.cardColors(containerColor = Color.White),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
        modifier = modifier
            .clickable { onClick() }
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Column {
                Text(text = title, fontSize = 11.sp, color = Color.Gray, fontWeight = FontWeight.SemiBold)
                Spacer(modifier = Modifier.height(4.dp))
                Text(text = value, fontSize = 24.sp, fontWeight = FontWeight.Black, color = DisasterNavy)
            }

            Box(
                modifier = Modifier
                    .size(42.dp)
                    .background(color.copy(alpha = 0.12f), CircleShape),
                contentAlignment = Alignment.Center
            ) {
                Icon(imageVector = icon, contentDescription = title, tint = color, modifier = Modifier.size(24.dp))
            }
        }
    }
}

// --- 2. GUIDES MANAGEMENT SECTION ---
@Composable
fun AdminGuidesSection(
    guides: List<EmergencyCategory>,
    onSaveGuide: (EmergencyCategory) -> Unit,
    onDeleteGuide: (String) -> Unit
) {
    var searchQuery by remember { mutableStateOf("") }
    var editingGuide by remember { mutableStateOf<EmergencyCategory?>(null) }
    var isAddingNew by remember { mutableStateOf(false) }

    val filtered = guides.filter {
        it.title.contains(searchQuery, ignoreCase = true) || it.filipinoTitle.contains(searchQuery, ignoreCase = true)
    }

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .testTag("admin_guides_content"),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Text("Emergency Guides (${guides.size})", fontWeight = FontWeight.Bold, fontSize = 16.sp, color = DisasterNavy)
                    Text("Add, edit, or delete disaster procedures", fontSize = 11.sp, color = Color.Gray)
                }

                Button(
                    onClick = { isAddingNew = true },
                    colors = ButtonDefaults.buttonColors(containerColor = DisasterNavy),
                    shape = RoundedCornerShape(8.dp),
                    contentPadding = PaddingValues(horizontal = 12.dp, vertical = 6.dp),
                    modifier = Modifier.testTag("admin_add_guide_button")
                ) {
                    Icon(imageVector = Icons.Default.Add, contentDescription = null, modifier = Modifier.size(16.dp))
                    Spacer(modifier = Modifier.width(4.dp))
                    Text("New Guide", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                }
            }
        }

        item {
            OutlinedTextField(
                value = searchQuery,
                onValueChange = { searchQuery = it },
                placeholder = { Text("Search disaster guides...") },
                leadingIcon = { Icon(Icons.Default.Search, contentDescription = null) },
                singleLine = true,
                shape = RoundedCornerShape(10.dp),
                modifier = Modifier.fillMaxWidth()
            )
        }

        items(filtered, key = { it.id }) { guide ->
            Card(
                shape = RoundedCornerShape(12.dp),
                colors = CardDefaults.cardColors(containerColor = Color.White),
                elevation = CardDefaults.cardElevation(defaultElevation = 1.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(14.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text(text = guide.title, fontWeight = FontWeight.Bold, fontSize = 15.sp, color = DisasterNavy)
                            Spacer(modifier = Modifier.width(6.dp))
                            Surface(color = AlertAmber.copy(alpha = 0.15f), shape = RoundedCornerShape(4.dp)) {
                                Text(text = guide.filipinoTitle, fontSize = 10.sp, fontWeight = FontWeight.Bold, color = AlertAmber, modifier = Modifier.padding(horizontal = 4.dp, vertical = 2.dp))
                            }
                        }
                        Spacer(modifier = Modifier.height(2.dp))
                        Text(text = guide.agencyInCharge, fontSize = 11.sp, color = Color.Gray)
                        Text(text = guide.summary, fontSize = 12.sp, color = Color.DarkGray, maxLines = 1)
                    }

                    Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        IconButton(
                            onClick = { editingGuide = guide },
                            modifier = Modifier.size(32.dp)
                        ) {
                            Icon(imageVector = Icons.Default.Edit, contentDescription = "Edit", tint = OceanBlue, modifier = Modifier.size(18.dp))
                        }

                        IconButton(
                            onClick = { onDeleteGuide(guide.id) },
                            modifier = Modifier.size(32.dp)
                        ) {
                            Icon(imageVector = Icons.Default.Delete, contentDescription = "Delete", tint = EmergencyRed, modifier = Modifier.size(18.dp))
                        }
                    }
                }
            }
        }
    }

    if (editingGuide != null || isAddingNew) {
        val target = editingGuide ?: EmergencyCategory(
            id = "guide_${System.currentTimeMillis()}",
            title = "",
            filipinoTitle = "",
            summary = "",
            iconName = "warning",
            whatToDoBefore = listOf("Prepare essential supplies and monitor local advisories."),
            whatToDoDuring = listOf("Remain calm and take immediate protective cover."),
            whatToDoAfter = listOf("Inspect structural damage and help neighbors safely."),
            whatNotToDo = listOf("Do not panic or enter compromised structures."),
            safetyTips = listOf("Always know your nearest evacuation route."),
            whatToPrepare = listOf("Water, canned food, flashlight, medicines, whistle."),
            whenToCallServices = listOf("When someone is trapped or severely injured."),
            agencyInCharge = "NDRRMC"
        )

        GuideEditDialog(
            initialGuide = target,
            isNew = isAddingNew,
            onDismiss = {
                editingGuide = null
                isAddingNew = false
            },
            onSave = { updated ->
                onSaveGuide(updated)
                editingGuide = null
                isAddingNew = false
            }
        )
    }
}

@Composable
fun GuideEditDialog(
    initialGuide: EmergencyCategory,
    isNew: Boolean,
    onDismiss: () -> Unit,
    onSave: (EmergencyCategory) -> Unit
) {
    var title by remember { mutableStateOf(initialGuide.title) }
    var filipinoTitle by remember { mutableStateOf(initialGuide.filipinoTitle) }
    var summary by remember { mutableStateOf(initialGuide.summary) }
    var agencyInCharge by remember { mutableStateOf(initialGuide.agencyInCharge) }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(if (isNew) "Add Emergency Guide" else "Edit Guide: ${initialGuide.title}", fontWeight = FontWeight.Bold) },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                OutlinedTextField(
                    value = title,
                    onValueChange = { title = it },
                    label = { Text("Title (e.g. Typhoon)") },
                    modifier = Modifier.fillMaxWidth()
                )
                OutlinedTextField(
                    value = filipinoTitle,
                    onValueChange = { filipinoTitle = it },
                    label = { Text("Filipino Term (e.g. Bagyo)") },
                    modifier = Modifier.fillMaxWidth()
                )
                OutlinedTextField(
                    value = agencyInCharge,
                    onValueChange = { agencyInCharge = it },
                    label = { Text("Agency in Charge (e.g. PAGASA)") },
                    modifier = Modifier.fillMaxWidth()
                )
                OutlinedTextField(
                    value = summary,
                    onValueChange = { summary = it },
                    label = { Text("Summary Description") },
                    modifier = Modifier.fillMaxWidth()
                )
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    onSave(
                        initialGuide.copy(
                            title = title,
                            filipinoTitle = filipinoTitle,
                            agencyInCharge = agencyInCharge,
                            summary = summary
                        )
                    )
                },
                colors = ButtonDefaults.buttonColors(containerColor = DisasterNavy)
            ) {
                Text("Save to DB")
            }
        },
        dismissButton = {
            OutlinedButton(onClick = onDismiss) {
                Text("Cancel")
            }
        }
    )
}

// --- 3. CONTACTS MANAGEMENT SECTION ---
@Composable
fun AdminContactsSection(
    contacts: List<EmergencyContact>,
    onSaveContact: (EmergencyContact) -> Unit,
    onDeleteContact: (String) -> Unit
) {
    var isAdding by remember { mutableStateOf(false) }
    var editingContact by remember { mutableStateOf<EmergencyContact?>(null) }

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .testTag("admin_contacts_content"),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Text("Emergency Hotlines (${contacts.size})", fontWeight = FontWeight.Bold, fontSize = 16.sp, color = DisasterNavy)
                    Text("Manage national agency emergency phone numbers", fontSize = 11.sp, color = Color.Gray)
                }

                Button(
                    onClick = { isAdding = true },
                    colors = ButtonDefaults.buttonColors(containerColor = DisasterNavy),
                    shape = RoundedCornerShape(8.dp),
                    contentPadding = PaddingValues(horizontal = 12.dp, vertical = 6.dp),
                    modifier = Modifier.testTag("admin_add_contact_button")
                ) {
                    Icon(imageVector = Icons.Default.Add, contentDescription = null, modifier = Modifier.size(16.dp))
                    Spacer(modifier = Modifier.width(4.dp))
                    Text("Add Hotline", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                }
            }
        }

        items(contacts, key = { it.id }) { contact ->
            Card(
                shape = RoundedCornerShape(12.dp),
                colors = CardDefaults.cardColors(containerColor = Color.White),
                elevation = CardDefaults.cardElevation(defaultElevation = 1.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(14.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text(text = contact.acronym, fontWeight = FontWeight.Black, fontSize = 14.sp, color = EmergencyRed)
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(text = contact.agencyName, fontWeight = FontWeight.Bold, fontSize = 14.sp, color = DisasterNavy)
                        }
                        Text(text = contact.primaryNumber, fontWeight = FontWeight.Black, fontSize = 14.sp, color = OceanBlue)
                        Text(text = contact.description, fontSize = 11.sp, color = Color.Gray, maxLines = 1)
                    }

                    Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        IconButton(
                            onClick = { editingContact = contact },
                            modifier = Modifier.size(32.dp)
                        ) {
                            Icon(imageVector = Icons.Default.Edit, contentDescription = "Edit", tint = OceanBlue, modifier = Modifier.size(18.dp))
                        }

                        IconButton(
                            onClick = { onDeleteContact(contact.id) },
                            modifier = Modifier.size(32.dp)
                        ) {
                            Icon(imageVector = Icons.Default.Delete, contentDescription = "Delete", tint = EmergencyRed, modifier = Modifier.size(18.dp))
                        }
                    }
                }
            }
        }
    }

    if (isAdding || editingContact != null) {
        val target = editingContact ?: EmergencyContact(
            id = "contact_${System.currentTimeMillis()}",
            agencyName = "",
            acronym = "",
            primaryNumber = "",
            description = ""
        )

        ContactEditDialog(
            initialContact = target,
            isNew = isAdding,
            onDismiss = {
                isAdding = false
                editingContact = null
            },
            onSave = { updated ->
                onSaveContact(updated)
                isAdding = false
                editingContact = null
            }
        )
    }
}

@Composable
fun ContactEditDialog(
    initialContact: EmergencyContact,
    isNew: Boolean,
    onDismiss: () -> Unit,
    onSave: (EmergencyContact) -> Unit
) {
    var agencyName by remember { mutableStateOf(initialContact.agencyName) }
    var acronym by remember { mutableStateOf(initialContact.acronym) }
    var primaryNumber by remember { mutableStateOf(initialContact.primaryNumber) }
    var description by remember { mutableStateOf(initialContact.description) }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(if (isNew) "Add Emergency Contact" else "Edit Contact", fontWeight = FontWeight.Bold) },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                OutlinedTextField(
                    value = acronym,
                    onValueChange = { acronym = it },
                    label = { Text("Agency Acronym (e.g. PNP, BFP)") },
                    modifier = Modifier.fillMaxWidth()
                )
                OutlinedTextField(
                    value = agencyName,
                    onValueChange = { agencyName = it },
                    label = { Text("Full Agency Name") },
                    modifier = Modifier.fillMaxWidth()
                )
                OutlinedTextField(
                    value = primaryNumber,
                    onValueChange = { primaryNumber = it },
                    label = { Text("Primary Hotline Number") },
                    modifier = Modifier.fillMaxWidth()
                )
                OutlinedTextField(
                    value = description,
                    onValueChange = { description = it },
                    label = { Text("Description & Role") },
                    modifier = Modifier.fillMaxWidth()
                )
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    onSave(
                        initialContact.copy(
                            agencyName = agencyName,
                            acronym = acronym,
                            primaryNumber = primaryNumber,
                            description = description
                        )
                    )
                },
                colors = ButtonDefaults.buttonColors(containerColor = DisasterNavy)
            ) {
                Text("Save")
            }
        },
        dismissButton = {
            OutlinedButton(onClick = onDismiss) { Text("Cancel") }
        }
    )
}

// --- 4. REGIONS MANAGEMENT SECTION ---
@Composable
fun AdminRegionsSection(
    regions: List<PhilippineRegion>,
    onUpdateRegion: (PhilippineRegion) -> Unit
) {
    var editingRegion by remember { mutableStateOf<PhilippineRegion?>(null) }

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .testTag("admin_regions_content"),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        item {
            Text("Regional Emergency Data (17 Regions)", fontWeight = FontWeight.Bold, fontSize = 16.sp, color = DisasterNavy)
            Text("Update official RDRRMC, Regional Police, and Fire hotlines", fontSize = 11.sp, color = Color.Gray)
        }

        items(regions, key = { it.code }) { region ->
            Card(
                shape = RoundedCornerShape(12.dp),
                colors = CardDefaults.cardColors(containerColor = Color.White),
                elevation = CardDefaults.cardElevation(defaultElevation = 1.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(14.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Surface(color = OceanBlue.copy(alpha = 0.15f), shape = RoundedCornerShape(4.dp)) {
                                Text(text = region.code, fontSize = 10.sp, fontWeight = FontWeight.Bold, color = OceanBlue, modifier = Modifier.padding(horizontal = 4.dp, vertical = 2.dp))
                            }
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(text = region.name, fontWeight = FontWeight.Bold, fontSize = 14.sp, color = DisasterNavy)
                        }
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(text = "RDRRMC: ${region.rdrrmcHotline} | PNP: ${region.policeHotline}", fontSize = 11.sp, color = Color.DarkGray)
                        Text(text = region.regionalOffice, fontSize = 10.sp, color = Color.Gray, maxLines = 1)
                    }

                    IconButton(
                        onClick = { editingRegion = region },
                        modifier = Modifier.size(32.dp)
                    ) {
                        Icon(imageVector = Icons.Default.Edit, contentDescription = "Edit", tint = OceanBlue, modifier = Modifier.size(18.dp))
                    }
                }
            }
        }
    }

    if (editingRegion != null) {
        RegionEditDialog(
            region = editingRegion!!,
            onDismiss = { editingRegion = null },
            onSave = { updated ->
                onUpdateRegion(updated)
                editingRegion = null
            }
        )
    }
}

@Composable
fun RegionEditDialog(
    region: PhilippineRegion,
    onDismiss: () -> Unit,
    onSave: (PhilippineRegion) -> Unit
) {
    var rdrrmcHotline by remember { mutableStateOf(region.rdrrmcHotline) }
    var altHotline by remember { mutableStateOf(region.altHotline) }
    var policeHotline by remember { mutableStateOf(region.policeHotline) }
    var fireHotline by remember { mutableStateOf(region.fireHotline) }
    var regionalOffice by remember { mutableStateOf(region.regionalOffice) }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Edit ${region.fullName} Contacts", fontWeight = FontWeight.Bold) },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                OutlinedTextField(
                    value = rdrrmcHotline,
                    onValueChange = { rdrrmcHotline = it },
                    label = { Text("RDRRMC Hotline") },
                    modifier = Modifier.fillMaxWidth()
                )
                OutlinedTextField(
                    value = altHotline,
                    onValueChange = { altHotline = it },
                    label = { Text("Alternate Hotline") },
                    modifier = Modifier.fillMaxWidth()
                )
                OutlinedTextField(
                    value = policeHotline,
                    onValueChange = { policeHotline = it },
                    label = { Text("Regional Police (PRO)") },
                    modifier = Modifier.fillMaxWidth()
                )
                OutlinedTextField(
                    value = fireHotline,
                    onValueChange = { fireHotline = it },
                    label = { Text("Regional BFP Fire Hotline") },
                    modifier = Modifier.fillMaxWidth()
                )
                OutlinedTextField(
                    value = regionalOffice,
                    onValueChange = { regionalOffice = it },
                    label = { Text("Office Address / Location") },
                    modifier = Modifier.fillMaxWidth()
                )
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    onSave(
                        region.copy(
                            rdrrmcHotline = rdrrmcHotline,
                            altHotline = altHotline,
                            policeHotline = policeHotline,
                            fireHotline = fireHotline,
                            regionalOffice = regionalOffice
                        )
                    )
                },
                colors = ButtonDefaults.buttonColors(containerColor = DisasterNavy)
            ) {
                Text("Save")
            }
        },
        dismissButton = {
            OutlinedButton(onClick = onDismiss) { Text("Cancel") }
        }
    )
}

// --- 5. ANNOUNCEMENTS MANAGEMENT SECTION ---
@Composable
fun AdminAnnouncementsSection(
    announcements: List<AnnouncementEntity>,
    onSaveAnnouncement: (AnnouncementEntity) -> Unit,
    onDeleteAnnouncement: (String) -> Unit
) {
    var isAdding by remember { mutableStateOf(false) }

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .testTag("admin_announcements_content"),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Text("Emergency Bulletins (${announcements.size})", fontWeight = FontWeight.Bold, fontSize = 16.sp, color = DisasterNavy)
                    Text("Publish real-time alerts to all citizens", fontSize = 11.sp, color = Color.Gray)
                }

                Button(
                    onClick = { isAdding = true },
                    colors = ButtonDefaults.buttonColors(containerColor = EmergencyRed),
                    shape = RoundedCornerShape(8.dp),
                    contentPadding = PaddingValues(horizontal = 12.dp, vertical = 6.dp),
                    modifier = Modifier.testTag("admin_new_announcement_button")
                ) {
                    Icon(imageVector = Icons.Default.Campaign, contentDescription = null, modifier = Modifier.size(16.dp))
                    Spacer(modifier = Modifier.width(4.dp))
                    Text("Broadcast Alert", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                }
            }
        }

        items(announcements, key = { it.id }) { ann ->
            Card(
                shape = RoundedCornerShape(12.dp),
                colors = CardDefaults.cardColors(containerColor = Color.White),
                elevation = CardDefaults.cardElevation(defaultElevation = 1.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(14.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Surface(
                                color = if (ann.severity == "CRITICAL") EmergencyRed.copy(alpha = 0.15f) else AlertAmber.copy(alpha = 0.15f),
                                shape = RoundedCornerShape(4.dp)
                            ) {
                                Text(
                                    text = ann.category,
                                    fontSize = 10.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = if (ann.severity == "CRITICAL") EmergencyRed else AlertAmber,
                                    modifier = Modifier.padding(horizontal = 4.dp, vertical = 2.dp)
                                )
                            }
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(text = "Region: ${ann.targetRegion}", fontSize = 10.sp, color = Color.Gray)
                        }
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(text = ann.title, fontWeight = FontWeight.Bold, fontSize = 14.sp, color = DisasterNavy)
                        Text(text = ann.message, fontSize = 12.sp, color = Color.DarkGray, maxLines = 2)
                    }

                    IconButton(
                        onClick = { onDeleteAnnouncement(ann.id) },
                        modifier = Modifier.size(32.dp)
                    ) {
                        Icon(imageVector = Icons.Default.Delete, contentDescription = "Delete", tint = EmergencyRed, modifier = Modifier.size(18.dp))
                    }
                }
            }
        }
    }

    if (isAdding) {
        AnnouncementCreateDialog(
            onDismiss = { isAdding = false },
            onSave = { ann ->
                onSaveAnnouncement(ann)
                isAdding = false
            }
        )
    }
}

@Composable
fun AnnouncementCreateDialog(
    onDismiss: () -> Unit,
    onSave: (AnnouncementEntity) -> Unit
) {
    var title by remember { mutableStateOf("") }
    var category by remember { mutableStateOf("TYPHOON ALERT") }
    var message by remember { mutableStateOf("") }
    var severity by remember { mutableStateOf("HIGH") }
    var targetRegion by remember { mutableStateOf("ALL") }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Broadcast Emergency Announcement", fontWeight = FontWeight.Bold) },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                OutlinedTextField(
                    value = title,
                    onValueChange = { title = it },
                    label = { Text("Announcement Headline") },
                    modifier = Modifier.fillMaxWidth()
                )
                OutlinedTextField(
                    value = category,
                    onValueChange = { category = it },
                    label = { Text("Category (e.g. FLOOD WARNING)") },
                    modifier = Modifier.fillMaxWidth()
                )
                OutlinedTextField(
                    value = targetRegion,
                    onValueChange = { targetRegion = it },
                    label = { Text("Target Region (ALL or e.g. NCR)") },
                    modifier = Modifier.fillMaxWidth()
                )
                OutlinedTextField(
                    value = message,
                    onValueChange = { message = it },
                    label = { Text("Detailed Advisory Message") },
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(100.dp)
                )
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    if (title.isNotBlank() && message.isNotBlank()) {
                        onSave(
                            AnnouncementEntity(
                                id = "ann_${System.currentTimeMillis()}",
                                title = title,
                                category = category,
                                message = message,
                                severity = severity,
                                targetRegion = targetRegion
                            )
                        )
                    }
                },
                colors = ButtonDefaults.buttonColors(containerColor = EmergencyRed)
            ) {
                Text("Broadcast Live")
            }
        },
        dismissButton = {
            OutlinedButton(onClick = onDismiss) { Text("Cancel") }
        }
    )
}

// --- 6. FEEDBACK MANAGEMENT SECTION ---
@Composable
fun AdminFeedbackSection(
    feedbackList: List<FeedbackEntity>,
    onUpdateStatus: (String, String) -> Unit,
    onDeleteFeedback: (String) -> Unit
) {
    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .testTag("admin_feedback_content"),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        item {
            Text("Citizen Feedback & Reports (${feedbackList.size})", fontWeight = FontWeight.Bold, fontSize = 16.sp, color = DisasterNavy)
            Text("Review citizen reports, LGU feedback, and field observations", fontSize = 11.sp, color = Color.Gray)
        }

        if (feedbackList.isEmpty()) {
            item {
                Card(
                    shape = RoundedCornerShape(12.dp),
                    colors = CardDefaults.cardColors(containerColor = Color.White),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Text("No user feedback submitted yet.", modifier = Modifier.padding(16.dp), color = Color.Gray)
                }
            }
        } else {
            items(feedbackList, key = { it.id }) { fb ->
                Card(
                    shape = RoundedCornerShape(12.dp),
                    colors = CardDefaults.cardColors(containerColor = Color.White),
                    elevation = CardDefaults.cardElevation(defaultElevation = 1.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(modifier = Modifier.padding(14.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Text(text = fb.userName, fontWeight = FontWeight.Bold, fontSize = 13.sp, color = DisasterNavy)
                                Spacer(modifier = Modifier.width(6.dp))
                                Text(text = "(${fb.disasterTopic})", fontSize = 11.sp, color = Color.Gray)
                            }

                            Surface(
                                color = if (fb.status == "RESOLVED") SafeGreen.copy(alpha = 0.15f) else AlertAmber.copy(alpha = 0.15f),
                                shape = RoundedCornerShape(4.dp)
                            ) {
                                Text(
                                    text = fb.status,
                                    fontSize = 10.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = if (fb.status == "RESOLVED") SafeGreen else AlertAmber,
                                    modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                                )
                            }
                        }

                        Spacer(modifier = Modifier.height(4.dp))
                        Text(text = "Rating: ${"⭐".repeat(fb.rating.coerceIn(1, 5))}", fontSize = 12.sp)
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(text = fb.comments, fontSize = 12.sp, color = Color.DarkGray)

                        Spacer(modifier = Modifier.height(10.dp))

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.End
                        ) {
                            if (fb.status != "RESOLVED") {
                                OutlinedButton(
                                    onClick = { onUpdateStatus(fb.id, "RESOLVED") },
                                    shape = RoundedCornerShape(6.dp),
                                    contentPadding = PaddingValues(horizontal = 8.dp, vertical = 2.dp)
                                ) {
                                    Icon(imageVector = Icons.Default.Check, contentDescription = null, modifier = Modifier.size(12.dp))
                                    Spacer(modifier = Modifier.width(4.dp))
                                    Text("Mark Resolved", fontSize = 11.sp)
                                }
                                Spacer(modifier = Modifier.width(8.dp))
                            }

                            IconButton(
                                onClick = { onDeleteFeedback(fb.id) },
                                modifier = Modifier.size(28.dp)
                            ) {
                                Icon(imageVector = Icons.Default.Delete, contentDescription = "Delete", tint = Color.Gray, modifier = Modifier.size(16.dp))
                            }
                        }
                    }
                }
            }
        }
    }
}

// --- 7. USERS MANAGEMENT SECTION ---
@Composable
fun AdminUsersSection(
    users: List<UserEntity>,
    onToggleRole: (String) -> Unit,
    onDeleteUser: (String) -> Unit
) {
    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .testTag("admin_users_content"),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        item {
            Text("Registered User Accounts (${users.size})", fontWeight = FontWeight.Bold, fontSize = 16.sp, color = DisasterNavy)
            Text("Manage citizen accounts and administrator privileges", fontSize = 11.sp, color = Color.Gray)
        }

        items(users, key = { it.id }) { u ->
            Card(
                shape = RoundedCornerShape(12.dp),
                colors = CardDefaults.cardColors(containerColor = Color.White),
                elevation = CardDefaults.cardElevation(defaultElevation = 1.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(14.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text(text = u.name, fontWeight = FontWeight.Bold, fontSize = 14.sp, color = DisasterNavy)
                            Spacer(modifier = Modifier.width(6.dp))
                            Surface(
                                color = if (u.role == "ADMIN") EmergencyRed.copy(alpha = 0.15f) else SafeGreen.copy(alpha = 0.15f),
                                shape = RoundedCornerShape(4.dp)
                            ) {
                                Text(
                                    text = u.role,
                                    fontSize = 10.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = if (u.role == "ADMIN") EmergencyRed else SafeGreen,
                                    modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                                )
                            }
                        }
                        Text(text = u.email, fontSize = 12.sp, color = Color.Gray)
                        if (u.addressLgu.isNotBlank()) {
                            Text(text = "LGU: ${u.addressLgu}", fontSize = 11.sp, color = Color.DarkGray)
                        }
                    }

                    Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        OutlinedButton(
                            onClick = { onToggleRole(u.id) },
                            shape = RoundedCornerShape(6.dp),
                            contentPadding = PaddingValues(horizontal = 8.dp, vertical = 2.dp)
                        ) {
                            Text(if (u.role == "ADMIN") "Demote" else "Make Admin", fontSize = 11.sp)
                        }

                        if (u.email != "admin@readyai.ph") {
                            IconButton(
                                onClick = { onDeleteUser(u.id) },
                                modifier = Modifier.size(32.dp)
                            ) {
                                Icon(imageVector = Icons.Default.Delete, contentDescription = "Delete", tint = EmergencyRed, modifier = Modifier.size(18.dp))
                            }
                        }
                    }
                }
            }
        }
    }
}

// --- 8. DISASTER ALERTS MANAGEMENT SECTION ---
@Composable
fun AdminAlertsSection(
    alerts: List<DisasterAlertEntity>,
    onSaveAlert: (DisasterAlertEntity) -> Unit,
    onDeleteAlert: (String) -> Unit,
    onBroadcastAlert: (DisasterAlertEntity) -> Unit
) {
    var searchQuery by remember { mutableStateOf("") }
    var severityFilter by remember { mutableStateOf("ALL") }
    var editingAlert by remember { mutableStateOf<DisasterAlertEntity?>(null) }
    var showCreateDialog by remember { mutableStateOf(false) }

    val filteredAlerts = alerts.filter { alert ->
        val matchesSearch = if (searchQuery.isBlank()) true else {
            alert.title.contains(searchQuery, ignoreCase = true) ||
                    alert.disasterType.contains(searchQuery, ignoreCase = true) ||
                    alert.locationCity.contains(searchQuery, ignoreCase = true) ||
                    alert.sourceName.contains(searchQuery, ignoreCase = true)
        }
        val matchesSeverity = if (severityFilter == "ALL") true else alert.severity.equals(severityFilter, ignoreCase = true)
        matchesSearch && matchesSeverity
    }

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .testTag("admin_alerts_content"),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Column {
                    Text(
                        text = "Real-Time Disaster Alerts & Incidents",
                        fontSize = 18.sp,
                        fontWeight = FontWeight.Bold,
                        color = DisasterNavy
                    )
                    Text(
                        text = "Broadcast official advisories for Typhoon, Earthquake, Fire, Flood, Volcano, and Landslide",
                        fontSize = 12.sp,
                        color = Color.Gray
                    )
                }

                Button(
                    onClick = { showCreateDialog = true },
                    colors = ButtonDefaults.buttonColors(containerColor = EmergencyRed),
                    shape = RoundedCornerShape(8.dp),
                    contentPadding = PaddingValues(horizontal = 12.dp, vertical = 6.dp),
                    modifier = Modifier.testTag("admin_add_alert_button")
                ) {
                    Icon(imageVector = Icons.Default.Add, contentDescription = null, modifier = Modifier.size(16.dp))
                    Spacer(modifier = Modifier.width(4.dp))
                    Text("Add Alert", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                }
            }
        }

        // Search & Severity Filter
        item {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedTextField(
                    value = searchQuery,
                    onValueChange = { searchQuery = it },
                    placeholder = { Text("Search alerts by title, city, or source...", fontSize = 13.sp) },
                    leadingIcon = { Icon(Icons.Default.Search, contentDescription = null, modifier = Modifier.size(18.dp)) },
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(10.dp),
                    singleLine = true
                )

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    listOf("ALL" to "All", "CRITICAL" to "Critical", "SERIOUS" to "Serious", "ADVISORY" to "Advisory", "EXPIRED" to "Expired").forEach { (sevKey, label) ->
                        Surface(
                            shape = RoundedCornerShape(6.dp),
                            color = if (severityFilter == sevKey) EmergencyRed else Color.White,
                            border = androidx.compose.foundation.BorderStroke(1.dp, if (severityFilter == sevKey) EmergencyRed else Color.LightGray),
                            modifier = Modifier.clickable { severityFilter = sevKey }
                        ) {
                            Text(
                                text = label,
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Bold,
                                color = if (severityFilter == sevKey) Color.White else DisasterNavy,
                                modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                            )
                        }
                    }
                }
            }
        }

        if (filteredAlerts.isEmpty()) {
            item {
                Card(
                    shape = RoundedCornerShape(10.dp),
                    colors = CardDefaults.cardColors(containerColor = Color.White),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Box(modifier = Modifier.padding(24.dp).fillMaxWidth(), contentAlignment = Alignment.Center) {
                        Text("No disaster alerts found matching search filter.", color = Color.Gray, fontSize = 13.sp)
                    }
                }
            }
        }

        items(filteredAlerts, key = { it.id }) { alert ->
            val sevColor = when (alert.severity) {
                "CRITICAL" -> EmergencyRed
                "SERIOUS" -> Color(0xFFE65100)
                "ADVISORY" -> AlertAmber
                else -> Color.Gray
            }

            Card(
                shape = RoundedCornerShape(12.dp),
                colors = CardDefaults.cardColors(containerColor = Color.White),
                elevation = CardDefaults.cardElevation(defaultElevation = 1.dp),
                border = androidx.compose.foundation.BorderStroke(1.dp, sevColor.copy(alpha = 0.3f)),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(14.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Surface(color = sevColor, shape = RoundedCornerShape(4.dp)) {
                                Text(
                                    text = alert.severity,
                                    fontSize = 9.sp,
                                    fontWeight = FontWeight.Black,
                                    color = Color.White,
                                    modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                                )
                            }
                            Spacer(modifier = Modifier.width(6.dp))
                            Surface(color = Color(0xFFECEFF1), shape = RoundedCornerShape(4.dp)) {
                                Text(
                                    text = DisasterType.formatDisasterTypeEnglish(alert.disasterType),
                                    fontSize = 10.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = DisasterNavy,
                                    modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                                )
                            }
                        }

                        Surface(color = SafeGreen.copy(alpha = 0.15f), shape = RoundedCornerShape(4.dp)) {
                            Text(
                                text = alert.verificationStatus,
                                fontSize = 10.sp,
                                fontWeight = FontWeight.Bold,
                                color = SafeGreen,
                                modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(6.dp))
                    Text(text = alert.title, fontSize = 14.sp, fontWeight = FontWeight.Bold, color = DisasterNavy)
                    Spacer(modifier = Modifier.height(2.dp))
                    Text(text = alert.shortDescription, fontSize = 12.sp, color = Color.DarkGray, maxLines = 2)

                    Spacer(modifier = Modifier.height(4.dp))
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Default.LocationOn, contentDescription = null, tint = OceanBlue, modifier = Modifier.size(13.dp))
                        Spacer(modifier = Modifier.width(4.dp))
                        Text(
                            text = "${alert.locationCity}, ${alert.affectedRegion}",
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Medium,
                            color = Color.Gray
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = "Source: ${alert.sourceName}",
                            fontSize = 11.sp,
                            color = Color.Gray
                        )
                    }

                    Spacer(modifier = Modifier.height(10.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Button(
                            onClick = { onBroadcastAlert(alert) },
                            colors = ButtonDefaults.buttonColors(containerColor = OceanBlue),
                            shape = RoundedCornerShape(6.dp),
                            contentPadding = PaddingValues(horizontal = 8.dp, vertical = 4.dp)
                        ) {
                            Icon(Icons.AutoMirrored.Filled.VolumeUp, contentDescription = null, modifier = Modifier.size(13.dp))
                            Spacer(modifier = Modifier.width(4.dp))
                            Text("Broadcast Alarm", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                        }

                        Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                            OutlinedButton(
                                onClick = { editingAlert = alert },
                                shape = RoundedCornerShape(6.dp),
                                contentPadding = PaddingValues(horizontal = 8.dp, vertical = 2.dp)
                            ) {
                                Icon(Icons.Default.Edit, contentDescription = null, modifier = Modifier.size(13.dp))
                                Spacer(modifier = Modifier.width(4.dp))
                                Text("Edit", fontSize = 11.sp)
                            }

                            IconButton(
                                onClick = { onDeleteAlert(alert.id) },
                                modifier = Modifier.size(32.dp)
                            ) {
                                Icon(Icons.Default.Delete, contentDescription = "Delete", tint = EmergencyRed, modifier = Modifier.size(18.dp))
                            }
                        }
                    }
                }
            }
        }
    }

    // Create / Edit Dialog
    if (showCreateDialog || editingAlert != null) {
        val targetAlert = editingAlert ?: DisasterAlertEntity(
            id = "alert_${System.currentTimeMillis()}",
            disasterType = "Bagyo",
            title = "",
            shortDescription = "",
            detailedInstructions = "",
            locationBarangay = "",
            locationCity = "Quezon City",
            locationProvince = "Metro Manila",
            affectedRegion = "NCR",
            severity = "SERIOUS",
            sourceName = "NDRRMC",
            sourceUrl = "https://ndrrmc.gov.ph",
            verificationStatus = "OFFICIAL BULLETIN"
        )

        AlertEditDialog(
            alert = targetAlert,
            onDismiss = {
                showCreateDialog = false
                editingAlert = null
            },
            onSave = { saved ->
                onSaveAlert(saved)
                showCreateDialog = false
                editingAlert = null
            },
            onSaveAndBroadcast = { saved ->
                onBroadcastAlert(saved)
                showCreateDialog = false
                editingAlert = null
            }
        )
    }
}

@Composable
fun AlertEditDialog(
    alert: DisasterAlertEntity,
    onDismiss: () -> Unit,
    onSave: (DisasterAlertEntity) -> Unit,
    onSaveAndBroadcast: (DisasterAlertEntity) -> Unit
) {
    var disasterType by remember { mutableStateOf(alert.disasterType) }
    var title by remember { mutableStateOf(alert.title) }
    var shortDescription by remember { mutableStateOf(alert.shortDescription) }
    var detailedInstructions by remember { mutableStateOf(alert.detailedInstructions) }
    var locationCity by remember { mutableStateOf(alert.locationCity) }
    var locationBarangay by remember { mutableStateOf(alert.locationBarangay) }
    var affectedRegion by remember { mutableStateOf(alert.affectedRegion) }
    var severity by remember { mutableStateOf(alert.severity) }
    var sourceName by remember { mutableStateOf(alert.sourceName) }
    var sourceUrl by remember { mutableStateOf(alert.sourceUrl) }
    var verificationStatus by remember { mutableStateOf(alert.verificationStatus) }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = {
            Text(if (alert.title.isNotBlank()) "Edit Disaster Alert" else "New Real-Time Disaster Alert", fontWeight = FontWeight.Bold)
        },
        text = {
            LazyColumn(
                modifier = Modifier.fillMaxWidth(),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                item {
                    Text("Disaster Type:", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(4.dp)
                    ) {
                        listOf(
                            "Typhoon" to "Typhoon",
                            "Earthquake" to "Earthquake",
                            "Fire" to "Fire",
                            "Flood" to "Flood",
                            "Volcano" to "Volcano",
                            "Landslide" to "Landslide"
                        ).forEach { (typeKey, typeLabel) ->
                            val isSelected = disasterType.equals(typeKey, ignoreCase = true)
                            Surface(
                                shape = RoundedCornerShape(6.dp),
                                color = if (isSelected) EmergencyRed else Color(0xFFEEEEEE),
                                modifier = Modifier.clickable { disasterType = typeKey }
                            ) {
                                Text(
                                    text = typeLabel,
                                    fontSize = 10.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = if (isSelected) Color.White else Color.Black,
                                    modifier = Modifier.padding(horizontal = 6.dp, vertical = 4.dp)
                                )
                            }
                        }
                    }
                }

                item {
                    Text("Severity Level:", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(4.dp)
                    ) {
                        listOf("CRITICAL", "SERIOUS", "ADVISORY", "EXPIRED").forEach { sev ->
                            Surface(
                                shape = RoundedCornerShape(6.dp),
                                color = if (severity == sev) DisasterNavy else Color(0xFFEEEEEE),
                                modifier = Modifier.clickable { severity = sev }
                            ) {
                                Text(
                                    text = sev,
                                    fontSize = 10.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = if (severity == sev) Color.White else Color.Black,
                                    modifier = Modifier.padding(horizontal = 6.dp, vertical = 4.dp)
                                )
                            }
                        }
                    }
                }

                item {
                    OutlinedTextField(
                        value = title,
                        onValueChange = { title = it },
                        label = { Text("Alert Title") },
                        modifier = Modifier.fillMaxWidth(),
                        singleLine = true
                    )
                }

                item {
                    OutlinedTextField(
                        value = shortDescription,
                        onValueChange = { shortDescription = it },
                        label = { Text("Short Description") },
                        modifier = Modifier.fillMaxWidth(),
                        minLines = 2
                    )
                }

                item {
                    OutlinedTextField(
                        value = detailedInstructions,
                        onValueChange = { detailedInstructions = it },
                        label = { Text("Official Safety Actions / Detailed Guidance") },
                        modifier = Modifier.fillMaxWidth(),
                        minLines = 2
                    )
                }

                item {
                    Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        OutlinedTextField(
                            value = locationCity,
                            onValueChange = { locationCity = it },
                            label = { Text("City / Town") },
                            modifier = Modifier.weight(1f)
                        )
                        OutlinedTextField(
                            value = affectedRegion,
                            onValueChange = { affectedRegion = it },
                            label = { Text("Region (e.g. NCR)") },
                            modifier = Modifier.weight(1f)
                        )
                    }
                }

                item {
                    OutlinedTextField(
                        value = locationBarangay,
                        onValueChange = { locationBarangay = it },
                        label = { Text("Barangay / Street Location") },
                        modifier = Modifier.fillMaxWidth()
                    )
                }

                item {
                    Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        OutlinedTextField(
                            value = sourceName,
                            onValueChange = { sourceName = it },
                            label = { Text("Source Agency (e.g. TXT FIRE / PAGASA)") },
                            modifier = Modifier.weight(1f)
                        )
                        OutlinedTextField(
                            value = verificationStatus,
                            onValueChange = { verificationStatus = it },
                            label = { Text("Status (e.g. VERIFIED)") },
                            modifier = Modifier.weight(1f)
                        )
                    }
                }

                item {
                    OutlinedTextField(
                        value = sourceUrl,
                        onValueChange = { sourceUrl = it },
                        label = { Text("Source Link / URL") },
                        modifier = Modifier.fillMaxWidth()
                    )
                }
            }
        },
        confirmButton = {
            Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                Button(
                    onClick = {
                        val updated = alert.copy(
                            disasterType = disasterType,
                            title = title,
                            shortDescription = shortDescription,
                            detailedInstructions = detailedInstructions,
                            locationCity = locationCity,
                            locationBarangay = locationBarangay,
                            affectedRegion = affectedRegion,
                            severity = severity,
                            sourceName = sourceName,
                            sourceUrl = sourceUrl,
                            verificationStatus = verificationStatus,
                            latestUpdateTime = System.currentTimeMillis()
                        )
                        onSave(updated)
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = DisasterNavy)
                ) {
                    Text("Save")
                }

                Button(
                    onClick = {
                        val updated = alert.copy(
                            disasterType = disasterType,
                            title = title,
                            shortDescription = shortDescription,
                            detailedInstructions = detailedInstructions,
                            locationCity = locationCity,
                            locationBarangay = locationBarangay,
                            affectedRegion = affectedRegion,
                            severity = severity,
                            sourceName = sourceName,
                            sourceUrl = sourceUrl,
                            verificationStatus = verificationStatus,
                            latestUpdateTime = System.currentTimeMillis()
                        )
                        onSaveAndBroadcast(updated)
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = EmergencyRed)
                ) {
                    Text("Save & Alarm")
                }
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) {
                Text("Cancel")
            }
        }
    )
}
