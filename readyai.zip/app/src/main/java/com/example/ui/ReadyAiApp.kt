package com.example.ui

import androidx.activity.compose.BackHandler
import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AdminPanelSettings
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.Campaign
import androidx.compose.material.icons.filled.Checklist
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.Phone
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material.icons.outlined.AutoAwesome
import androidx.compose.material.icons.outlined.Checklist
import androidx.compose.material.icons.outlined.Home
import androidx.compose.material.icons.outlined.Person
import androidx.compose.material.icons.outlined.Phone
import androidx.compose.material.icons.outlined.Warning
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationBarItemDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.admin.AdminDashboardScreen
import com.example.ui.components.Call911Dialog
import com.example.ui.components.TopEmergencyHeader
import com.example.ui.screens.AiAssistantScreen
import com.example.ui.screens.AnnouncementsScreen
import com.example.ui.screens.AuthScreen
import com.example.ui.screens.CategoriesScreen
import com.example.ui.screens.CategoryDetailScreen
import com.example.ui.screens.ChecklistScreen
import com.example.ui.screens.ContactsScreen
import com.example.ui.screens.DisasterNotificationCenterScreen
import com.example.ui.screens.FeedbackScreen
import com.example.ui.screens.HomeScreen
import com.example.ui.screens.ProfileScreen
import com.example.ui.theme.AlertAmber
import com.example.ui.theme.DisasterNavy
import com.example.ui.theme.EmergencyRed

@Composable
fun ReadyAiApp(viewModel: ReadyAiViewModel) {
    val uiState by viewModel.uiState.collectAsState()
    val guides by viewModel.guides.collectAsState()
    val contacts by viewModel.contacts.collectAsState()
    val regionalContacts by viewModel.regionalContacts.collectAsState()
    val announcements by viewModel.announcements.collectAsState()
    val alerts by viewModel.alerts.collectAsState()
    val unreadAlertsCount by viewModel.unreadAlertsCount.collectAsState()
    val feedbackList by viewModel.feedbackList.collectAsState()
    val users by viewModel.users.collectAsState()
    val userCount by viewModel.userCount.collectAsState()
    val userChecklist by viewModel.userChecklist.collectAsState()

    val snackbarHostState = remember { SnackbarHostState() }

    LaunchedEffect(uiState.statusMessage) {
        uiState.statusMessage?.let { msg ->
            snackbarHostState.showSnackbar(msg)
            viewModel.clearStatusMessage()
        }
    }

    // Handle system back navigation
    BackHandler(enabled = uiState.currentScreen != AppScreen.HOME || uiState.selectedCategory != null) {
        viewModel.navigateBack()
    }

    // If currently on Admin Dashboard, render full-screen Admin Interface
    if (uiState.currentScreen == AppScreen.ADMIN_DASHBOARD) {
        AdminDashboardScreen(
            currentTab = uiState.adminCurrentTab,
            onTabSelected = { tab -> viewModel.setAdminTab(tab) },
            onExitToUserUi = { viewModel.navigateTo(AppScreen.HOME) },
            totalUsers = userCount,
            usersList = users,
            guidesList = guides,
            contactsList = contacts,
            regionsList = regionalContacts,
            announcementsList = announcements,
            feedbackList = feedbackList,
            alertsList = alerts,
            onSaveGuide = { guide -> viewModel.saveGuide(guide) },
            onDeleteGuide = { id -> viewModel.deleteGuide(id) },
            onSaveContact = { contact -> viewModel.saveContact(contact) },
            onDeleteContact = { id -> viewModel.deleteContact(id) },
            onUpdateRegion = { region -> viewModel.updateRegionalContact(region) },
            onSaveAnnouncement = { ann -> viewModel.saveAnnouncement(ann) },
            onDeleteAnnouncement = { id -> viewModel.deleteAnnouncement(id) },
            onUpdateFeedbackStatus = { id, status -> viewModel.updateFeedbackStatus(id, status) },
            onDeleteFeedback = { id -> viewModel.deleteFeedback(id) },
            onToggleUserRole = { userId -> viewModel.toggleUserRole(userId) },
            onDeleteUser = { userId -> viewModel.deleteUser(userId) },
            onSaveAlert = { alert -> viewModel.saveAlert(alert) },
            onDeleteAlert = { id -> viewModel.deleteAlert(id) },
            onBroadcastAlert = { alert -> viewModel.broadcastAlert(alert) }
        )
        return
    }

    Scaffold(
        modifier = Modifier.fillMaxSize(),
        snackbarHost = { SnackbarHost(snackbarHostState) },
        topBar = {
            if (uiState.currentScreen != AppScreen.AUTH) {
                val title = when (uiState.currentScreen) {
                    AppScreen.HOME -> "ReadyAI"
                    AppScreen.DISASTER_ALERTS -> "Disaster Alerts"
                    AppScreen.CATEGORIES -> "Disaster Guides"
                    AppScreen.CATEGORY_DETAIL -> uiState.selectedCategory?.title ?: "Disaster Guide"
                    AppScreen.CONTACTS -> "Emergency Contacts"
                    AppScreen.CHECKLIST -> "Survival Go Bag"
                    AppScreen.ASSISTANT -> "AI Emergency Assistant"
                    AppScreen.ANNOUNCEMENTS -> "Announcements"
                    AppScreen.FEEDBACK -> "Citizen Feedback"
                    AppScreen.PROFILE -> "User Profile"
                    else -> "ReadyAI"
                }

                val subtitle = when (uiState.currentScreen) {
                    AppScreen.HOME -> "Your AI Emergency & Disaster Assistant"
                    AppScreen.DISASTER_ALERTS -> "Real-Time Emergency Alerts & Feeds (${alerts.size} active)"
                    AppScreen.CATEGORIES -> "Official Safety Guides (${guides.size} Disasters)"
                    AppScreen.CATEGORY_DETAIL -> uiState.selectedCategory?.agencyInCharge ?: "Official Safety Guidance"
                    AppScreen.CONTACTS -> "National & Regional 24/7 Hotlines"
                    AppScreen.CHECKLIST -> "72-Hour Preparedness Checklist"
                    AppScreen.ASSISTANT -> "Immediate practical safety advice"
                    AppScreen.ANNOUNCEMENTS -> "Official Alerts & Advisories"
                    AppScreen.FEEDBACK -> "Report issues & suggest hotlines"
                    AppScreen.PROFILE -> "Logged in as ${uiState.currentUser?.name ?: "Citizen"}"
                    else -> "Emergency & Disaster Assistance"
                }

                TopEmergencyHeader(
                    title = title,
                    subtitle = subtitle,
                    showBackButton = uiState.currentScreen == AppScreen.CATEGORY_DETAIL ||
                            uiState.currentScreen == AppScreen.DISASTER_ALERTS ||
                            (uiState.currentScreen != AppScreen.HOME && uiState.screenStack.size > 1),
                    onBackClick = { viewModel.navigateBack() },
                    onCall911Click = { viewModel.showCall911Dialog(true) },
                    isSirenActive = uiState.isSirenPlaying,
                    onToggleSiren = { viewModel.toggleEmergencySiren() },
                    unreadAlertsCount = unreadAlertsCount,
                    onNotificationClick = { viewModel.navigateTo(AppScreen.DISASTER_ALERTS) }
                )
            }
        },
        bottomBar = {
            if (uiState.currentScreen != AppScreen.AUTH) {
                ReadyAiBottomBar(
                    currentScreen = uiState.currentScreen,
                    isAdmin = uiState.currentUser?.role == "ADMIN",
                    onNavigate = { screen -> viewModel.navigateTo(screen) }
                )
            }
        }
    ) { innerPadding ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
        ) {
            AnimatedContent(
                targetState = uiState.currentScreen,
                transitionSpec = { fadeIn() togetherWith fadeOut() },
                label = "screen_transition"
            ) { targetScreen ->
                when (targetScreen) {
                    AppScreen.HOME -> {
                        HomeScreen(
                            categories = guides,
                            currentUser = uiState.currentUser,
                            alerts = alerts,
                            unreadAlertsCount = unreadAlertsCount,
                            userCityName = uiState.userCityName,
                            onNavigateTo = { screen -> viewModel.navigateTo(screen) },
                            onSelectCategory = { cat -> viewModel.selectCategory(cat) },
                            onSelectAlert = { alert -> viewModel.selectAlertForDetail(alert) },
                            onCall911 = { viewModel.showCall911Dialog(true) },
                            isSirenActive = uiState.isSirenPlaying,
                            onToggleSiren = { viewModel.toggleEmergencySiren() }
                        )
                    }

                    AppScreen.DISASTER_ALERTS -> {
                        DisasterNotificationCenterScreen(
                            alerts = alerts,
                            unreadCount = unreadAlertsCount,
                            selectedTypeFilter = uiState.alertTypeFilter,
                            selectedSeverityFilter = uiState.alertSeverityFilter,
                            selectedLocationFilter = uiState.alertLocationFilter,
                            onlyNearby = uiState.onlyNearbyAlerts,
                            searchQuery = uiState.alertSearchQuery,
                            userCityName = uiState.userCityName,
                            userLatitude = uiState.userLatitude,
                            userLongitude = uiState.userLongitude,
                            isSoundAlertsEnabled = uiState.isSoundAlertsEnabled,
                            selectedAlertForDetail = uiState.selectedAlertForDetail,
                            onSetTypeFilter = { type -> viewModel.setAlertTypeFilter(type) },
                            onSetSeverityFilter = { sev -> viewModel.setAlertSeverityFilter(sev) },
                            onSetLocationFilter = { loc -> viewModel.setAlertLocationFilter(loc) },
                            onSetOnlyNearby = { nearby -> viewModel.setOnlyNearbyAlerts(nearby) },
                            onSetSearchQuery = { query -> viewModel.setAlertSearchQuery(query) },
                            onSelectAlertForDetail = { alert -> viewModel.selectAlertForDetail(alert) },
                            onMarkAsRead = { id -> viewModel.markAlertAsRead(id) },
                            onMarkAllAsRead = { viewModel.markAllAlertsAsRead() },
                            onSetSoundAlertsEnabled = { enabled -> viewModel.setSoundAlertsEnabled(enabled) },
                            onPreviewSound = { viewModel.previewAlertSound() },
                            onUpdateLocation = { lat, lng, city -> viewModel.setUserLocation(lat, lng, city) },
                            onCall911 = { viewModel.showCall911Dialog(true) }
                        )
                    }

                    AppScreen.CATEGORIES -> {
                        CategoriesScreen(
                            categories = guides,
                            onSelectCategory = { cat -> viewModel.selectCategory(cat) },
                            onCall911 = { viewModel.showCall911Dialog(true) }
                        )
                    }

                    AppScreen.CATEGORY_DETAIL -> {
                        uiState.selectedCategory?.let { category ->
                            CategoryDetailScreen(
                                category = category,
                                onBack = { viewModel.navigateBack() },
                                onCall911 = { viewModel.showCall911Dialog(true) },
                                onAskAi = { prompt ->
                                    viewModel.navigateTo(AppScreen.ASSISTANT)
                                    viewModel.sendMessage(prompt)
                                }
                            )
                        } ?: run {
                            CategoriesScreen(
                                categories = guides,
                                onSelectCategory = { cat -> viewModel.selectCategory(cat) },
                                onCall911 = { viewModel.showCall911Dialog(true) }
                            )
                        }
                    }

                    AppScreen.CONTACTS -> {
                        ContactsScreen(
                            contacts = contacts,
                            regions = regionalContacts,
                            selectedRegionCode = uiState.selectedRegionCode,
                            onSelectRegion = { code -> viewModel.selectRegion(code) },
                            onCall911 = { viewModel.showCall911Dialog(true) }
                        )
                    }

                    AppScreen.CHECKLIST -> {
                        ChecklistScreen(
                            checklist = userChecklist,
                            onToggleItem = { id -> viewModel.toggleChecklistItem(id) },
                            onReset = { viewModel.resetChecklist() },
                            onToggleAll = { checkAll -> viewModel.toggleAllChecklist(checkAll) }
                        )
                    }

                    AppScreen.ASSISTANT -> {
                        AiAssistantScreen(
                            messages = uiState.chatMessages,
                            isThinking = uiState.isAiThinking,
                            onSendMessage = { text -> viewModel.sendMessage(text) },
                            onCall911 = { viewModel.showCall911Dialog(true) }
                        )
                    }

                    AppScreen.ANNOUNCEMENTS -> {
                        AnnouncementsScreen(
                            announcements = announcements,
                            onCall911 = { viewModel.showCall911Dialog(true) }
                        )
                    }

                    AppScreen.FEEDBACK -> {
                        FeedbackScreen(
                            onSubmitFeedback = { topic, rating, comments, onSuccess ->
                                viewModel.submitFeedback(topic, rating, comments, onSuccess)
                            }
                        )
                    }

                    AppScreen.PROFILE -> {
                        ProfileScreen(
                            user = uiState.currentUser,
                            onUpdateProfile = { name, phone, address, onSuccess ->
                                viewModel.updateProfile(name, phone, address, onSuccess)
                            },
                            onLogout = { viewModel.logout() },
                            onOpenAdminDashboard = { viewModel.navigateTo(AppScreen.ADMIN_DASHBOARD) },
                            onNavigateToAuth = { viewModel.navigateTo(AppScreen.AUTH) }
                        )
                    }

                    AppScreen.AUTH -> {
                        AuthScreen(
                            onLogin = { email, pass, onSucc, onErr ->
                                viewModel.login(email, pass, onSucc, onErr)
                            },
                            onRegister = { name, email, pass, role, onSucc, onErr ->
                                viewModel.register(name, email, pass, role, onSucc, onErr)
                            },
                            onQuickSwitch = { user ->
                                viewModel.quickSwitchUser(user)
                            },
                            onGoogleSignInSuccess = { user ->
                                viewModel.loginWithGoogle(user)
                            },
                            existingUsers = users
                        )
                    }

                    AppScreen.ADMIN_DASHBOARD -> {
                        // Handled above
                    }
                }
            }
        }
    }

    if (uiState.showCall911Dialog) {
        Call911Dialog(onDismissRequest = { viewModel.showCall911Dialog(false) })
    }
}

@Composable
fun ReadyAiBottomBar(
    currentScreen: AppScreen,
    isAdmin: Boolean,
    onNavigate: (AppScreen) -> Unit
) {
    NavigationBar(
        containerColor = MaterialTheme.colorScheme.surface,
        tonalElevation = 6.dp,
        modifier = Modifier.testTag("readyai_bottom_bar")
    ) {
        // 1. Home
        NavigationBarItem(
            selected = currentScreen == AppScreen.HOME,
            onClick = { onNavigate(AppScreen.HOME) },
            icon = {
                Icon(
                    imageVector = if (currentScreen == AppScreen.HOME) Icons.Default.Home else Icons.Outlined.Home,
                    contentDescription = "Home"
                )
            },
            label = { Text("Home", fontSize = 10.sp, fontWeight = FontWeight.Bold) },
            colors = NavigationBarItemDefaults.colors(
                selectedIconColor = EmergencyRed,
                selectedTextColor = EmergencyRed,
                indicatorColor = EmergencyRed.copy(alpha = 0.15f)
            ),
            modifier = Modifier.testTag("nav_item_home")
        )

        // 2. Disasters / Guides
        NavigationBarItem(
            selected = currentScreen == AppScreen.CATEGORIES || currentScreen == AppScreen.CATEGORY_DETAIL,
            onClick = { onNavigate(AppScreen.CATEGORIES) },
            icon = {
                Icon(
                    imageVector = if (currentScreen == AppScreen.CATEGORIES || currentScreen == AppScreen.CATEGORY_DETAIL)
                        Icons.Default.Warning else Icons.Outlined.Warning,
                    contentDescription = "Guides"
                )
            },
            label = { Text("Guides", fontSize = 10.sp, fontWeight = FontWeight.Bold) },
            colors = NavigationBarItemDefaults.colors(
                selectedIconColor = EmergencyRed,
                selectedTextColor = EmergencyRed,
                indicatorColor = EmergencyRed.copy(alpha = 0.15f)
            ),
            modifier = Modifier.testTag("nav_item_disasters")
        )

        // 3. Hotlines / Contacts
        NavigationBarItem(
            selected = currentScreen == AppScreen.CONTACTS,
            onClick = { onNavigate(AppScreen.CONTACTS) },
            icon = {
                Icon(
                    imageVector = if (currentScreen == AppScreen.CONTACTS) Icons.Default.Phone else Icons.Outlined.Phone,
                    contentDescription = "Hotlines"
                )
            },
            label = { Text("Hotlines", fontSize = 10.sp, fontWeight = FontWeight.Bold) },
            colors = NavigationBarItemDefaults.colors(
                selectedIconColor = EmergencyRed,
                selectedTextColor = EmergencyRed,
                indicatorColor = EmergencyRed.copy(alpha = 0.15f)
            ),
            modifier = Modifier.testTag("nav_item_contacts")
        )

        // 4. Go Bag Checklist
        NavigationBarItem(
            selected = currentScreen == AppScreen.CHECKLIST,
            onClick = { onNavigate(AppScreen.CHECKLIST) },
            icon = {
                Icon(
                    imageVector = if (currentScreen == AppScreen.CHECKLIST) Icons.Default.Checklist else Icons.Outlined.Checklist,
                    contentDescription = "Go Bag"
                )
            },
            label = { Text("Go Bag", fontSize = 10.sp, fontWeight = FontWeight.Bold) },
            colors = NavigationBarItemDefaults.colors(
                selectedIconColor = EmergencyRed,
                selectedTextColor = EmergencyRed,
                indicatorColor = EmergencyRed.copy(alpha = 0.15f)
            ),
            modifier = Modifier.testTag("nav_item_checklist")
        )

        // 5. AI Assistant
        NavigationBarItem(
            selected = currentScreen == AppScreen.ASSISTANT,
            onClick = { onNavigate(AppScreen.ASSISTANT) },
            icon = {
                Icon(
                    imageVector = if (currentScreen == AppScreen.ASSISTANT) Icons.Default.AutoAwesome else Icons.Outlined.AutoAwesome,
                    contentDescription = "ReadyAI"
                )
            },
            label = { Text("ReadyAI", fontSize = 10.sp, fontWeight = FontWeight.Bold) },
            colors = NavigationBarItemDefaults.colors(
                selectedIconColor = AlertAmber,
                selectedTextColor = AlertAmber,
                indicatorColor = AlertAmber.copy(alpha = 0.15f)
            ),
            modifier = Modifier.testTag("nav_item_assistant")
        )

        // 6. User Profile or Admin
        NavigationBarItem(
            selected = currentScreen == AppScreen.PROFILE || currentScreen == AppScreen.AUTH,
            onClick = { onNavigate(AppScreen.PROFILE) },
            icon = {
                Icon(
                    imageVector = if (isAdmin) Icons.Default.AdminPanelSettings else if (currentScreen == AppScreen.PROFILE) Icons.Default.Person else Icons.Outlined.Person,
                    contentDescription = "Profile"
                )
            },
            label = { Text(if (isAdmin) "Admin" else "Profile", fontSize = 10.sp, fontWeight = FontWeight.Bold) },
            colors = NavigationBarItemDefaults.colors(
                selectedIconColor = if (isAdmin) EmergencyRed else DisasterNavy,
                selectedTextColor = if (isAdmin) EmergencyRed else DisasterNavy,
                indicatorColor = (if (isAdmin) EmergencyRed else DisasterNavy).copy(alpha = 0.15f)
            ),
            modifier = Modifier.testTag("nav_item_profile")
        )
    }
}
