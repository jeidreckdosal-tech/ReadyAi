package com.example.ui

import android.app.Application
import android.content.Context
import android.media.AudioAttributes
import android.media.AudioFormat
import android.media.AudioTrack
import android.os.Build
import android.os.VibrationEffect
import android.os.Vibrator
import android.os.VibratorManager
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.GeminiService
import com.example.data.local.AnnouncementEntity
import com.example.data.local.DisasterAlertEntity
import com.example.data.local.FeedbackEntity
import com.example.data.local.ReadyAiLocalRepository
import com.example.data.local.UserEntity
import com.example.data.model.ChecklistItem
import com.example.data.model.ChatMessage
import com.example.data.model.EmergencyCategory
import com.example.data.model.EmergencyContact
import com.example.data.model.PhilippineRegion
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import com.google.firebase.Firebase
import com.google.firebase.auth.auth
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.auth.FirebaseUser
import com.example.data.firebase.ReadyAiFirestoreRepository
import com.example.data.firebase.FirestoreUserProfile
import com.example.data.firebase.FirestoreChecklistItem
import com.example.data.firebase.FirestoreFeedback
import java.util.UUID

enum class AppScreen {
    HOME,
    CATEGORIES,
    CATEGORY_DETAIL,
    CONTACTS,
    CHECKLIST,
    ASSISTANT,
    ANNOUNCEMENTS,
    DISASTER_ALERTS,
    FEEDBACK,
    PROFILE,
    ADMIN_DASHBOARD,
    AUTH
}

enum class AdminTab {
    OVERVIEW,
    ALERTS,
    GUIDES,
    CONTACTS,
    REGIONS,
    ANNOUNCEMENTS,
    FEEDBACK,
    USERS
}

data class ReadyAiUiState(
    val currentScreen: AppScreen = AppScreen.HOME,
    val screenStack: List<AppScreen> = listOf(AppScreen.HOME),
    val selectedCategory: EmergencyCategory? = null,
    val selectedRegionCode: String = "NCR",
    val currentUser: UserEntity? = null,
    val isAiThinking: Boolean = false,
    val chatMessages: List<ChatMessage> = emptyList(),
    val showCall911Dialog: Boolean = false,
    val isSirenPlaying: Boolean = false,
    val regionSearchQuery: String = "",
    val adminCurrentTab: AdminTab = AdminTab.OVERVIEW,
    val statusMessage: String? = null,
    // Disaster Alerts & Location States
    val userLatitude: Double = 14.6349, // Quezon City, Metro Manila
    val userLongitude: Double = 121.0028,
    val userCityName: String = "Quezon City, NCR",
    val isSoundAlertsEnabled: Boolean = true,
    val alertTypeFilter: String = "ALL", // "ALL", "Bagyo", "Lindol", "Sunog", "Baha", "Volcano", "Landslide", "Other"
    val alertSeverityFilter: String = "ALL", // "ALL", "CRITICAL", "SERIOUS", "ADVISORY", "EXPIRED"
    val alertLocationFilter: String = "ALL",
    val onlyNearbyAlerts: Boolean = false,
    val alertSearchQuery: String = "",
    val selectedAlertForDetail: DisasterAlertEntity? = null
)

class ReadyAiViewModel(application: Application) : AndroidViewModel(application) {

    val repository = ReadyAiLocalRepository(application)
    val firestoreRepository = ReadyAiFirestoreRepository(application)
    private val prefs = application.getSharedPreferences("readyai_prefs", Context.MODE_PRIVATE)

    private val _uiState = MutableStateFlow(
        ReadyAiUiState(
            isSoundAlertsEnabled = application.getSharedPreferences("readyai_prefs", Context.MODE_PRIVATE)
                .getBoolean("sound_alerts_enabled", true)
        )
    )
    val uiState: StateFlow<ReadyAiUiState> = _uiState.asStateFlow()

    // Reactive database flows
    val guides: StateFlow<List<EmergencyCategory>> = repository.getGuidesFlow()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val contacts: StateFlow<List<EmergencyContact>> = repository.getContactsFlow()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val regionalContacts: StateFlow<List<PhilippineRegion>> = repository.getRegionalContactsFlow()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val announcements: StateFlow<List<AnnouncementEntity>> = repository.getAnnouncementsFlow()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val alerts: StateFlow<List<DisasterAlertEntity>> = repository.getAllAlertsFlow()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val unreadAlertsCount: StateFlow<Int> = repository.getUnreadAlertCountFlow()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), 0)

    val feedbackList: StateFlow<List<FeedbackEntity>> = repository.getFeedbackFlow()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val users: StateFlow<List<UserEntity>> = repository.getAllUsers()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val userCount: StateFlow<Int> = repository.getUserCount()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), 0)

    private val _userChecklist = MutableStateFlow<List<ChecklistItem>>(emptyList())
    val userChecklist: StateFlow<List<ChecklistItem>> = _userChecklist.asStateFlow()

    private var sirenJob: Job? = null
    private var audioTrack: AudioTrack? = null

    init {
        initializeChat()
        // Auto-login to default citizen demo account if no user is active
        viewModelScope.launch {
            val lastUserId = prefs.getString("last_active_user_id", null)
            val allUsers = repository.getAllUsers()
            allUsers.collect { userList ->
                if (_uiState.value.currentUser == null && userList.isNotEmpty()) {
                    val matching = userList.firstOrNull { it.id == lastUserId } ?: userList.firstOrNull { it.role == "USER" } ?: userList.first()
                    _uiState.update { it.copy(currentUser = matching) }
                    loadChecklistForUser(matching.id)
                }
            }
        }
    }

    private fun loadChecklistForUser(userId: String) {
        viewModelScope.launch {
            repository.getUserChecklistFlow(userId).collect { list ->
                _userChecklist.value = list
            }
        }
    }

    private fun initializeChat() {
        val welcomeMessage = ChatMessage(
            id = "welcome_msg",
            text = "Kumusta! I am ReadyAI, your emergency and disaster assistant in the Philippines 🇵🇭.\n\n" +
                    "Ask me what to do during typhoons, floods, earthquakes, fires, landslides, volcanic eruptions, or power outages.\n\n" +
                    "⚠️ SAFETY NOTICE: ReadyAI provides general safety guidance only and cannot replace professional rescuers or medical staff. For life-threatening emergencies, immediately CALL 911.",
            isUser = false
        )
        _uiState.update { it.copy(chatMessages = listOf(welcomeMessage)) }
    }

    // --- Navigation ---
    fun navigateTo(screen: AppScreen) {
        // Role-based protection: non-admins cannot enter ADMIN_DASHBOARD
        if (screen == AppScreen.ADMIN_DASHBOARD && _uiState.value.currentUser?.role != "ADMIN") {
            _uiState.update { it.copy(statusMessage = "Access Denied: Admin privileges required.") }
            return
        }

        _uiState.update { state ->
            val newStack = state.screenStack + screen
            state.copy(currentScreen = screen, screenStack = newStack)
        }
    }

    fun navigateBack(): Boolean {
        var handled = false
        _uiState.update { state ->
            if (state.selectedCategory != null && state.currentScreen == AppScreen.CATEGORY_DETAIL) {
                handled = true
                state.copy(
                    selectedCategory = null,
                    currentScreen = AppScreen.CATEGORIES
                )
            } else if (state.screenStack.size > 1) {
                handled = true
                val newStack = state.screenStack.dropLast(1)
                state.copy(
                    currentScreen = newStack.last(),
                    screenStack = newStack
                )
            } else if (state.currentScreen != AppScreen.HOME) {
                handled = true
                state.copy(
                    currentScreen = AppScreen.HOME,
                    screenStack = listOf(AppScreen.HOME)
                )
            } else {
                state
            }
        }
        return handled
    }

    fun setAdminTab(tab: AdminTab) {
        _uiState.update { it.copy(adminCurrentTab = tab) }
    }

    fun selectCategory(category: EmergencyCategory) {
        _uiState.update {
            it.copy(
                selectedCategory = category,
                currentScreen = AppScreen.CATEGORY_DETAIL,
                screenStack = it.screenStack + AppScreen.CATEGORY_DETAIL
            )
        }
    }

    fun selectRegion(regionCode: String) {
        _uiState.update { it.copy(selectedRegionCode = regionCode) }
    }

    fun setRegionSearch(query: String) {
        _uiState.update { it.copy(regionSearchQuery = query) }
    }

    fun clearStatusMessage() {
        _uiState.update { it.copy(statusMessage = null) }
    }

    // --- Authentication Operations ---
    fun login(email: String, pass: String, onSuccess: () -> Unit, onError: (String) -> Unit) {
        viewModelScope.launch {
            val result = repository.loginUser(email, pass)
            result.onSuccess { user ->
                prefs.edit().putString("last_active_user_id", user.id).apply()
                _uiState.update {
                    it.copy(
                        currentUser = user,
                        currentScreen = if (user.role == "ADMIN") AppScreen.ADMIN_DASHBOARD else AppScreen.HOME,
                        statusMessage = "Welcome, ${user.name}!"
                    )
                }
                loadChecklistForUser(user.id)
                onSuccess()
            }.onFailure { error ->
                onError(error.localizedMessage ?: "Login failed")
            }
        }
    }

    fun register(name: String, email: String, pass: String, role: String, onSuccess: () -> Unit, onError: (String) -> Unit) {
        viewModelScope.launch {
            val result = repository.registerUser(name, email, pass, role)
            result.onSuccess { user ->
                prefs.edit().putString("last_active_user_id", user.id).apply()
                _uiState.update {
                    it.copy(
                        currentUser = user,
                        currentScreen = if (user.role == "ADMIN") AppScreen.ADMIN_DASHBOARD else AppScreen.HOME,
                        statusMessage = "Account registered successfully!"
                    )
                }
                loadChecklistForUser(user.id)
                onSuccess()
            }.onFailure { error ->
                onError(error.localizedMessage ?: "Registration failed")
            }
        }
    }

    fun loginWithGoogle(firebaseUser: FirebaseUser) {
        viewModelScope.launch {
            val uid = firebaseUser.uid
            val email = firebaseUser.email ?: "citizen@readyai.ph"
            val name = firebaseUser.displayName?.ifBlank { "Citizen User" } ?: "Citizen User"
            val phone = firebaseUser.phoneNumber ?: ""

            // Sync User Profile to Cloud Firestore
            val profile = FirestoreUserProfile(
                userId = uid,
                email = email,
                displayName = name,
                phone = phone,
                regionCode = _uiState.value.selectedRegionCode
            )
            firestoreRepository.saveUserProfile(profile)

            // Save to local database for seamless offline resilience
            val userEntity = UserEntity(
                id = uid,
                name = name,
                email = email,
                passwordHash = "google_auth_token",
                role = if (email == "jeidreck.dosal@college.cksc.edu.ph" || email.contains("admin")) "ADMIN" else "USER",
                contactPhone = phone,
                addressLgu = _uiState.value.userCityName
            )
            repository.insertUser(userEntity)
            prefs.edit().putString("last_active_user_id", uid).apply()

            _uiState.update {
                it.copy(
                    currentUser = userEntity,
                    currentScreen = if (userEntity.role == "ADMIN") AppScreen.ADMIN_DASHBOARD else AppScreen.HOME,
                    statusMessage = "Signed in with Google as $name"
                )
            }
            loadChecklistForUser(uid)
        }
    }

    fun logout() {
        Firebase.auth.signOut()
        prefs.edit().remove("last_active_user_id").apply()
        _uiState.update {
            it.copy(
                currentUser = null,
                currentScreen = AppScreen.AUTH,
                statusMessage = "Logged out successfully"
            )
        }
    }

    fun quickSwitchUser(user: UserEntity) {
        prefs.edit().putString("last_active_user_id", user.id).apply()
        _uiState.update {
            it.copy(
                currentUser = user,
                currentScreen = if (user.role == "ADMIN") AppScreen.ADMIN_DASHBOARD else AppScreen.HOME,
                statusMessage = "Switched to ${user.name} (${user.role})"
            )
        }
        loadChecklistForUser(user.id)
    }

    fun updateProfile(name: String, phone: String, address: String, onSuccess: () -> Unit) {
        val user = _uiState.value.currentUser ?: return
        val updated = user.copy(name = name, contactPhone = phone, addressLgu = address)
        viewModelScope.launch {
            repository.updateUserProfile(updated)
            _uiState.update {
                it.copy(currentUser = updated, statusMessage = "Profile updated successfully")
            }
            onSuccess()
        }
    }

    // --- Checklist Operations ---
    fun toggleChecklistItem(itemId: String) {
        val userId = _uiState.value.currentUser?.id ?: "guest_user"
        val updated = _userChecklist.value.map { item ->
            if (item.id == itemId) {
                val newChecked = !item.isChecked
                prefs.edit().putBoolean("check_${userId}_${item.id}", newChecked).apply()
                item.copy(isChecked = newChecked)
            } else {
                item
            }
        }
        _userChecklist.value = updated

        // Sync to cloud Firestore if authenticated
        if (Firebase.auth.currentUser != null) {
            val currentItem = updated.firstOrNull { it.id == itemId }
            if (currentItem != null) {
                viewModelScope.launch {
                    firestoreRepository.saveChecklistItem(
                        FirestoreChecklistItem(
                            id = currentItem.id,
                            userId = Firebase.auth.currentUser!!.uid,
                            title = currentItem.name,
                            category = currentItem.category,
                            description = currentItem.description,
                            isChecked = currentItem.isChecked
                        )
                    )
                }
            }
        }
    }

    fun resetChecklist() {
        val userId = _uiState.value.currentUser?.id ?: "guest_user"
        val updated = _userChecklist.value.map {
            prefs.edit().putBoolean("check_${userId}_${it.id}", false).apply()
            it.copy(isChecked = false)
        }
        _userChecklist.value = updated
    }

    fun toggleAllChecklist(checkAll: Boolean) {
        val userId = _uiState.value.currentUser?.id ?: "guest_user"
        val updated = _userChecklist.value.map {
            prefs.edit().putBoolean("check_${userId}_${it.id}", checkAll).apply()
            it.copy(isChecked = checkAll)
        }
        _userChecklist.value = updated
    }

    // --- Feedback Operations ---
    fun submitFeedback(disasterTopic: String, rating: Int, comments: String, onSuccess: () -> Unit) {
        val user = _uiState.value.currentUser
        val userId = user?.id ?: "anonymous_user"
        val userName = user?.name ?: "Anonymous Citizen"
        val userEmail = user?.email ?: "anonymous@readyai.ph"

        viewModelScope.launch {
            repository.submitFeedback(userId, userName, userEmail, disasterTopic, rating, comments)
            // Sync to Firestore if authenticated with Google
            if (Firebase.auth.currentUser != null) {
                firestoreRepository.submitFeedback(
                    FirestoreFeedback(
                        id = "fb_${UUID.randomUUID()}",
                        userId = Firebase.auth.currentUser!!.uid,
                        userName = userName,
                        category = disasterTopic,
                        message = comments,
                        rating = rating.toLong()
                    )
                )
            }
            _uiState.update { it.copy(statusMessage = "Feedback submitted. Salamat!") }
            onSuccess()
        }
    }

    fun updateFeedbackStatus(id: String, status: String) {
        viewModelScope.launch {
            repository.updateFeedbackStatus(id, status)
        }
    }

    fun deleteFeedback(id: String) {
        viewModelScope.launch {
            repository.deleteFeedback(id)
        }
    }

    // --- Admin Operations: Emergency Guides ---
    fun saveGuide(guide: EmergencyCategory) {
        viewModelScope.launch {
            repository.saveGuide(guide)
            _uiState.update { it.copy(statusMessage = "Emergency guide '${guide.title}' updated in database.") }
        }
    }

    fun deleteGuide(id: String) {
        viewModelScope.launch {
            repository.deleteGuide(id)
            _uiState.update { it.copy(statusMessage = "Emergency guide removed from database.") }
        }
    }

    // --- Admin Operations: Emergency Contacts ---
    fun saveContact(contact: EmergencyContact) {
        viewModelScope.launch {
            repository.saveContact(contact)
            _uiState.update { it.copy(statusMessage = "Emergency contact '${contact.agencyName}' saved.") }
        }
    }

    fun deleteContact(id: String) {
        viewModelScope.launch {
            repository.deleteContact(id)
            _uiState.update { it.copy(statusMessage = "Emergency contact deleted.") }
        }
    }

    // --- Admin Operations: Regional Contacts ---
    fun updateRegionalContact(region: PhilippineRegion) {
        viewModelScope.launch {
            repository.updateRegionalContact(region)
            _uiState.update { it.copy(statusMessage = "Regional contacts for ${region.code} updated.") }
        }
    }

    // --- Admin Operations: Announcements ---
    fun saveAnnouncement(announcement: AnnouncementEntity) {
        viewModelScope.launch {
            repository.saveAnnouncement(announcement)
            _uiState.update { it.copy(statusMessage = "Announcement broadcasted successfully.") }
        }
    }

    fun deleteAnnouncement(id: String) {
        viewModelScope.launch {
            repository.deleteAnnouncement(id)
            _uiState.update { it.copy(statusMessage = "Announcement deleted.") }
        }
    }

    // --- Admin Operations: Users ---
    fun toggleUserRole(userId: String) {
        viewModelScope.launch {
            repository.toggleUserRole(userId)
            _uiState.update { it.copy(statusMessage = "User privileges updated.") }
        }
    }

    fun deleteUser(userId: String) {
        viewModelScope.launch {
            repository.deleteUser(userId)
            _uiState.update { it.copy(statusMessage = "User account removed.") }
        }
    }

    // --- Emergency 911 Dialog ---
    fun showCall911Dialog(show: Boolean) {
        _uiState.update { it.copy(showCall911Dialog = show) }
    }

    // --- Gemini AI Assistant ---
    fun sendMessage(userText: String) {
        val trimmed = userText.trim()
        if (trimmed.isBlank() || _uiState.value.isAiThinking) return

        val userMessage = ChatMessage(
            id = "user_${System.currentTimeMillis()}",
            text = trimmed,
            isUser = true
        )

        _uiState.update {
            it.copy(
                chatMessages = it.chatMessages + userMessage,
                isAiThinking = true
            )
        }

        viewModelScope.launch {
            val responseText = GeminiService.askEmergencyAssistant(trimmed)
            val aiMessage = ChatMessage(
                id = "ai_${System.currentTimeMillis()}",
                text = responseText,
                isUser = false
            )
            _uiState.update {
                it.copy(
                    chatMessages = it.chatMessages + aiMessage,
                    isAiThinking = false
                )
            }
        }
    }

    // --- Siren & SOS Sound ---
    fun toggleEmergencySiren() {
        if (_uiState.value.isSirenPlaying) {
            stopSiren()
        } else {
            startSiren()
        }
    }

    private fun startSiren() {
        _uiState.update { it.copy(isSirenPlaying = true) }
        sirenJob = viewModelScope.launch(Dispatchers.Default) {
            try {
                val sampleRate = 44100
                val numSamplesHigh = sampleRate / 2
                val numSamplesLow = sampleRate / 2
                val bufferHigh = ShortArray(numSamplesHigh)
                val bufferLow = ShortArray(numSamplesLow)

                for (i in 0 until numSamplesHigh) {
                    val angle = 2.0 * Math.PI * i / (sampleRate / 1000.0)
                    bufferHigh[i] = (Math.sin(angle) * Short.MAX_VALUE * 0.9).toInt().toShort()
                }

                for (i in 0 until numSamplesLow) {
                    val angle = 2.0 * Math.PI * i / (sampleRate / 600.0)
                    bufferLow[i] = (Math.sin(angle) * Short.MAX_VALUE * 0.9).toInt().toShort()
                }

                val minBufferSize = AudioTrack.getMinBufferSize(
                    sampleRate,
                    AudioFormat.CHANNEL_OUT_MONO,
                    AudioFormat.ENCODING_PCM_16BIT
                )

                audioTrack = AudioTrack.Builder()
                    .setAudioAttributes(
                        AudioAttributes.Builder()
                            .setUsage(AudioAttributes.USAGE_ALARM)
                            .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
                            .build()
                    )
                    .setAudioFormat(
                        AudioFormat.Builder()
                            .setEncoding(AudioFormat.ENCODING_PCM_16BIT)
                            .setSampleRate(sampleRate)
                            .setChannelMask(AudioFormat.CHANNEL_OUT_MONO)
                            .build()
                    )
                    .setBufferSizeInBytes(minBufferSize.coerceAtLeast(bufferHigh.size * 2))
                    .build()

                audioTrack?.play()

                val vibrator = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
                    val manager = getApplication<Application>().getSystemService(Context.VIBRATOR_MANAGER_SERVICE) as? VibratorManager
                    manager?.defaultVibrator
                } else {
                    @Suppress("DEPRECATION")
                    getApplication<Application>().getSystemService(Context.VIBRATOR_SERVICE) as? Vibrator
                }

                while (isActive) {
                    audioTrack?.write(bufferHigh, 0, bufferHigh.size)
                    vibrator?.let {
                        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                            it.vibrate(VibrationEffect.createOneShot(300, VibrationEffect.DEFAULT_AMPLITUDE))
                        } else {
                            @Suppress("DEPRECATION")
                            it.vibrate(300)
                        }
                    }
                    delay(300)

                    audioTrack?.write(bufferLow, 0, bufferLow.size)
                    delay(300)
                }
            } catch (e: Exception) {
                android.util.Log.e("Siren", "Audio error", e)
            } finally {
                stopAudioTrack()
            }
        }
    }

    private fun stopSiren() {
        sirenJob?.cancel()
        sirenJob = null
        stopAudioTrack()
        _uiState.update { it.copy(isSirenPlaying = false) }
    }

    private fun stopAudioTrack() {
        try {
            audioTrack?.pause()
            audioTrack?.flush()
            audioTrack?.stop()
            audioTrack?.release()
        } catch (_: Exception) {
        } finally {
            audioTrack = null
        }
    }

    // --- Disaster Alerts & Nearby Incidents Operations ---
    fun setAlertTypeFilter(type: String) {
        _uiState.update { it.copy(alertTypeFilter = type) }
    }

    fun setAlertSeverityFilter(severity: String) {
        _uiState.update { it.copy(alertSeverityFilter = severity) }
    }

    fun setAlertLocationFilter(location: String) {
        _uiState.update { it.copy(alertLocationFilter = location) }
    }

    fun setOnlyNearbyAlerts(enabled: Boolean) {
        _uiState.update { it.copy(onlyNearbyAlerts = enabled) }
    }

    fun setAlertSearchQuery(query: String) {
        _uiState.update { it.copy(alertSearchQuery = query) }
    }

    fun selectAlertForDetail(alert: DisasterAlertEntity?) {
        _uiState.update { it.copy(selectedAlertForDetail = alert) }
        if (alert != null && !alert.isRead) {
            markAlertAsRead(alert.id)
        }
    }

    fun setUserLocation(lat: Double, lng: Double, cityName: String) {
        _uiState.update {
            it.copy(
                userLatitude = lat,
                userLongitude = lng,
                userCityName = cityName,
                statusMessage = "Location updated to $cityName"
            )
        }
    }

    fun calculateDistanceKm(targetLat: Double, targetLng: Double): Double {
        val userLat = _uiState.value.userLatitude
        val userLng = _uiState.value.userLongitude
        val earthRadius = 6371.0 // km
        val dLat = Math.toRadians(targetLat - userLat)
        val dLng = Math.toRadians(targetLng - userLng)
        val a = Math.sin(dLat / 2) * Math.sin(dLat / 2) +
                Math.cos(Math.toRadians(userLat)) * Math.cos(Math.toRadians(targetLat)) *
                Math.sin(dLng / 2) * Math.sin(dLng / 2)
        val c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a))
        return earthRadius * c
    }

    fun isAlertNearby(alert: DisasterAlertEntity, radiusKm: Double = 40.0): Boolean {
        // Match by geographic distance OR region / city name
        val distance = calculateDistanceKm(alert.latitude, alert.longitude)
        if (distance <= radiusKm) return true
        val userCity = _uiState.value.userCityName.lowercase()
        return alert.locationCity.isNotBlank() && userCity.contains(alert.locationCity.lowercase())
    }

    fun markAlertAsRead(id: String) {
        viewModelScope.launch {
            repository.markAlertAsRead(id)
        }
    }

    fun markAllAlertsAsRead() {
        viewModelScope.launch {
            repository.markAllAlertsAsRead()
            _uiState.update { it.copy(statusMessage = "All disaster notifications marked as read") }
        }
    }

    fun saveAlert(alert: DisasterAlertEntity) {
        viewModelScope.launch {
            repository.saveAlert(alert)
            _uiState.update { it.copy(statusMessage = "Disaster alert saved successfully") }
        }
    }

    fun broadcastAlert(alert: DisasterAlertEntity) {
        viewModelScope.launch {
            repository.saveAlert(alert)
            _uiState.update { it.copy(statusMessage = "🚨 Alert Broadcasted: ${alert.title}") }
            playDisasterAlertSound()
        }
    }

    fun deleteAlert(id: String) {
        viewModelScope.launch {
            repository.deleteAlert(id)
            _uiState.update { it.copy(statusMessage = "Alert deleted") }
        }
    }

    fun setAlertArchived(id: String, isArchived: Boolean) {
        viewModelScope.launch {
            repository.setAlertArchived(id, isArchived)
            _uiState.update { it.copy(statusMessage = if (isArchived) "Alert archived" else "Alert unarchived") }
        }
    }

    // --- Sound Notification Settings & Chime Synthesis ---
    fun setSoundAlertsEnabled(enabled: Boolean) {
        prefs.edit().putBoolean("sound_alerts_enabled", enabled).apply()
        _uiState.update {
            it.copy(
                isSoundAlertsEnabled = enabled,
                statusMessage = if (enabled) "Emergency sound notifications ENABLED" else "Emergency sound notifications MUTED"
            )
        }
    }

    fun playDisasterAlertSound() {
        if (!_uiState.value.isSoundAlertsEnabled) return
        viewModelScope.launch(Dispatchers.IO) {
            synthesizeAlertChime()
        }
    }

    fun previewAlertSound() {
        viewModelScope.launch(Dispatchers.IO) {
            synthesizeAlertChime()
        }
    }

    private suspend fun synthesizeAlertChime() {
        try {
            val sampleRate = 44100
            val durationMs = 320
            val numSamples = (sampleRate * (durationMs / 1000.0)).toInt()
            val buffer = ShortArray(numSamples)

            // EAS / Civil Defense Dual Tone (853 Hz + 960 Hz) standard Philippine alert frequency
            for (i in 0 until numSamples) {
                val t = i.toDouble() / sampleRate
                val tone1 = Math.sin(2.0 * Math.PI * 853.0 * t)
                val tone2 = Math.sin(2.0 * Math.PI * 960.0 * t)
                val combined = (tone1 * 0.5 + tone2 * 0.5) * Short.MAX_VALUE * 0.85
                buffer[i] = combined.toInt().toShort()
            }

            val track = AudioTrack.Builder()
                .setAudioAttributes(
                    AudioAttributes.Builder()
                        .setUsage(AudioAttributes.USAGE_ALARM)
                        .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
                        .build()
                )
                .setAudioFormat(
                    AudioFormat.Builder()
                        .setEncoding(AudioFormat.ENCODING_PCM_16BIT)
                        .setSampleRate(sampleRate)
                        .setChannelMask(AudioFormat.CHANNEL_OUT_MONO)
                        .build()
                )
                .setBufferSizeInBytes(buffer.size * 2)
                .build()

            track.play()

            val vibrator = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
                val manager = getApplication<Application>().getSystemService(Context.VIBRATOR_MANAGER_SERVICE) as? VibratorManager
                manager?.defaultVibrator
            } else {
                @Suppress("DEPRECATION")
                getApplication<Application>().getSystemService(Context.VIBRATOR_SERVICE) as? Vibrator
            }

            // Pulse 2 quick bursts
            repeat(2) {
                track.write(buffer, 0, buffer.size)
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                    vibrator?.vibrate(VibrationEffect.createOneShot(240, VibrationEffect.DEFAULT_AMPLITUDE))
                } else {
                    @Suppress("DEPRECATION")
                    vibrator?.vibrate(240)
                }
                delay(120)
            }

            track.stop()
            track.release()
        } catch (e: Exception) {
            android.util.Log.e("SoundAlert", "Audio synthesis error", e)
        }
    }

    override fun onCleared() {
        super.onCleared()
        stopSiren()
    }
}
