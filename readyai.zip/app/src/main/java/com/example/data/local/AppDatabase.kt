package com.example.data.local

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase

@Database(
    entities = [
        UserEntity::class,
        EmergencyGuideEntity::class,
        EmergencyContactEntity::class,
        RegionalContactEntity::class,
        AnnouncementEntity::class,
        ChecklistEntity::class,
        FeedbackEntity::class,
        DisasterAlertEntity::class
    ],
    version = 2,
    exportSchema = false
)
abstract class AppDatabase : RoomDatabase() {

    abstract fun userDao(): UserDao
    abstract fun guideDao(): EmergencyGuideDao
    abstract fun contactDao(): EmergencyContactDao
    abstract fun regionalDao(): RegionalContactDao
    abstract fun announcementDao(): AnnouncementDao
    abstract fun checklistDao(): ChecklistDao
    abstract fun feedbackDao(): FeedbackDao
    abstract fun alertDao(): DisasterAlertDao

    companion object {
        @Volatile
        private var INSTANCE: AppDatabase? = null

        fun getDatabase(context: Context): AppDatabase {
            return INSTANCE ?: synchronized(this) {
                val instance = Room.databaseBuilder(
                    context.applicationContext,
                    AppDatabase::class.java,
                    "readyai_disaster.db"
                ).fallbackToDestructiveMigration(true).build()
                INSTANCE = instance
                instance
            }
        }

        fun createInMemoryDatabase(context: Context): AppDatabase {
            return Room.inMemoryDatabaseBuilder(
                context.applicationContext,
                AppDatabase::class.java
            ).allowMainThreadQueries().build()
        }
    }
}
