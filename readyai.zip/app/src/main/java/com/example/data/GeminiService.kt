package com.example.data

import android.util.Log
import com.example.BuildConfig
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONArray
import org.json.JSONObject
import java.util.concurrent.TimeUnit

object GeminiService {
    private const val TAG = "GeminiService"
    private const val MODEL_NAME = "gemini-3.5-flash"
    private const val BASE_URL = "https://generativelanguage.googleapis.com/v1beta/models/$MODEL_NAME:generateContent"

    private val client = OkHttpClient.Builder()
        .connectTimeout(60, TimeUnit.SECONDS)
        .readTimeout(60, TimeUnit.SECONDS)
        .writeTimeout(60, TimeUnit.SECONDS)
        .build()

    private const val SYSTEM_INSTRUCTION = """
You are ReadyAI, an emergency and disaster information assistant specifically designed for people in the Philippines.
Your mission is to provide clear, simple, practical, step-by-step emergency instructions and disaster preparedness advice.
Adhere to official guidelines from NDRRMC, PAGASA, PHIVOLCS, Bureau of Fire Protection (BFP), and the Philippine Red Cross.

CRITICAL SAFETY & MEDICAL RULES:
1. You MUST NEVER diagnose medical conditions or pretend to be a doctor, firefighter, police officer, or professional emergency responder.
2. For any life-threatening or immediate emergencies (active fire, structural collapse, rising flood waters trapping people, severe injuries), instruct the user directly in bold capital letters to immediately CALL 911.
3. Keep instructions concise, structured with bullet points, simple for ordinary citizens and students to read under stress, and actionable.
4. When relevant, mention key Philippine hotlines (911 for all emergencies, 117 for PNP, 143 for Red Cross, (02) 8426-0219 for BFP).
"""

    suspend fun askEmergencyAssistant(userQuery: String): String = withContext(Dispatchers.IO) {
        val apiKey = try {
            BuildConfig.GEMINI_API_KEY
        } catch (e: Exception) {
            ""
        }

        // If API key is missing or default placeholder, or network fails, provide offline disaster response
        if (apiKey.isNullOrBlank() || apiKey == "MY_GEMINI_API_KEY") {
            Log.w(TAG, "Gemini API key is not configured or is placeholder. Using smart emergency fallback.")
            return@withContext getOfflineEmergencyResponse(userQuery)
        }

        try {
            val jsonBody = JSONObject().apply {
                // systemInstruction
                put("systemInstruction", JSONObject().apply {
                    put("parts", JSONArray().apply {
                        put(JSONObject().apply { put("text", SYSTEM_INSTRUCTION) })
                    })
                })
                // contents
                put("contents", JSONArray().apply {
                    put(JSONObject().apply {
                        put("parts", JSONArray().apply {
                            put(JSONObject().apply { put("text", userQuery) })
                        })
                    })
                })
                // generationConfig
                put("generationConfig", JSONObject().apply {
                    put("temperature", 0.4)
                    put("topP", 0.95)
                    put("topK", 40)
                })
            }

            val requestBody = jsonBody.toString().toRequestBody("application/json; charset=utf-8".toMediaType())
            val request = Request.Builder()
                .url("$BASE_URL?key=$apiKey")
                .post(requestBody)
                .build()

            val response = client.newCall(request).execute()
            val responseString = response.body?.string()

            if (!response.isSuccessful || responseString == null) {
                Log.e(TAG, "Gemini API call failed with HTTP ${response.code}: $responseString")
                return@withContext getOfflineEmergencyResponse(userQuery)
            }

            val rootJson = JSONObject(responseString)
            val candidates = rootJson.optJSONArray("candidates")
            if (candidates != null && candidates.length() > 0) {
                val firstCandidate = candidates.getJSONObject(0)
                val content = firstCandidate.optJSONObject("content")
                val parts = content?.optJSONArray("parts")
                if (parts != null && parts.length() > 0) {
                    val text = parts.getJSONObject(0).optString("text")
                    if (text.isNotBlank()) {
                        return@withContext text
                    }
                }
            }

            return@withContext getOfflineEmergencyResponse(userQuery)
        } catch (e: Exception) {
            Log.e(TAG, "Error contacting Gemini API", e)
            return@withContext getOfflineEmergencyResponse(userQuery)
        }
    }

    /**
     * Resilient offline emergency response tailored to Philippine disaster context
     * Ensures users never face an error screen during real storms or power outages.
     */
    private fun getOfflineEmergencyResponse(query: String): String {
        val q = query.lowercase()

        return when {
            q.contains("flood") || q.contains("baha") -> """
🚨 FLOOD SAFETY INSTRUCTIONS (Philippine NDRRMC Guidelines):

1. IMMEDIATE ACTIONS:
• Turn off the main electrical circuit breaker BEFORE water reaches electrical sockets.
• Move family, pets, and your 72-hour Go Bag to upper floors or designated evacuation centers immediately.
• If water enters your home, wear rubber boots to protect against Leptospirosis and sharp debris.

2. WHAT NOT TO DO:
• DO NOT walk, swim, or drive through moving floodwaters. Just 6 inches of water can sweep you off your feet.
• DO NOT touch wet electrical appliances or submerged outlets.
• DO NOT drink tap water without boiling it for at least 1-3 minutes.

3. WHEN TO CALL FOR RESCUE:
• If water is rising rapidly and exit paths are blocked, or if vulnerable family members are trapped.
📞 FOR LIFE-THREATENING RESCUE: CALL 911 or Coast Guard (02) 8527-8481 / Red Cross 143.
""".trimIndent()

            q.contains("typhoon") || q.contains("bagyo") || q.contains("storm") -> """
🚨 TYPHOON PREPAREDNESS & SAFETY (PAGASA Guidelines):

1. WHAT TO PREPARE BEFORE THE TYPHOON:
• Secure roof sheets, clean rain gutters, and prune tree branches near power lines.
• Stock up on drinking water (at least 1 gallon/person/day for 3+ days) and ready-to-eat canned food.
• Fully charge mobile phones, power banks, and battery-operated emergency lanterns.
• Pack birth certificates, IDs, and deeds in waterproof plastic pouches.

2. DURING THE TYPHOON:
• Stay indoors away from glass windows and open verandas.
• Monitor PAGASA storm signal advisories via radio or emergency alerts.
• BEWARE OF THE EYE: If violent winds suddenly stop, DO NOT go outside. The eye will pass, and winds will strike fiercely from the reverse direction.

3. WHEN TO CALL:
📞 FOR LIFE-THREATENING EMERGENCIES: CALL 911 or your local City/Municipal DRRMO.
""".trimIndent()

            q.contains("earthquake") || q.contains("lindol") || q.contains("quake") -> """
🚨 EARTHQUAKE SAFETY (PHIVOLCS Guidelines):

1. DURING THE SHAKING:
• DROP down onto your hands and knees.
• COVER your head and neck under a sturdy table or desk.
• HOLD ON to your shelter until the shaking stops completely.
• If outdoors, move to an open area clear of buildings, power lines, and billboards.

2. IMMEDIATELY AFTER:
• Expect aftershocks. Be prepared to Drop, Cover, and Hold again.
• Evacuate using stairs. NEVER use elevators.
• Check for gas leaks (smell of LPG). Shut off the gas tank valve immediately.
• If you are near coastal shores and felt strong shaking, RUN INLAND to high ground immediately (Tsunami threat).

3. WHEN TO CALL:
📞 IF SOMEONE IS TRAPPED UNDER DEBRIS OR HURT: CALL 911 or BFP Rescue immediately.
""".trimIndent()

            q.contains("fire") || q.contains("sunog") -> """
🚨 FIRE SAFETY & RESCUE (Bureau of Fire Protection Guidelines):

1. ESCAPE IMMEDIATELY:
• Shout "SUNOG!" to alert family and neighbors.
• CRAWL LOW under smoke where oxygen levels are higher and air is cooler.
• Test doorknobs with the back of your hand before opening. If hot, use your secondary escape route.
• If your clothes catch fire: STOP, DROP, and ROLL.

2. CRITICAL RULES:
• NEVER go back inside a burning building for pets, gadgets, or money.
• DO NOT throw water on grease (cooking oil) or electrical fires; smother with a lid or use ABC fire extinguisher.

3. CALL BFP & 911:
📞 IMMEDIATELY CALL 911 or BFP Hotline (02) 8426-0219. Give your exact barangay, street name, and landmarks.
""".trimIndent()

            q.contains("go bag") || q.contains("bag") || q.contains("kit") || q.contains("prepare") || q.contains("pack") -> """
🎒 72-HOUR EMERGENCY GO BAG CHECKLIST:

1. Hydration & Food:
• 1 gallon of drinking water per person per day (3-day minimum).
• Non-perishable canned food with pull-tab openers and high-calorie biscuits.

2. Lighting & Power:
• Waterproof LED flashlight and extra batteries.
• Fully charged 20,000mAh power bank and USB cables.

3. Medical & Safety:
• First aid kit (antiseptic, bandages, medical tape, sterile gauze).
• 7-day supply of maintenance medications + paracetamol.
• Loud emergency whistle (to signal rescuers without exhausting your voice).

4. Documents & Personal:
• IDs, birth certificates, and insurance in a waterproof zip pouch.
• Extra clothes, raincoat, sturdy footwear, and personal hygiene supplies.
""".trimIndent()

            q.contains("tsunami") -> """
🚨 TSUNAMI SURVIVAL GUIDE (PHIVOLCS Warning):

1. NATURAL WARNING SIGNS:
• Strong earthquake felt along the coast.
• Sudden, unusual receding of the ocean tide exposing the seabed.
• Loud roaring sound like a train or jet engine coming from the sea.

2. IMMEDIATE ACTIONS:
• DO NOT wait for official warnings if you see these signs!
• RUN IMMEDIATELY to ground at least 30 meters (100 feet) high or at least 1 kilometer inland.
• Stay at high ground for several hours; tsunamis come in multiple waves, and later waves are often larger.
• DO NOT go to the shore to watch the waves!
📞 EMERGENCY: CALL 911 or Philippine Coast Guard (PCG).
""".trimIndent()

            q.contains("volcano") || q.contains("volcanic") || q.contains("ashfall") || q.contains("bulkan") -> """
🚨 VOLCANIC ERUPTION & ASHFALL SAFETY (PHIVOLCS):

1. PROTECTION FROM ASHFALL:
• Wear an N95 respirator mask or damp clean cloth over your nose and mouth.
• Protect eyes with safety goggles. DO NOT wear contact lenses.
• Keep doors, windows, and ventilation dampers shut tight.
• Cover drinking water cisterns and pet food bowls.

2. OUTDOOR & TRAVEL HAZARDS:
• Do not drive in heavy ashfall — roads become extremely slippery and ash clogs engines.
• Clear volcanic ash off roofs promptly to prevent roof collapse, especially if it rains.
• Beware of Lahar (volcanic mudflows) rushing down river channels during rainfall.

3. EVACUATION:
• Obey all mandatory evacuation orders for the Permanent Danger Zone (PDZ).
📞 FOR EMERGENCY ASSISTANCE: CALL 911 or PHIVOLCS (02) 8426-1468.
""".trimIndent()

            q.contains("brownout") || q.contains("power") || q.contains("blackout") -> """
🚨 POWER OUTAGE SAFETY (Brownout / Blackout):

1. SAFETY FIRST:
• Use battery-powered flashlights or LED lanterns. AVOID open wax candles to prevent house fires.
• Unplug sensitive appliances (TVs, refrigerators, computers) to avoid damage from sudden power surges when electricity returns.
• Keep refrigerator and freezer doors closed. Food stays cold for ~4 hours in a closed fridge and 48 hours in a full freezer.

2. GENERATOR PRECAUTION:
• NEVER run fuel generators indoors or in garages. Carbon monoxide gas is invisible, odorless, and fatal. Always place generators outdoors at least 20 feet away from windows.
📞 FOR DOWNED POWER LINES: CALL 911 or Meralco (16211) / local electric coop.
""".trimIndent()

            else -> """
🚨 READYAI EMERGENCY INSTRUCTION:

Thank you for consulting ReadyAI. When preparing for or facing an emergency in the Philippines:

1. ASSESS DANGER & PROTECT LIFE:
• Check if anyone is injured, trapped, or in immediate hazard (fire, flood, collapsed structures).
• Gather your 72-Hour Go Bag with water, medicines, flashlight, documents, and whistle.
• Follow official advisories from NDRRMC, PAGASA, PHIVOLCS, and your local Barangay DRRMO.

2. ESSENTIAL SAFETY NOTE:
• ReadyAI provides general safety guidance only and cannot replace professional emergency responders or medical personnel.

📞 FOR ALL LIFE-THREATENING EMERGENCIES: IMMEDIATELY CALL 911.
Police: 117 | Red Cross: 143 | Fire (BFP): (02) 8426-0219
""".trimIndent()
        }
    }
}
