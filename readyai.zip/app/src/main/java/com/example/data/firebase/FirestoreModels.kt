package com.example.data.firebase

import com.google.firebase.Timestamp
import com.google.firebase.firestore.DocumentId
import com.google.firebase.firestore.IgnoreExtraProperties
import com.google.firebase.firestore.ServerTimestamp

@IgnoreExtraProperties
data class FirestoreUserProfile(
    @DocumentId val id: String = "",
    val userId: String = "",
    val email: String = "",
    val displayName: String = "",
    val phone: String? = null,
    val bloodType: String? = null,
    val allergies: String? = null,
    val emergencyNotes: String? = null,
    val regionCode: String? = null,
    @ServerTimestamp val createdAt: Timestamp? = null,
    @ServerTimestamp val updatedAt: Timestamp? = null
)

@IgnoreExtraProperties
data class FirestoreChecklistItem(
    val id: String = "",
    val userId: String = "",
    val title: String = "",
    val category: String = "",
    val description: String? = null,
    val isChecked: Boolean = false,
    @ServerTimestamp val createdAt: Timestamp? = null,
    @ServerTimestamp val updatedAt: Timestamp? = null
)

@IgnoreExtraProperties
data class FirestoreEmergencyContact(
    val id: String = "",
    val userId: String = "",
    val name: String = "",
    val phone: String = "",
    val relationship: String = "",
    @ServerTimestamp val createdAt: Timestamp? = null,
    @ServerTimestamp val updatedAt: Timestamp? = null
)

@IgnoreExtraProperties
data class FirestoreFeedback(
    val id: String = "",
    val userId: String = "",
    val userName: String = "",
    val category: String = "",
    val message: String = "",
    val rating: Long = 5L,
    @ServerTimestamp val createdAt: Timestamp? = null
)

@IgnoreExtraProperties
data class FirestoreDisasterAlert(
    val id: String = "",
    val userId: String = "",
    val title: String = "",
    val category: String = "",
    val severity: String = "",
    val message: String = "",
    val locationCity: String = "",
    val sourceAgency: String? = null,
    val isTest: Boolean = false,
    @ServerTimestamp val createdAt: Timestamp? = null
)

