package com.example.data.model

import androidx.compose.ui.graphics.vector.ImageVector

/**
 * Emergency disaster category model (e.g. Typhoon, Flood, Earthquake, etc.)
 */
data class EmergencyCategory(
    val id: String,
    val title: String,
    val filipinoTitle: String,
    val summary: String,
    val iconName: String,
    val whatToDoBefore: List<String>,
    val whatToDoDuring: List<String>,
    val whatToDoAfter: List<String>,
    val whatNotToDo: List<String>,
    val safetyTips: List<String>,
    val whatToPrepare: List<String>,
    val whenToCallServices: List<String>,
    val agencyInCharge: String,
    val alertLevelsInfo: String? = null
)

/**
 * Philippine emergency contact information
 */
data class EmergencyContact(
    val id: String,
    val agencyName: String,
    val acronym: String,
    val primaryNumber: String,
    val alternateNumbers: List<String> = emptyList(),
    val description: String,
    val category: ContactCategory = ContactCategory.NATIONAL,
    val isNationalPriority: Boolean = false
)

enum class ContactCategory {
    NATIONAL,
    POLICE_MILITARY,
    FIRE_RESCUE,
    MEDICAL_HEALTH,
    DISASTER_WEATHER,
    REGIONAL
}

/**
 * Philippine Administrative Region emergency directory
 */
data class PhilippineRegion(
    val code: String,
    val name: String,
    val fullName: String,
    val rdrrmcHotline: String,
    val altHotline: String,
    val policeHotline: String,
    val fireHotline: String,
    val regionalOffice: String,
    val lguNote: String = "Please verify localized municipal / city DRRMO numbers with your local barangay hall or city hall."
)

/**
 * Go Bag emergency checklist item
 */
data class ChecklistItem(
    val id: String,
    val name: String,
    val category: String,
    val description: String,
    val isChecked: Boolean = false,
    val isEssential: Boolean = true
)

/**
 * Chat message for AI Emergency Assistant
 */
data class ChatMessage(
    val id: String,
    val text: String,
    val isUser: Boolean,
    val timestamp: Long = System.currentTimeMillis(),
    val isEmergencyAlert: Boolean = false
)

enum class DisasterType(val label: String, val filipinoLabel: String, val emoji: String) {
    TYPHOON("Typhoon", "Bagyo", "🌀"),
    EARTHQUAKE("Earthquake", "Lindol", "🌋"),
    FIRE("Fire", "Sunog", "🔥"),
    FLOOD("Flood", "Baha", "🌊"),
    VOLCANO("Volcano", "Bulkan", "🌋"),
    LANDSLIDE("Landslide", "Pagguho ng Lupa", "⛰️"),
    OTHER("Other Emergency", "Iba Pang Emergency", "⚠️");

    val displayName: String get() = "$label ($filipinoLabel)"

    companion object {
        val BAGYO = TYPHOON
        val LINDOL = EARTHQUAKE
        val SUNOG = FIRE
        val BAHA = FLOOD
        val BULKAN = VOLCANO

        fun formatDisasterTypeEnglish(disasterType: String): String {
            return when (disasterType.trim().lowercase()) {
                "bagyo", "typhoon" -> "TYPHOON (BAGYO)"
                "lindol", "earthquake" -> "EARTHQUAKE (LINDOL)"
                "sunog", "fire" -> "FIRE (SUNOG)"
                "baha", "flood" -> "FLOOD (BAHA)"
                "bulkan", "volcano", "pagsabog ng bulkan" -> "VOLCANO (BULKAN)"
                "landslide", "pagguho ng lupa" -> "LANDSLIDE"
                else -> disasterType.uppercase()
            }
        }
    }
}

enum class AlertSeverity(val label: String, val colorCode: Long) {
    CRITICAL("Critical Warning", 0xFFD32F2F), // Red
    SERIOUS("Serious Alert", 0xFFE65100),     // Orange
    ADVISORY("Advisory", 0xFFF57F17),         // Yellow
    EXPIRED("Expired / Archived", 0xFF757575) // Gray
}

data class DisasterAlert(
    val id: String,
    val disasterType: DisasterType,
    val title: String,
    val shortDescription: String,
    val detailedInstructions: String = "",
    val locationBarangay: String = "",
    val locationCity: String = "",
    val locationProvince: String = "",
    val affectedRegion: String = "NCR",
    val latitude: Double = 14.5995,
    val longitude: Double = 120.9842,
    val incidentTime: Long = System.currentTimeMillis(),
    val latestUpdateTime: Long = System.currentTimeMillis(),
    val severity: AlertSeverity = AlertSeverity.ADVISORY,
    val sourceName: String,
    val sourceUrl: String,
    val verificationStatus: String = "VERIFIED",
    val isRead: Boolean = false,
    val isArchived: Boolean = false,
    val earthquakeMagnitude: String? = null,
    val earthquakeDepth: String? = null,
    val typhoonSignal: String? = null,
    val fireAlarmLevel: String? = null,
    val floodLevel: String? = null
) {
    val fullLocationText: String
        get() {
            val parts = listOf(locationBarangay, locationCity, locationProvince, affectedRegion)
                .filter { it.isNotBlank() }
            return if (parts.isNotEmpty()) parts.joinToString(", ") else "Philippines"
        }
}

