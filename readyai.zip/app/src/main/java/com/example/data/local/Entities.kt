package com.example.data.local

import androidx.room.Entity
import androidx.room.PrimaryKey

/**
 * User Account Entity with Role-Based Access Control (USER vs ADMIN)
 */
@Entity(tableName = "users")
data class UserEntity(
    @PrimaryKey val id: String,
    val name: String,
    val email: String,
    val passwordHash: String,
    val role: String = "USER", // "USER" or "ADMIN"
    val contactPhone: String = "",
    val addressLgu: String = "",
    val createdAt: Long = System.currentTimeMillis()
)

/**
 * Emergency Disaster Guide Entity
 */
@Entity(tableName = "emergency_guides")
data class EmergencyGuideEntity(
    @PrimaryKey val id: String,
    val title: String,
    val filipinoTitle: String,
    val summary: String,
    val agencyInCharge: String,
    val alertLevelsInfo: String = "",
    val whatToDoBefore: String, // newline-separated
    val whatToDoDuring: String, // newline-separated
    val whatToDoAfter: String,  // newline-separated
    val whatNotToDo: String,    // newline-separated
    val safetyTips: String,     // newline-separated
    val whatToPrepare: String,  // newline-separated
    val whenToCallServices: String, // newline-separated
    val updatedAt: Long = System.currentTimeMillis()
)

/**
 * Emergency Contact Entity (National & General)
 */
@Entity(tableName = "emergency_contacts")
data class EmergencyContactEntity(
    @PrimaryKey val id: String,
    val agencyName: String,
    val acronym: String,
    val primaryNumber: String,
    val alternateNumbers: String = "", // comma-separated
    val description: String,
    val category: String = "NATIONAL",
    val isNationalPriority: Boolean = false,
    val updatedAt: Long = System.currentTimeMillis()
)

/**
 * Regional Emergency Contact Entity
 */
@Entity(tableName = "regional_contacts")
data class RegionalContactEntity(
    @PrimaryKey val code: String, // e.g. "NCR", "CAR", "Region I"
    val name: String,
    val fullName: String,
    val rdrrmcHotline: String,
    val altHotline: String,
    val policeHotline: String,
    val fireHotline: String,
    val regionalOffice: String,
    val updatedAt: Long = System.currentTimeMillis()
)

/**
 * Official Emergency Announcements Entity (Admin managed)
 */
@Entity(tableName = "announcements")
data class AnnouncementEntity(
    @PrimaryKey val id: String,
    val title: String,
    val category: String, // "TYPHOON ALERT", "FLOOD WARNING", "RELIEF DISTRIBUTION", "ADVISORY"
    val message: String,
    val severity: String = "NORMAL", // "HIGH", "CRITICAL", "NORMAL"
    val targetRegion: String = "ALL", // "ALL" or specific region like "NCR"
    val issuedBy: String = "Office of Civil Defense / ReadyAI Admin",
    val timestamp: Long = System.currentTimeMillis()
)

/**
 * User Checklist Item Entity (Go Bag)
 */
@Entity(tableName = "user_checklist")
data class ChecklistEntity(
    @PrimaryKey val id: String,
    val userId: String,
    val name: String,
    val category: String,
    val description: String,
    val isChecked: Boolean = false
)

/**
 * User Feedback Entity
 */
@Entity(tableName = "user_feedback")
data class FeedbackEntity(
    @PrimaryKey val id: String,
    val userId: String,
    val userName: String,
    val userEmail: String,
    val disasterTopic: String,
    val rating: Int, // 1 to 5 stars
    val comments: String,
    val status: String = "PENDING", // "PENDING", "REVIEWED", "RESOLVED"
    val timestamp: Long = System.currentTimeMillis()
)

/**
 * Real-Time Disaster Alert and Incident Entity
 */
@Entity(tableName = "disaster_alerts")
data class DisasterAlertEntity(
    @PrimaryKey val id: String,
    val disasterType: String, // "Bagyo", "Lindol", "Sunog", "Baha", "Volcano", "Landslide", "Other"
    val title: String,
    val shortDescription: String,
    val detailedInstructions: String = "",
    val locationBarangay: String = "",
    val locationCity: String = "",
    val locationProvince: String = "",
    val affectedRegion: String = "NCR",
    val latitude: Double = 14.5995,
    val longitude: Double = 120.9842,
    val incidentTime: Long = System.currentTimeMillis(),
    val latestUpdateTime: Long = System.currentTimeMillis(),
    val severity: String = "ADVISORY", // "CRITICAL", "SERIOUS", "ADVISORY", "EXPIRED"
    val sourceName: String = "NDRRMC",
    val sourceUrl: String = "https://ndrrmc.gov.ph",
    val verificationStatus: String = "VERIFIED", // "VERIFIED", "OFFICIAL BULLETIN", "COMMUNITY REPORTED"
    val isRead: Boolean = false,
    val isArchived: Boolean = false,
    val earthquakeMagnitude: String? = null,
    val earthquakeDepth: String? = null,
    val typhoonSignal: String? = null,
    val fireAlarmLevel: String? = null,
    val floodLevel: String? = null
)

