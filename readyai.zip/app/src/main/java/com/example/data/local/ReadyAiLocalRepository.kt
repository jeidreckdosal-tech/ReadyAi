package com.example.data.local

import android.content.Context
import com.example.data.DisasterRepository
import com.example.data.model.ChecklistItem
import com.example.data.model.EmergencyCategory
import com.example.data.model.EmergencyContact
import com.example.data.model.PhilippineRegion
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.launch
import java.security.MessageDigest
import java.util.UUID

class ReadyAiLocalRepository(
    private val db: AppDatabase,
    autoSeed: Boolean = true
) {
    constructor(context: Context) : this(AppDatabase.getDatabase(context), true)

    private val userDao = db.userDao()
    private val guideDao = db.guideDao()
    private val contactDao = db.contactDao()
    private val regionalDao = db.regionalDao()
    private val announcementDao = db.announcementDao()
    private val checklistDao = db.checklistDao()
    private val feedbackDao = db.feedbackDao()
    private val alertDao = db.alertDao()

    init {
        if (autoSeed) {
            CoroutineScope(Dispatchers.IO).launch {
                seedInitialDataIfEmpty()
            }
        }
    }

    suspend fun seedInitialDataIfEmpty() {
        // 1. Seed Default Admin and Citizen users if no users exist
        val userCount = userDao.getUserCount().first()
        if (userCount == 0) {
            val defaultAdmin = UserEntity(
                id = "admin_readyai_root",
                name = "ReadyAI Administrator",
                email = "admin@readyai.ph",
                passwordHash = hashPassword("admin123"),
                role = "ADMIN",
                contactPhone = "(02) 8911-5061",
                addressLgu = "NDRRMC Camp Aguinaldo, Quezon City"
            )

            val defaultUser = UserEntity(
                id = "user_citizen_demo",
                name = "Juan dela Cruz",
                email = "user@readyai.ph",
                passwordHash = hashPassword("user123"),
                role = "USER",
                contactPhone = "0917-123-4567",
                addressLgu = "Barangay Central, Quezon City, NCR"
            )

            userDao.insertUser(defaultAdmin)
            userDao.insertUser(defaultUser)
        }

        // 2. Seed Emergency Guides from DisasterRepository
        val guides = guideDao.getAllGuides().first()
        if (guides.isEmpty()) {
            val entities = DisasterRepository.categories.map { cat ->
                EmergencyGuideEntity(
                    id = cat.id,
                    title = cat.title,
                    filipinoTitle = cat.filipinoTitle,
                    summary = cat.summary,
                    agencyInCharge = cat.agencyInCharge,
                    alertLevelsInfo = cat.alertLevelsInfo ?: "",
                    whatToDoBefore = cat.whatToDoBefore.joinToString("\n"),
                    whatToDoDuring = cat.whatToDoDuring.joinToString("\n"),
                    whatToDoAfter = cat.whatToDoAfter.joinToString("\n"),
                    whatNotToDo = cat.whatNotToDo.joinToString("\n"),
                    safetyTips = cat.safetyTips.joinToString("\n"),
                    whatToPrepare = cat.whatToPrepare.joinToString("\n"),
                    whenToCallServices = cat.whenToCallServices.joinToString("\n")
                )
            }
            guideDao.insertAllGuides(entities)
        }

        // 3. Seed National Contacts
        val contacts = contactDao.getAllContacts().first()
        if (contacts.isEmpty()) {
            val entities = DisasterRepository.nationalContacts.map { c ->
                EmergencyContactEntity(
                    id = c.id,
                    agencyName = c.agencyName,
                    acronym = c.acronym,
                    primaryNumber = c.primaryNumber,
                    alternateNumbers = c.alternateNumbers.joinToString(", "),
                    description = c.description,
                    category = c.category.name,
                    isNationalPriority = c.isNationalPriority
                )
            }
            contactDao.insertAllContacts(entities)
        }

        // 4. Seed Regional Contacts
        val regionalContacts = regionalDao.getAllRegionalContacts().first()
        if (regionalContacts.isEmpty()) {
            val entities = DisasterRepository.philippineRegions.map { r ->
                RegionalContactEntity(
                    code = r.code,
                    name = r.name,
                    fullName = r.fullName,
                    rdrrmcHotline = r.rdrrmcHotline,
                    altHotline = r.altHotline,
                    policeHotline = r.policeHotline,
                    fireHotline = r.fireHotline,
                    regionalOffice = r.regionalOffice
                )
            }
            regionalDao.insertAllRegionalContacts(entities)
        }

        // 5. Seed Initial Announcements
        val announcements = announcementDao.getAllAnnouncements().first()
        if (announcements.isEmpty()) {
            val initialAnnouncements = listOf(
                AnnouncementEntity(
                    id = "ann_1",
                    title = "PAGASA Tropical Cyclone Weather Advisory",
                    category = "TYPHOON ALERT",
                    message = "LPA east of Mindanao has developed into a Tropical Depression. Continuous heavy rainfall expected over Eastern Visayas, Bicol, and Caraga. Small sea crafts are advised not to venture out.",
                    severity = "HIGH",
                    targetRegion = "ALL",
                    issuedBy = "PAGASA / OCD Operations Center"
                ),
                AnnouncementEntity(
                    id = "ann_2",
                    title = "Nationwide Simultaneous Earthquake Drill (NSED)",
                    category = "DISASTER DRILL",
                    message = "NDRRMC invites all schools, local government units, private businesses, and households to practice Duck, Cover, and Hold this Thursday at 2:00 PM.",
                    severity = "NORMAL",
                    targetRegion = "ALL",
                    issuedBy = "NDRRMC Secretariat"
                ),
                AnnouncementEntity(
                    id = "ann_3",
                    title = "Metro Manila Flood Control Advisory",
                    category = "FLOOD WARNING",
                    message = "MMDA pumping stations in Manila, Pasay, and Malabon are on full alert due to high tide and monsoon rains. Monitor water levels along Marikina River.",
                    severity = "HIGH",
                    targetRegion = "NCR",
                    issuedBy = "MMDA Metrobase"
                )
            )
            announcementDao.insertAllAnnouncements(initialAnnouncements)
        }

        // 6. Seed Real-Time Disaster Alerts & Incidents
        val existingAlerts = alertDao.getAllAlerts().first()
        if (existingAlerts.isEmpty()) {
            val initialAlerts = listOf(
                DisasterAlertEntity(
                    id = "alert_sunog_qc_001",
                    disasterType = "Fire",
                    title = "Fire: 3rd Alarm Structural Fire — Brgy. Sto. Domingo, Quezon City",
                    shortDescription = "Active residential fire along Biak-na-Bato St. Volunteer fire trucks responding. Stay clear of Araneta Ave corridor.",
                    detailedInstructions = "BFP Quezon City dispatched 8 fire engines alongside volunteer brigades. Evacuate immediately if downwind from smoke. Turn off LPG tank regulators. Close main circuit breaker. Avoid using elevators. Keep wet cloth over mouth and nose.",
                    locationBarangay = "Brgy. Sto. Domingo",
                    locationCity = "Quezon City",
                    locationProvince = "Metro Manila",
                    affectedRegion = "NCR",
                    latitude = 14.6349,
                    longitude = 121.0028,
                    incidentTime = System.currentTimeMillis() - 25 * 60 * 1000L, // 25 mins ago
                    latestUpdateTime = System.currentTimeMillis() - 5 * 60 * 1000L,
                    severity = "SERIOUS",
                    sourceName = "TXT FIRE Philippines & BFP-NCR",
                    sourceUrl = "https://www.facebook.com/txtfire",
                    verificationStatus = "VERIFIED BY BFP",
                    isRead = false,
                    isArchived = false,
                    fireAlarmLevel = "3rd Alarm (Volunteer & BFP Active)"
                ),
                DisasterAlertEntity(
                    id = "alert_lindol_lubang_002",
                    disasterType = "Earthquake",
                    title = "Earthquake: Magnitude 5.4 — Offshore Lubang, Occidental Mindoro",
                    shortDescription = "Tectonic earthquake with depth of 16 km. Felt at Intensity IV in Batangas and Intensity III in Metro Manila. Aftershocks expected.",
                    detailedInstructions = "PHIVOLCS Earthquake Information No. 2 officially recorded. No destructive tsunami threat for Philippine coasts. Check household structural damages and gas lines. Prepare for aftershocks. Remember: DUCK, COVER, and HOLD.",
                    locationBarangay = "Offshore Lubang",
                    locationCity = "Lubang",
                    locationProvince = "Occidental Mindoro",
                    affectedRegion = "Region IV-B",
                    latitude = 13.8569,
                    longitude = 120.1245,
                    incidentTime = System.currentTimeMillis() - 50 * 60 * 1000L,
                    latestUpdateTime = System.currentTimeMillis() - 15 * 60 * 1000L,
                    severity = "SERIOUS",
                    sourceName = "PHIVOLCS-DOST",
                    sourceUrl = "https://earthquake.phivolcs.dost.gov.ph/",
                    verificationStatus = "OFFICIAL BULLETIN",
                    isRead = false,
                    isArchived = false,
                    earthquakeMagnitude = "Magnitude 5.4 Ms",
                    earthquakeDepth = "16 km (Tectonic)"
                ),
                DisasterAlertEntity(
                    id = "alert_bagyo_super_003",
                    disasterType = "Typhoon",
                    title = "Typhoon Signal #3 — Typhoon LEON (Bulletin #16)",
                    shortDescription = "Typhoon packing 165 km/h sustained winds. Coastal surge warnings active for Batanes, Babuyan Islands, and Northern Cagayan.",
                    detailedInstructions = "PAGASA warns of destructive typhoon winds within 18 hours. Forced evacuation active in coastal low-lying communities. Anchor tin roofs, charge mobile phones and power banks, stockpile 3 days drinking water, and stay indoors.",
                    locationBarangay = "Coastal Municipalities",
                    locationCity = "Basco & Santa Ana",
                    locationProvince = "Batanes & Cagayan",
                    affectedRegion = "Region II",
                    latitude = 20.4485,
                    longitude = 121.9708,
                    incidentTime = System.currentTimeMillis() - 90 * 60 * 1000L,
                    latestUpdateTime = System.currentTimeMillis() - 10 * 60 * 1000L,
                    severity = "CRITICAL",
                    sourceName = "PAGASA-DOST",
                    sourceUrl = "https://bagong.pagasa.dost.gov.ph/",
                    verificationStatus = "OFFICIAL BULLETIN",
                    isRead = false,
                    isArchived = false,
                    typhoonSignal = "TCWS #3 (121 - 170 km/h winds)"
                ),
                DisasterAlertEntity(
                    id = "alert_baha_manila_004",
                    disasterType = "Flood",
                    title = "Flood Warning: Red Rainfall & Waist-Level Flood — España & Taft Ave",
                    shortDescription = "Waist-deep floodwaters reported along España Blvd corner Lacson Ave and Taft Ave corner P. Faura. Not passable to light vehicles.",
                    detailedInstructions = "MMDA Metrobase reports all pumping stations in Balete, Aviles, and Binondo operating at peak capacity. Motorists instructed to use high-elevation diversions. Pedestrians must avoid wading due to live wire and leptospirosis hazards.",
                    locationBarangay = "Sampaloc & Ermita",
                    locationCity = "Manila",
                    locationProvince = "Metro Manila",
                    affectedRegion = "NCR",
                    latitude = 14.6062,
                    longitude = 120.9904,
                    incidentTime = System.currentTimeMillis() - 40 * 60 * 1000L,
                    latestUpdateTime = System.currentTimeMillis() - 8 * 60 * 1000L,
                    severity = "CRITICAL",
                    sourceName = "MMDA Metrobase & Project NOAH",
                    sourceUrl = "https://noah.up.edu.ph/",
                    verificationStatus = "FIELD CONFIRMED",
                    isRead = false,
                    isArchived = false,
                    floodLevel = "Waist Deep (30-36 inches) — Not Passable to Light Vehicles"
                ),
                DisasterAlertEntity(
                    id = "alert_volcano_taal_005",
                    disasterType = "Volcano",
                    title = "Volcano Advisory: Taal Smog (Vog) & Degassing Alert",
                    shortDescription = "Sulfur dioxide emissions measured at 4,500 tonnes/day over Batangas and Cavite. Vulnerable residents advised to wear N95 masks.",
                    detailedInstructions = "PHIVOLCS maintains Alert Level 1. Main Crater Island remains a Permanent Danger Zone. Residents with respiratory conditions should stay indoors, seal windows, and wear N95/KN95 masks.",
                    locationBarangay = "Talisay, Agoncillo & Laurel",
                    locationCity = "Batangas Lakeshore",
                    locationProvince = "Batangas",
                    affectedRegion = "Region IV-A",
                    latitude = 14.0022,
                    longitude = 120.9934,
                    incidentTime = System.currentTimeMillis() - 180 * 60 * 1000L,
                    latestUpdateTime = System.currentTimeMillis() - 30 * 60 * 1000L,
                    severity = "ADVISORY",
                    sourceName = "PHIVOLCS-DOST",
                    sourceUrl = "https://www.phivolcs.dost.gov.ph/",
                    verificationStatus = "OFFICIAL BULLETIN",
                    isRead = false,
                    isArchived = false
                ),
                DisasterAlertEntity(
                    id = "alert_expired_kennon_006",
                    disasterType = "Landslide",
                    title = "Landslide Cleared: Kennon Road Rockslide — Normal Traffic Resumed (ARCHIVED)",
                    shortDescription = "DPWH Cordillera completed rock clearing operations at Camp 4, Tuba, Benguet. Both lanes now reopened.",
                    detailedInstructions = "Road condition inspected and cleared for vehicular traffic by DPWH and Baguio City DRRMO. Motorists are advised to drive cautiously during afternoon rainfall.",
                    locationBarangay = "Camp 4, Tuba",
                    locationCity = "Tuba",
                    locationProvince = "Benguet",
                    affectedRegion = "CAR",
                    latitude = 16.3214,
                    longitude = 120.5754,
                    incidentTime = System.currentTimeMillis() - 86400 * 1000L * 2, // 2 days ago
                    latestUpdateTime = System.currentTimeMillis() - 86400 * 1000L,
                    severity = "EXPIRED",
                    sourceName = "DPWH CAR & Baguio City DRRMO",
                    sourceUrl = "https://ndrrmc.gov.ph/",
                    verificationStatus = "RESOLVED",
                    isRead = true,
                    isArchived = true
                )
            )
            alertDao.insertAllAlerts(initialAlerts)
        }
    }

    // --- User & Auth Operations ---
    fun getAllUsers(): Flow<List<UserEntity>> = userDao.getAllUsers()
    fun getUserCount(): Flow<Int> = userDao.getUserCount()

    suspend fun registerUser(name: String, email: String, password: String, role: String = "USER"): Result<UserEntity> {
        val existing = userDao.getUserByEmail(email.trim().lowercase())
        if (existing != null) {
            return Result.failure(Exception("An account with this email already exists."))
        }
        val newUser = UserEntity(
            id = "user_${UUID.randomUUID()}",
            name = name.trim(),
            email = email.trim().lowercase(),
            passwordHash = hashPassword(password),
            role = role.uppercase(),
            createdAt = System.currentTimeMillis()
        )
        userDao.insertUser(newUser)
        return Result.success(newUser)
    }

    suspend fun insertUser(user: UserEntity) {
        userDao.insertUser(user)
    }

    suspend fun loginUser(email: String, password: String): Result<UserEntity> {
        val user = userDao.getUserByEmail(email.trim().lowercase())
            ?: return Result.failure(Exception("No account found with this email."))
        if (user.passwordHash != hashPassword(password)) {
            return Result.failure(Exception("Incorrect password. Please try again."))
        }
        return Result.success(user)
    }

    suspend fun updateUserProfile(user: UserEntity) {
        userDao.updateUser(user)
    }

    suspend fun toggleUserRole(userId: String) {
        val user = userDao.getUserById(userId) ?: return
        val newRole = if (user.role == "ADMIN") "USER" else "ADMIN"
        userDao.updateUser(user.copy(role = newRole))
    }

    suspend fun deleteUser(userId: String) {
        userDao.deleteUser(userId)
    }

    // --- Emergency Guides Operations (Database-driven) ---
    fun getGuidesFlow(): Flow<List<EmergencyCategory>> = guideDao.getAllGuides().map { list ->
        list.map { entity ->
            EmergencyCategory(
                id = entity.id,
                title = entity.title,
                filipinoTitle = entity.filipinoTitle,
                summary = entity.summary,
                iconName = entity.id,
                agencyInCharge = entity.agencyInCharge,
                alertLevelsInfo = entity.alertLevelsInfo.ifBlank { null },
                whatToDoBefore = entity.whatToDoBefore.split("\n").filter { it.isNotBlank() },
                whatToDoDuring = entity.whatToDoDuring.split("\n").filter { it.isNotBlank() },
                whatToDoAfter = entity.whatToDoAfter.split("\n").filter { it.isNotBlank() },
                whatNotToDo = entity.whatNotToDo.split("\n").filter { it.isNotBlank() },
                safetyTips = entity.safetyTips.split("\n").filter { it.isNotBlank() },
                whatToPrepare = entity.whatToPrepare.split("\n").filter { it.isNotBlank() },
                whenToCallServices = entity.whenToCallServices.split("\n").filter { it.isNotBlank() }
            )
        }
    }

    suspend fun saveGuide(guide: EmergencyCategory) {
        val entity = EmergencyGuideEntity(
            id = guide.id,
            title = guide.title,
            filipinoTitle = guide.filipinoTitle,
            summary = guide.summary,
            agencyInCharge = guide.agencyInCharge,
            alertLevelsInfo = guide.alertLevelsInfo ?: "",
            whatToDoBefore = guide.whatToDoBefore.joinToString("\n"),
            whatToDoDuring = guide.whatToDoDuring.joinToString("\n"),
            whatToDoAfter = guide.whatToDoAfter.joinToString("\n"),
            whatNotToDo = guide.whatNotToDo.joinToString("\n"),
            safetyTips = guide.safetyTips.joinToString("\n"),
            whatToPrepare = guide.whatToPrepare.joinToString("\n"),
            whenToCallServices = guide.whenToCallServices.joinToString("\n"),
            updatedAt = System.currentTimeMillis()
        )
        guideDao.insertGuide(entity)
    }

    suspend fun deleteGuide(id: String) {
        guideDao.deleteGuide(id)
    }

    // --- Emergency Contacts Operations ---
    fun getContactsFlow(): Flow<List<EmergencyContact>> = contactDao.getAllContacts().map { list ->
        list.map { entity ->
            EmergencyContact(
                id = entity.id,
                agencyName = entity.agencyName,
                acronym = entity.acronym,
                primaryNumber = entity.primaryNumber,
                alternateNumbers = entity.alternateNumbers.split(",").map { it.trim() }.filter { it.isNotBlank() },
                description = entity.description,
                isNationalPriority = entity.isNationalPriority
            )
        }
    }

    suspend fun saveContact(contact: EmergencyContact) {
        val entity = EmergencyContactEntity(
            id = contact.id,
            agencyName = contact.agencyName,
            acronym = contact.acronym,
            primaryNumber = contact.primaryNumber,
            alternateNumbers = contact.alternateNumbers.joinToString(", "),
            description = contact.description,
            category = contact.category.name,
            isNationalPriority = contact.isNationalPriority,
            updatedAt = System.currentTimeMillis()
        )
        contactDao.insertContact(entity)
    }

    suspend fun deleteContact(id: String) {
        contactDao.deleteContact(id)
    }

    // --- Regional Contacts Operations ---
    fun getRegionalContactsFlow(): Flow<List<PhilippineRegion>> = regionalDao.getAllRegionalContacts().map { list ->
        list.map { entity ->
            PhilippineRegion(
                code = entity.code,
                name = entity.name,
                fullName = entity.fullName,
                rdrrmcHotline = entity.rdrrmcHotline,
                altHotline = entity.altHotline,
                policeHotline = entity.policeHotline,
                fireHotline = entity.fireHotline,
                regionalOffice = entity.regionalOffice
            )
        }
    }

    suspend fun updateRegionalContact(region: PhilippineRegion) {
        val entity = RegionalContactEntity(
            code = region.code,
            name = region.name,
            fullName = region.fullName,
            rdrrmcHotline = region.rdrrmcHotline,
            altHotline = region.altHotline,
            policeHotline = region.policeHotline,
            fireHotline = region.fireHotline,
            regionalOffice = region.regionalOffice,
            updatedAt = System.currentTimeMillis()
        )
        regionalDao.updateRegionalContact(entity)
    }

    // --- Announcements Operations ---
    fun getAnnouncementsFlow(): Flow<List<AnnouncementEntity>> = announcementDao.getAllAnnouncements()

    suspend fun saveAnnouncement(announcement: AnnouncementEntity) {
        announcementDao.insertAnnouncement(announcement)
    }

    suspend fun deleteAnnouncement(id: String) {
        announcementDao.deleteAnnouncement(id)
    }

    // --- Feedback Operations ---
    fun getFeedbackFlow(): Flow<List<FeedbackEntity>> = feedbackDao.getAllFeedback()

    suspend fun submitFeedback(userId: String, userName: String, userEmail: String, disasterTopic: String, rating: Int, comments: String) {
        val feedback = FeedbackEntity(
            id = "fb_${UUID.randomUUID()}",
            userId = userId,
            userName = userName,
            userEmail = userEmail,
            disasterTopic = disasterTopic,
            rating = rating,
            comments = comments,
            timestamp = System.currentTimeMillis()
        )
        feedbackDao.insertFeedback(feedback)
    }

    suspend fun updateFeedbackStatus(id: String, status: String) {
        feedbackDao.updateFeedbackStatus(id, status)
    }

    suspend fun deleteFeedback(id: String) {
        feedbackDao.deleteFeedback(id)
    }

    // --- Checklist Operations ---
    fun getUserChecklistFlow(userId: String): Flow<List<ChecklistItem>> = checklistDao.getChecklistForUser(userId).map { list ->
        if (list.isEmpty()) {
            DisasterRepository.defaultChecklist
        } else {
            list.map { entity ->
                ChecklistItem(
                    id = entity.id,
                    name = entity.name,
                    category = entity.category,
                    description = entity.description,
                    isChecked = entity.isChecked
                )
            }
        }
    }

    suspend fun initializeChecklistForUser(userId: String) {
        val existing = checklistDao.getChecklistForUser(userId).first()
        if (existing.isEmpty()) {
            val entities = DisasterRepository.defaultChecklist.map { item ->
                ChecklistEntity(
                    id = item.id,
                    userId = userId,
                    name = item.name,
                    category = item.category,
                    description = item.description,
                    isChecked = false
                )
            }
            checklistDao.insertChecklist(entities)
        }
    }

    suspend fun toggleChecklistItem(userId: String, itemId: String, currentChecked: Boolean) {
        checklistDao.updateChecklistItem(
            ChecklistEntity(
                id = itemId,
                userId = userId,
                name = "",
                category = "",
                description = "",
                isChecked = !currentChecked
            )
        )
    }

    // --- Real-Time Disaster Alerts & Incidents Operations ---
    fun getAllAlertsFlow(): Flow<List<DisasterAlertEntity>> = alertDao.getAllAlerts()
    fun getActiveAlertsFlow(): Flow<List<DisasterAlertEntity>> = alertDao.getActiveAlerts()
    fun getUnreadAlertCountFlow(): Flow<Int> = alertDao.getUnreadAlertCount()

    suspend fun saveAlert(alert: DisasterAlertEntity) {
        alertDao.insertAlert(alert)
    }

    suspend fun markAlertAsRead(id: String) {
        alertDao.markAsRead(id)
    }

    suspend fun markAllAlertsAsRead() {
        alertDao.markAllAsRead()
    }

    suspend fun setAlertArchived(id: String, isArchived: Boolean) {
        alertDao.setArchived(id, isArchived)
    }

    suspend fun deleteAlert(id: String) {
        alertDao.deleteAlert(id)
    }

    // Password Hashing helper (SHA-256)
    private fun hashPassword(password: String): String {
        val bytes = MessageDigest.getInstance("SHA-256").digest(password.toByteArray())
        return bytes.joinToString("") { "%02x".format(it) }
    }
}
