package com.example.data.firebase

import android.content.Context
import com.example.R
import com.google.firebase.Firebase
import com.google.firebase.auth.auth
import com.google.firebase.firestore.FieldValue
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.snapshots
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.catch
import kotlinx.coroutines.flow.emitAll
import kotlinx.coroutines.flow.flow
import kotlinx.coroutines.flow.map
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.firestore.Query
import kotlinx.coroutines.tasks.await
import java.util.UUID

class ReadyAiFirestoreRepository(
    private val db: FirebaseFirestore,
    private val auth: FirebaseAuth = Firebase.auth
) {

    constructor(context: Context) : this(
        FirebaseFirestore.getInstance(
            context.applicationContext.getString(R.string.firestore_database_id)
        ),
        Firebase.auth
    )

    private fun requireUserId(): String {
        return auth.currentUser?.uid
            ?: throw IllegalStateException("User must be signed in with Google before accessing Firestore.")
    }

    // --- USER PROFILE ---

    fun observeUserProfile(userId: String): Flow<FirestoreUserProfile?> = flow {
        val path = "users/$userId"
        emitAll(
            db.collection("users").document(userId)
                .snapshots()
                .map { snapshot ->
                    if (snapshot.exists()) snapshot.toObject(FirestoreUserProfile::class.java) else null
                }
                .catch { error ->
                    if (error is Exception) handleFirestoreError(error, OperationType.GET, path)
                    throw error
                }
        )
    }

    suspend fun saveUserProfile(profile: FirestoreUserProfile): Result<Unit> {
        val uid = requireUserId()
        val docRef = db.collection("users").document(uid)
        return try {
            val exists = docRef.get().await().exists()
            val payload = mutableMapOf<String, Any>(
                "userId" to uid,
                "email" to profile.email,
                "displayName" to profile.displayName,
                "updatedAt" to FieldValue.serverTimestamp()
            )
            profile.phone?.let { payload["phone"] = it }
            profile.bloodType?.let { payload["bloodType"] = it }
            profile.allergies?.let { payload["allergies"] = it }
            profile.emergencyNotes?.let { payload["emergencyNotes"] = it }
            profile.regionCode?.let { payload["regionCode"] = it }

            if (!exists) {
                payload["createdAt"] = FieldValue.serverTimestamp()
            }
            docRef.set(payload, com.google.firebase.firestore.SetOptions.merge()).await()
            Result.success(Unit)
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.WRITE, docRef.path)
            Result.failure(e)
        }
    }

    // --- CHECKLIST ITEMS ---

    fun observeChecklistItems(userId: String): Flow<List<FirestoreChecklistItem>> = flow {
        val path = "users/$userId/checklist_items"
        emitAll(
            db.collection("users").document(userId).collection("checklist_items")
                .snapshots()
                .map { snapshot -> snapshot.toObjects(FirestoreChecklistItem::class.java) }
                .catch { error ->
                    if (error is Exception) handleFirestoreError(error, OperationType.LIST, path)
                    throw error
                }
        )
    }

    suspend fun saveChecklistItem(item: FirestoreChecklistItem): Result<String> {
        val uid = requireUserId()
        val itemId = if (item.id.isNotBlank()) item.id else UUID.randomUUID().toString()
        val docRef = db.collection("users").document(uid).collection("checklist_items").document(itemId)
        return try {
            val exists = docRef.get().await().exists()
            val payload = mutableMapOf<String, Any>(
                "id" to itemId,
                "userId" to uid,
                "title" to item.title,
                "category" to item.category,
                "isChecked" to item.isChecked,
                "updatedAt" to FieldValue.serverTimestamp()
            )
            item.description?.let { payload["description"] = it }

            if (!exists) {
                payload["createdAt"] = FieldValue.serverTimestamp()
            }
            docRef.set(payload, com.google.firebase.firestore.SetOptions.merge()).await()
            Result.success(itemId)
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.WRITE, docRef.path)
            Result.failure(e)
        }
    }

    suspend fun deleteChecklistItem(itemId: String): Result<Unit> {
        val uid = requireUserId()
        val docRef = db.collection("users").document(uid).collection("checklist_items").document(itemId)
        return try {
            docRef.delete().await()
            Result.success(Unit)
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.DELETE, docRef.path)
            Result.failure(e)
        }
    }

    // --- EMERGENCY CONTACTS ---

    fun observeEmergencyContacts(userId: String): Flow<List<FirestoreEmergencyContact>> = flow {
        val path = "users/$userId/contacts"
        emitAll(
            db.collection("users").document(userId).collection("contacts")
                .snapshots()
                .map { snapshot -> snapshot.toObjects(FirestoreEmergencyContact::class.java) }
                .catch { error ->
                    if (error is Exception) handleFirestoreError(error, OperationType.LIST, path)
                    throw error
                }
        )
    }

    suspend fun saveEmergencyContact(contact: FirestoreEmergencyContact): Result<String> {
        val uid = requireUserId()
        val contactId = if (contact.id.isNotBlank()) contact.id else UUID.randomUUID().toString()
        val docRef = db.collection("users").document(uid).collection("contacts").document(contactId)
        return try {
            val exists = docRef.get().await().exists()
            val payload = mutableMapOf<String, Any>(
                "id" to contactId,
                "userId" to uid,
                "name" to contact.name,
                "phone" to contact.phone,
                "relationship" to contact.relationship,
                "updatedAt" to FieldValue.serverTimestamp()
            )
            if (!exists) {
                payload["createdAt"] = FieldValue.serverTimestamp()
            }
            docRef.set(payload, com.google.firebase.firestore.SetOptions.merge()).await()
            Result.success(contactId)
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.WRITE, docRef.path)
            Result.failure(e)
        }
    }

    suspend fun deleteEmergencyContact(contactId: String): Result<Unit> {
        val uid = requireUserId()
        val docRef = db.collection("users").document(uid).collection("contacts").document(contactId)
        return try {
            docRef.delete().await()
            Result.success(Unit)
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.DELETE, docRef.path)
            Result.failure(e)
        }
    }

    // --- FEEDBACK & INCIDENT REPORTS ---

    fun observeUserFeedback(userId: String): Flow<List<FirestoreFeedback>> = flow {
        val path = "feedback"
        emitAll(
            db.collection(path)
                .whereEqualTo("userId", userId)
                .snapshots()
                .map { snapshot -> snapshot.toObjects(FirestoreFeedback::class.java) }
                .catch { error ->
                    if (error is Exception) handleFirestoreError(error, OperationType.LIST, path)
                    throw error
                }
        )
    }

    suspend fun submitFeedback(feedback: FirestoreFeedback): Result<String> {
        val uid = requireUserId()
        val feedbackId = if (feedback.id.isNotBlank()) feedback.id else UUID.randomUUID().toString()
        val docRef = db.collection("feedback").document(feedbackId)
        return try {
            val payload = mapOf(
                "id" to feedbackId,
                "userId" to uid,
                "userName" to feedback.userName,
                "category" to feedback.category,
                "message" to feedback.message,
                "rating" to feedback.rating,
                "createdAt" to FieldValue.serverTimestamp()
            )
            docRef.set(payload).await()
            Result.success(feedbackId)
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.CREATE, docRef.path)
            Result.failure(e)
        }
    }

    // --- DISASTER ALERTS & BROADCASTS ---

    fun observeDisasterAlerts(): Flow<List<FirestoreDisasterAlert>> = flow {
        val path = "alerts"
        emitAll(
            db.collection(path)
                .orderBy("createdAt", Query.Direction.DESCENDING)
                .limit(50)
                .snapshots()
                .map { snapshot -> snapshot.toObjects(FirestoreDisasterAlert::class.java) }
                .catch { error ->
                    if (error is Exception) handleFirestoreError(error, OperationType.LIST, path)
                    throw error
                }
        )
    }

    suspend fun publishDisasterAlert(alert: FirestoreDisasterAlert): Result<String> {
        val uid = requireUserId()
        val alertId = if (alert.id.isNotBlank()) alert.id else UUID.randomUUID().toString()
        val docRef = db.collection("alerts").document(alertId)
        return try {
            val payload = mutableMapOf<String, Any>(
                "id" to alertId,
                "userId" to uid,
                "title" to alert.title,
                "category" to alert.category,
                "severity" to alert.severity,
                "message" to alert.message,
                "locationCity" to alert.locationCity,
                "createdAt" to FieldValue.serverTimestamp()
            )
            alert.sourceAgency?.let { payload["sourceAgency"] = it }
            if (alert.isTest) {
                payload["isTest"] = true
            }
            docRef.set(payload).await()
            Result.success(alertId)
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.CREATE, docRef.path)
            Result.failure(e)
        }
    }
}
