package com.example.data.local

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Update
import kotlinx.coroutines.flow.Flow

@Dao
interface UserDao {
    @Query("SELECT * FROM users ORDER BY createdAt DESC")
    fun getAllUsers(): Flow<List<UserEntity>>

    @Query("SELECT * FROM users WHERE email = :email LIMIT 1")
    suspend fun getUserByEmail(email: String): UserEntity?

    @Query("SELECT * FROM users WHERE id = :id LIMIT 1")
    suspend fun getUserById(id: String): UserEntity?

    @Query("SELECT COUNT(*) FROM users")
    fun getUserCount(): Flow<Int>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertUser(user: UserEntity)

    @Update
    suspend fun updateUser(user: UserEntity)

    @Query("DELETE FROM users WHERE id = :id")
    suspend fun deleteUser(id: String)
}

@Dao
interface EmergencyGuideDao {
    @Query("SELECT * FROM emergency_guides ORDER BY title ASC")
    fun getAllGuides(): Flow<List<EmergencyGuideEntity>>

    @Query("SELECT * FROM emergency_guides WHERE id = :id LIMIT 1")
    suspend fun getGuideById(id: String): EmergencyGuideEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertGuide(guide: EmergencyGuideEntity)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertAllGuides(guides: List<EmergencyGuideEntity>)

    @Update
    suspend fun updateGuide(guide: EmergencyGuideEntity)

    @Query("DELETE FROM emergency_guides WHERE id = :id")
    suspend fun deleteGuide(id: String)
}

@Dao
interface EmergencyContactDao {
    @Query("SELECT * FROM emergency_contacts ORDER BY isNationalPriority DESC, agencyName ASC")
    fun getAllContacts(): Flow<List<EmergencyContactEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertContact(contact: EmergencyContactEntity)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertAllContacts(contacts: List<EmergencyContactEntity>)

    @Update
    suspend fun updateContact(contact: EmergencyContactEntity)

    @Query("DELETE FROM emergency_contacts WHERE id = :id")
    suspend fun deleteContact(id: String)
}

@Dao
interface RegionalContactDao {
    @Query("SELECT * FROM regional_contacts ORDER BY code ASC")
    fun getAllRegionalContacts(): Flow<List<RegionalContactEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertAllRegionalContacts(contacts: List<RegionalContactEntity>)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertRegionalContact(contact: RegionalContactEntity)

    @Update
    suspend fun updateRegionalContact(contact: RegionalContactEntity)
}

@Dao
interface AnnouncementDao {
    @Query("SELECT * FROM announcements ORDER BY timestamp DESC")
    fun getAllAnnouncements(): Flow<List<AnnouncementEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertAnnouncement(announcement: AnnouncementEntity)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertAllAnnouncements(announcements: List<AnnouncementEntity>)

    @Update
    suspend fun updateAnnouncement(announcement: AnnouncementEntity)

    @Query("DELETE FROM announcements WHERE id = :id")
    suspend fun deleteAnnouncement(id: String)
}

@Dao
interface ChecklistDao {
    @Query("SELECT * FROM user_checklist WHERE userId = :userId")
    fun getChecklistForUser(userId: String): Flow<List<ChecklistEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertChecklist(items: List<ChecklistEntity>)

    @Update
    suspend fun updateChecklistItem(item: ChecklistEntity)

    @Query("DELETE FROM user_checklist WHERE userId = :userId")
    suspend fun deleteChecklistForUser(userId: String)
}

@Dao
interface FeedbackDao {
    @Query("SELECT * FROM user_feedback ORDER BY timestamp DESC")
    fun getAllFeedback(): Flow<List<FeedbackEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertFeedback(feedback: FeedbackEntity)

    @Query("UPDATE user_feedback SET status = :status WHERE id = :id")
    suspend fun updateFeedbackStatus(id: String, status: String)

    @Query("DELETE FROM user_feedback WHERE id = :id")
    suspend fun deleteFeedback(id: String)
}

@Dao
interface DisasterAlertDao {
    @Query("SELECT * FROM disaster_alerts ORDER BY incidentTime DESC")
    fun getAllAlerts(): Flow<List<DisasterAlertEntity>>

    @Query("SELECT * FROM disaster_alerts WHERE isArchived = 0 ORDER BY incidentTime DESC")
    fun getActiveAlerts(): Flow<List<DisasterAlertEntity>>

    @Query("SELECT COUNT(*) FROM disaster_alerts WHERE isRead = 0 AND isArchived = 0")
    fun getUnreadAlertCount(): Flow<Int>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertAlert(alert: DisasterAlertEntity)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertAllAlerts(alerts: List<DisasterAlertEntity>)

    @Update
    suspend fun updateAlert(alert: DisasterAlertEntity)

    @Query("UPDATE disaster_alerts SET isRead = 1 WHERE id = :id")
    suspend fun markAsRead(id: String)

    @Query("UPDATE disaster_alerts SET isRead = 1")
    suspend fun markAllAsRead()

    @Query("UPDATE disaster_alerts SET isArchived = :isArchived WHERE id = :id")
    suspend fun setArchived(id: String, isArchived: Boolean)

    @Query("DELETE FROM disaster_alerts WHERE id = :id")
    suspend fun deleteAlert(id: String)
}

