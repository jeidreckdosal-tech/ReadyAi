package com.example.data

import com.example.data.model.ChecklistItem
import com.example.data.model.ContactCategory
import com.example.data.model.EmergencyCategory
import com.example.data.model.EmergencyContact
import com.example.data.model.PhilippineRegion

object DisasterRepository {

    val categories: List<EmergencyCategory> = listOf(
        EmergencyCategory(
            id = "typhoon",
            title = "Typhoon",
            filipinoTitle = "Bagyo",
            summary = "Tropical cyclones bringing violent winds, heavy torrential rain, and storm surges.",
            iconName = "cyclone",
            agencyInCharge = "PAGASA (Philippine Atmospheric, Geophysical and Astronomical Services Administration)",
            alertLevelsInfo = "Tropical Cyclone Wind Signals 1 to 5 (Signal 1: 39-61 km/h up to Signal 5: >185 km/h Super Typhoon)",
            whatToDoBefore = listOf(
                "Secure loose roof sheets, trim overhanging tree branches, and clear gutters.",
                "Pack your 72-hour Go Bag (water, food, flashlight, power banks, medicines).",
                "Heed early local government (LGU) pre-emptive evacuation warnings if living near shores, rivers, or hillsides.",
                "Charge all mobile phones, power banks, and emergency flashlights.",
                "Stock up on at least 3 to 5 days of drinking water and ready-to-eat food."
            ),
            whatToDoDuring = listOf(
                "Stay indoors away from glass windows and open verandas.",
                "Turn off the main electrical switch and LPG regulator if floodwaters start entering.",
                "Monitor PAGASA weather bulletins via battery-powered AM/FM radio or mobile broadcasts.",
                "Beware of the 'Eye of the Typhoon': Calmer winds indicate you are in the eye; violent winds will resume from the opposite direction soon.",
                "If roof collapses or structure weakens, take cover under a sturdy table or move to an interior bathroom."
            ),
            whatToDoAfter = listOf(
                "Do not return to damaged structures until cleared by barangay or local DRRMO.",
                "Inspect house for broken electric wires, gas leaks, and cracked structural walls.",
                "Do not wade in leftover floodwaters without boots due to leptospirosis risk.",
                "Boil drinking water or use water purification tablets until tap water is officially certified safe.",
                "Help neighbors, children, elderly, and persons with disabilities."
            ),
            whatNotToDo = listOf(
                "DO NOT go outside during the lull of the 'Eye of the Storm'.",
                "DO NOT touch fallen electric posts or submerged power lines.",
                "DO NOT spread unverified rumors or panic on social media.",
                "DO NOT drive through flooded roads — just 6 inches of water can stall a car, and 12 inches can sweep it away."
            ),
            safetyTips = listOf(
                "Know your barangay's designated evacuation center and designated routes.",
                "Keep emergency cash in small denominations sealed in waterproof plastic.",
                "Save local CDRRMO / MDRRMO hotlines on your phone before the storm hits."
            ),
            whatToPrepare = listOf(
                "Heavy-duty waterproof flashlight and spare batteries",
                "Bottled drinking water (1 gallon/person/day for 3 days)",
                "Non-perishable ready-to-eat canned goods (with pull-tabs)",
                "Emergency whistle for signaling",
                "Portable power bank with phone cables",
                "First aid kit and maintenance medicines"
            ),
            whenToCallServices = listOf(
                "When family members are trapped in rising floodwaters or collapsed roofs.",
                "When electrical sparks or live wires are touching water near human presence.",
                "When someone is severely injured, hypothermic, or in medical distress.",
                "Call 911 or your local City/Municipal DRRMO immediately."
            )
        ),

        EmergencyCategory(
            id = "flood",
            title = "Flood",
            filipinoTitle = "Baha",
            summary = "Rising waters caused by excessive monsoon rains, storm surges, or overflowing river basins.",
            iconName = "water",
            agencyInCharge = "MMDA / PAGASA / Local DRRMO",
            alertLevelsInfo = "Rainfall Warnings: Yellow (Monitor/Be Alert), Orange (Prepare for Evacuation), Red (Mandatory Evacuation)",
            whatToDoBefore = listOf(
                "Familiarize yourself with flood-prone areas in your community.",
                "Elevate furniture, essential appliances, and electrical outlets.",
                "Put important personal documents (birth certs, land titles, IDs) in waterproof sealed pouches.",
                "Prepare evacuation route to higher ground or assigned public shelter."
            ),
            whatToDoDuring = listOf(
                "Switch off main circuit breaker before water reaches electrical sockets.",
                "Evacuate to upper floors or designated evacuation centers immediately before roads become impassable.",
                "Keep children away from drains, manholes, and swollen drainage canals.",
                "Wear rubber boots or protective clothing if you must wade through shallow water."
            ),
            whatToDoAfter = listOf(
                "Do not turn on electrical appliances until inspected and dried by a certified electrician.",
                "Wash hands thoroughly with soap and clean water after contact with floodwaters.",
                "Disinfect all surfaces that came into contact with floodwaters.",
                "Consult a doctor or health center for Leptospirosis prophylaxis (e.g. Doxycycline) if you waded through floods."
            ),
            whatNotToDo = listOf(
                "DO NOT allow children to swim or play in floodwaters.",
                "DO NOT consume open food or drink water that was submerged in floodwater.",
                "DO NOT attempt to cross flowing streams or submerged bridges on foot or by vehicle.",
                "DO NOT plug in wet electrical appliances."
            ),
            safetyTips = listOf(
                "Watch out for open manholes and washed-away drainage covers.",
                "Be vigilant for snakes, insects, and rodents seeking high ground inside houses.",
                "Store tap water in covered containers ahead of time because water service may be shut off."
            ),
            whatToPrepare = listOf(
                "Tall rubber boots and rain gear",
                "Doxycycline or prophylactic medication prescribed by local health workers",
                "Waterproof flashlight and battery-powered radio",
                "Inflatable lifesavers or life vests if living near riverbanks",
                "Water purification tablets or chlorine drops"
            ),
            whenToCallServices = listOf(
                "When floodwaters are rising rapidly cut off your exit paths to safety.",
                "When children, elderly, or sick family members cannot evacuate without rescue boats.",
                "When live electrical wires fall into the water.",
                "Call 911, Philippine Coast Guard (PCG), or Red Cross 143."
            )
        ),

        EmergencyCategory(
            id = "earthquake",
            title = "Earthquake",
            filipinoTitle = "Lindol",
            summary = "Sudden violent shaking of the ground caused by geological fault slip or volcanic activity.",
            iconName = "earthquake",
            agencyInCharge = "PHIVOLCS (Philippine Institute of Volcanology and Seismology)",
            alertLevelsInfo = "PHIVOLCS Earthquake Intensity Scale (PEIS) from Intensity I (Scarcely Perceptible) to Intensity X (Completely Devastating)",
            whatToDoBefore = listOf(
                "Identify safe spots in each room: under sturdy tables or against interior walls.",
                "Anchor heavy furniture, bookcases, and wall-mounted appliances securely.",
                "Store breakables, glass, and heavy objects on low shelves.",
                "Participate in nationwide simultaneous earthquake drills (NSED)."
            ),
            whatToDoDuring = listOf(
                "DROP to your hands and knees.",
                "COVER your head and neck under a sturdy table or desk.",
                "HOLD ON to your shelter until the shaking stops completely.",
                "If outdoors, move to an open area clear of buildings, power lines, and billboards.",
                "If driving, safely pull over away from overpasses and flyovers, stay inside with seatbelt on."
            ),
            whatToDoAfter = listOf(
                "Expect aftershocks. Be prepared to Drop, Cover, and Hold again.",
                "Evacuate the building calmly using stairs — NEVER use elevators.",
                "Check yourself and others for injuries; administer first aid.",
                "Check for gas leaks (smell of LPG) and turn off valve immediately.",
                "If near the sea and shaking was strong, evacuate inland to high ground immediately (tsunami risk)."
            ),
            whatNotToDo = listOf(
                "DO NOT panic or run while ground is shaking.",
                "DO NOT rush to exits or crowd stairwells during the quake.",
                "DO NOT light matches, candles, or turn on electric switches until sure there are no gas leaks.",
                "DO NOT enter severely cracked or compromised buildings."
            ),
            safetyTips = listOf(
                "Keep shoes or sturdy slippers beside your bed to avoid stepping on broken glass in the dark.",
                "Know where the master water valve and main electrical breaker are located.",
                "Designate an emergency family reunion point outside your neighborhood."
            ),
            whatToPrepare = listOf(
                "Hard hat or heavy cushion for head protection",
                "Dust masks (to prevent inhaling pulverized concrete or dust)",
                "Sturdy work gloves",
                "Emergency whistle (essential for search and rescue teams to locate you)",
                "Compact crowbar or multi-tool",
                "First aid kit with sterile bandages and splints"
            ),
            whenToCallServices = listOf(
                "When someone is trapped under heavy debris or structural collapse.",
                "When fire breaks out following the earthquake.",
                "When there is an active gas leak or chemical hazard.",
                "Call 911, BFP, or local Search and Rescue (SAR) units."
            )
        ),

        EmergencyCategory(
            id = "fire",
            title = "Fire",
            filipinoTitle = "Sunog",
            summary = "Rapidly spreading residential, commercial, or forest fires with high risk of smoke inhalation and heat burns.",
            iconName = "fire",
            agencyInCharge = "BFP (Bureau of Fire Protection)",
            alertLevelsInfo = "BFP Fire Alarms: 1st Alarm up to 5th Alarm, Task Force Alpha, Bravo, Charlie, and General Alarm",
            whatToDoBefore = listOf(
                "Install smoke detectors and check batteries regularly.",
                "Keep a certified ABC dry chemical fire extinguisher on every floor, especially near the kitchen.",
                "Establish and practice two emergency escape exits from every room.",
                "Inspect electrical cords, avoid octopus connections, and store flammable liquids safely."
            ),
            whatToDoDuring = listOf(
                "Shout 'SUNOG!' to alert all occupants in the house and nearby neighbors.",
                "CRAWL LOW under the smoke where the air is cleaner and cooler.",
                "Before opening any door, feel the doorknob and wood with the back of your hand; if hot, DO NOT OPEN.",
                "If your clothes catch fire: STOP, DROP, and ROLL to extinguish flames.",
                "Get out of the building immediately and stay out."
            ),
            whatToDoAfter = listOf(
                "Once safe outside, immediately call BFP or 911.",
                "Never go back inside a burning or smoldering structure for pets or possessions.",
                "Report immediately to the incident commander or barangay officials so you are accounted for.",
                "Cool minor burns with cool (not icy) running water for 10-15 minutes."
            ),
            whatNotToDo = listOf(
                "DO NOT use water on electrical or cooking oil (grease) fires (smother oil fires with a metal lid or fire blanket).",
                "DO NOT use elevators during a fire evacuation.",
                "DO NOT waste precious seconds trying to gather valuables or clothes.",
                "DO NOT re-enter a burning building under any circumstances."
            ),
            safetyTips = listOf(
                "Always sleep with bedroom doors closed to slow down fire and toxic smoke progression.",
                "Keep windows free of permanently welded security grills, or ensure an emergency release latch exists.",
                "Teach children how to dial 911 and memorize their complete home address."
            ),
            whatToPrepare = listOf(
                "Dry chemical fire extinguisher (ABC rated)",
                "Fire blanket for the kitchen",
                "Emergency escape ladders for second-story rooms",
                "Wet towels to cover mouth and nose during smoke evacuation",
                "Flashlight to navigate through thick smoke"
            ),
            whenToCallServices = listOf(
                "Immediately upon spotting uncontrolled flames or smoke.",
                "When anyone is missing or suspected trapped inside.",
                "Call BFP Hotlines or 911 right away without delay."
            )
        ),

        EmergencyCategory(
            id = "landslide",
            title = "Landslide",
            filipinoTitle = "Pagguho ng Lupa",
            summary = "Downward sliding mass of earth, rocks, and mud triggered by torrential rains or seismic faulting.",
            iconName = "terrain",
            agencyInCharge = "MGB (Mines and Geosciences Bureau) / NDRRMC",
            alertLevelsInfo = "MGB Geohazard Maps (Low, Moderate, High, and Very High Susceptibility)",
            whatToDoBefore = listOf(
                "Check the MGB Geohazard Map for your municipality to know if your area is prone to landslides.",
                "Observe slopes for signs of movement: widening cracks on ground, tilted utility poles or trees.",
                "Notice changes in water drainage or sudden cloudiness in stream water.",
                "Evacuate voluntarily if living below or upon steep slopes during continuous days of monsoon rains."
            ),
            whatToDoDuring = listOf(
                "Listen for unusual sounds like trees cracking, boulders knocking, or faint rumblings.",
                "If caught inside a building with no time to escape, curl into a tight ball and protect your head.",
                "Move quickly away from the path of the slide to stable higher ground perpendicular to the flow."
            ),
            whatToDoAfter = listOf(
                "Stay away from the slide area; secondary collapses frequently occur.",
                "Check for injured or trapped persons around the perimeter without entering the slide zone directly.",
                "Alert neighbors and local barangay disaster committees.",
                "Watch out for flash floods or mudflows which often accompany landslides."
            ),
            whatNotToDo = listOf(
                "DO NOT build houses near the edges of steep cliffs or at the base of unstable ravines.",
                "DO NOT cross mudflow paths or damaged bridges.",
                "DO NOT ignore government pre-emptive evacuation advisories in mountain provinces."
            ),
            safetyTips = listOf(
                "Plant deep-rooted native trees and vegetation to stabilize topsoil on slopes.",
                "Avoid constructing excessive retaining walls without engineered weep holes for water drainage."
            ),
            whatToPrepare = listOf(
                "Grab-and-go emergency backpack with 3 days of essentials",
                "Loud whistle to signal rescuers if trapped",
                "Sturdy boots and rainwear",
                "High-intensity battery-powered lantern"
            ),
            whenToCallServices = listOf(
                "When a slide blocks vital access roads or cuts off communities.",
                "When people or vehicles are buried or missing.",
                "Call 911 or local Police / Military SAR units."
            )
        ),

        EmergencyCategory(
            id = "tsunami",
            title = "Tsunami",
            filipinoTitle = "Tsunami / Higanteng Alon",
            summary = "Series of giant sea waves triggered by undersea earthquakes or coastal volcanic collapses.",
            iconName = "tsunami",
            agencyInCharge = "PHIVOLCS Tsunami Early Warning System",
            alertLevelsInfo = "Tsunami Alert Levels: Alert 1 (Evaluate), Alert 2 (Stay away from beach), Alert 3 (Evacuate coastal areas)",
            whatToDoBefore = listOf(
                "Know the elevation of your coastal home and distance from the coastline.",
                "Identify evacuation routes leading to ground at least 30 meters (100 feet) above sea level or 1 km inland.",
                "Practice walking your tsunami evacuation route with your entire family."
            ),
            whatToDoDuring = listOf(
                "Natural Warning Signs: Strong earthquake, unusual rapid receding of sea water exposing the seafloor, or loud ocean roar.",
                "If you see the water recede or feel a strong quake on the coast: RUN IMMEDIATELY to high ground.",
                "Do NOT wait for official siren or text broadcast if you observe natural warning signs.",
                "Stay at high ground for several hours; tsunamis are a series of waves, and later waves are often much bigger."
            ),
            whatToDoAfter = listOf(
                "Do not return to coastal lowlands until PHIVOLCS or local DRRMO officially gives the 'All Clear'.",
                "Avoid debris-strewn floodwaters and destroyed ports.",
                "Help clean and salvage only when authorized by safety personnel."
            ),
            whatNotToDo = listOf(
                "DO NOT go to the shore to watch the tsunami or collect stranded fish.",
                "DO NOT stay in coastal structures or single-story beachfront houses.",
                "DO NOT return after the first wave; subsequent waves can arrive hours later."
            ),
            safetyTips = listOf(
                "If high ground is not accessible, climb to the roof or upper floors (3rd floor or higher) of a reinforced concrete building.",
                "If on a boat in deep water (>100 meters), stay offshore where tsunami waves pass harmlessly underneath."
            ),
            whatToPrepare = listOf(
                "Life jackets or buoyant devices for family members",
                "Waterproof bag with food, water, and first aid",
                "Emergency radio tuned to provincial alerts"
            ),
            whenToCallServices = listOf(
                "When individuals are washed into sea or stranded on debris.",
                "Call 911, Philippine Coast Guard (PCG), or Red Cross."
            )
        ),

        EmergencyCategory(
            id = "volcano",
            title = "Volcanic Eruption",
            filipinoTitle = "Pagsabog ng Bulkan",
            summary = "Explosive ejection of ash, pyroclastic flows, volcanic bombs, lava, and hazardous sulfur gases.",
            iconName = "volcano",
            agencyInCharge = "PHIVOLCS (Philippine Institute of Volcanology and Seismology)",
            alertLevelsInfo = "PHIVOLCS Volcano Alert Levels 0 (Normal) to 5 (Hazardous Eruption in Progress)",
            whatToDoBefore = listOf(
                "Know the Permanent Danger Zone (PDZ) boundary of active volcanoes (e.g. Mayon, Taal, Kanlaon, Bulusan).",
                "Store N95 particulate respirators or damp clean handkerchiefs for ashfall protection.",
                "Cover water storage cisterns and food supplies to prevent volcanic ash contamination.",
                "Follow pre-emptive evacuation orders if living inside the danger radius."
            ),
            whatToDoDuring = listOf(
                "Wear an N95 mask or damp cloth over your nose and mouth to prevent inhaling fine silicate ash.",
                "Protect eyes with safety goggles or eyeglasses; DO NOT wear contact lenses during ashfall.",
                "Stay indoors; close all doors, windows, and fireplace dampers.",
                "Keep pets and livestock indoors and provide clean, covered water.",
                "Listen to PHIVOLCS bulletins for updates on pyroclastic density currents (PDC) and wind direction."
            ),
            whatToDoAfter = listOf(
                "Clear roofs of accumulated volcanic ash promptly (heavy ash combined with rain causes roof collapse).",
                "Wear protective goggles, gloves, and masks when cleaning up ash.",
                "Avoid driving in heavy ashfall — ash clogs air filters and makes roads dangerously slick.",
                "Be vigilant against Lahar (volcanic mudflows) along river channels during rainstorms."
            ),
            whatNotToDo = listOf(
                "DO NOT enter the Permanent Danger Zone (PDZ) for sightseeing, farming, or photography.",
                "DO NOT rub your eyes if ash gets into them; flush with clean water instead.",
                "DO NOT turn on air conditioning units or intake fans while ash is in the air."
            ),
            safetyTips = listOf(
                "Seal window gaps and door thresholds with damp cloths or masking tape.",
                "Stock up on several spare N95 masks per family member.",
                "Rinse vegetables and fruits thoroughly before eating if grown in ashfall areas."
            ),
            whatToPrepare = listOf(
                "N95 particle masks or certified dust masks",
                "Airtight safety goggles (not vented)",
                "Long-sleeved shirts and long pants to prevent skin irritation",
                "Plastic sheeting and tape to seal windows and computer equipment",
                "Ample bottled drinking water"
            ),
            whenToCallServices = listOf(
                "When pyroclastic or lahar flows threaten to block your evacuation corridor.",
                "When someone suffers severe respiratory arrest or eye trauma.",
                "Call 911, PHIVOLCS, or Provincial DRRMO."
            )
        ),

        EmergencyCategory(
            id = "power_outage",
            title = "Power Outage",
            filipinoTitle = "Brownout / Blackout",
            summary = "Prolonged loss of electrical grid power following storms, equipment failures, or grid overload.",
            iconName = "power_off",
            agencyInCharge = "DOE / Meralco / Local Electric Cooperatives",
            alertLevelsInfo = "Grid Alerts: Yellow Alert (Low Reserves) and Red Alert (Insufficient Generation)",
            whatToDoBefore = listOf(
                "Keep rechargeable emergency LED lights and high-capacity power banks fully charged at all times.",
                "Have a battery-operated or hand-crank AM/FM radio ready for government announcements.",
                "Stock non-perishable food that does not require refrigeration or electric cooking.",
                "Keep an inventory of needed prescription drugs, especially those requiring refrigeration (prepare cooler and ice packs)."
            ),
            whatToDoDuring = listOf(
                "Unplug sensitive electronic devices and appliances (computers, TVs, refrigerators) to prevent damage from power surges when electricity returns.",
                "Keep refrigerator and freezer doors closed. An unopened refrigerator keeps food cold for 4 hours; a full freezer maintains temperature for 48 hours.",
                "Use battery-powered flashlights or glow sticks instead of wax candles to eliminate fire hazard.",
                "If using a fuel-powered generator, ONLY operate it OUTDOORS at least 20 feet away from windows and doors to prevent fatal carbon monoxide poisoning."
            ),
            whatToDoAfter = listOf(
                "Wait 10-15 minutes after power is restored before turning on heavy appliances one by one.",
                "Check food in refrigerator; discard meat, milk, or dairy that was exposed to temperatures above 4°C for over 2 hours.",
                "Recharge all emergency lamps, power banks, and backup batteries immediately."
            ),
            whatNotToDo = listOf(
                "DO NOT leave candles burning unattended or near bedsheets, curtains, and plastics.",
                "DO NOT run a gas generator inside a garage, porch, basement, or enclosed space.",
                "DO NOT touch sagging outdoor power cables or fallen transformers."
            ),
            safetyTips = listOf(
                "Keep a physical list of emergency hotlines written on paper in case phone battery dies.",
                "Know how to manually disengage electric gates and garage doors."
            ),
            whatToPrepare = listOf(
                "Multi-mode LED lantern and headlamps",
                "High-capacity 20,000+ mAh power bank",
                "Pack of AA and AAA alkaline batteries",
                "Insulated cooler box with reusable ice packs",
                "Non-electric manual can opener"
            ),
            whenToCallServices = listOf(
                "When fallen power cables are sparking on roads or water.",
                "When life-support medical equipment runs out of emergency battery reserve.",
                "Call 911, Meralco Hotlines (16211), or local electric cooperative."
            )
        )
    )

    val nationalContacts: List<EmergencyContact> = listOf(
        EmergencyContact(
            id = "hotline_911",
            agencyName = "National Emergency Hotline",
            acronym = "911",
            primaryNumber = "911",
            alternateNumbers = listOf("(02) 8925-9111"),
            description = "Central nationwide 24/7 dispatch for police, fire, ambulance, rescue, and disaster assistance across the Philippines.",
            category = ContactCategory.NATIONAL,
            isNationalPriority = true
        ),
        EmergencyContact(
            id = "pnp",
            agencyName = "Philippine National Police",
            acronym = "PNP",
            primaryNumber = "117",
            alternateNumbers = listOf("(02) 8722-0650", "0998-869-8888"),
            description = "National police service for law enforcement, crime response, civil protection, and emergency peace and order.",
            category = ContactCategory.POLICE_MILITARY,
            isNationalPriority = true
        ),
        EmergencyContact(
            id = "bfp",
            agencyName = "Bureau of Fire Protection",
            acronym = "BFP",
            primaryNumber = "(02) 8426-0219",
            alternateNumbers = listOf("(02) 8426-0246", "(02) 8426-3812"),
            description = "National fire prevention, fire suppression, emergency medical services, and structural rescue operations.",
            category = ContactCategory.FIRE_RESCUE,
            isNationalPriority = true
        ),
        EmergencyContact(
            id = "prc",
            agencyName = "Philippine Red Cross",
            acronym = "PRC",
            primaryNumber = "143",
            alternateNumbers = listOf("(02) 8790-2300", "(02) 8527-0000"),
            description = "Premier humanitarian organization providing disaster relief, emergency blood supply, ambulances, and rescue teams.",
            category = ContactCategory.MEDICAL_HEALTH,
            isNationalPriority = true
        ),
        EmergencyContact(
            id = "pcg",
            agencyName = "Philippine Coast Guard",
            acronym = "PCG",
            primaryNumber = "(02) 8527-8481",
            alternateNumbers = listOf("0917-724-3682", "0918-912-8238"),
            description = "Maritime search and rescue, flood disaster rubber boat evacuations, and port storm safety enforcement.",
            category = ContactCategory.DISASTER_WEATHER,
            isNationalPriority = true
        ),
        EmergencyContact(
            id = "pagasa",
            agencyName = "PAGASA Weather & Storm Updates",
            acronym = "PAGASA",
            primaryNumber = "(02) 8284-0800",
            alternateNumbers = listOf("(02) 8927-1335", "(02) 8928-2031"),
            description = "Official national weather forecasts, severe tropical cyclone bulletins, flood advisories, and storm surge warnings.",
            category = ContactCategory.DISASTER_WEATHER,
            isNationalPriority = true
        ),
        EmergencyContact(
            id = "phivolcs",
            agencyName = "PHIVOLCS (Earthquake & Volcano)",
            acronym = "PHIVOLCS",
            primaryNumber = "(02) 8426-1468",
            alternateNumbers = listOf("(02) 8926-2611", "0905-313-4077"),
            description = "National seismological institute monitoring earthquakes, active volcanoes, fault lines, and tsunami bulletins.",
            category = ContactCategory.DISASTER_WEATHER,
            isNationalPriority = true
        ),
        EmergencyContact(
            id = "ndrrmc",
            agencyName = "NDRRMC (National Disaster Risk Reduction)",
            acronym = "NDRRMC / OCD",
            primaryNumber = "(02) 8911-5061",
            alternateNumbers = listOf("(02) 8911-1406", "(02) 8912-5668"),
            description = "National disaster coordination, emergency operations center, and nationwide cellular broadcast alerts.",
            category = ContactCategory.DISASTER_WEATHER,
            isNationalPriority = true
        ),
        EmergencyContact(
            id = "doh",
            agencyName = "Department of Health Emergency Hotline",
            acronym = "DOH",
            primaryNumber = "(02) 8651-7800",
            alternateNumbers = listOf("1555", "(02) 8711-1001"),
            description = "National health emergency management, hospital coordination, disease outbreaks, and mental health crisis hotline.",
            category = ContactCategory.MEDICAL_HEALTH
        ),
        EmergencyContact(
            id = "mmda",
            agencyName = "MMDA Metro Manila Development Authority",
            acronym = "MMDA",
            primaryNumber = "136",
            alternateNumbers = listOf("(02) 8882-4151", "0960-911-6632"),
            description = "Metro Manila traffic control, flood control pumping stations, and road rescue operations in the capital region.",
            category = ContactCategory.NATIONAL
        )
    )

    val philippineRegions: List<PhilippineRegion> = listOf(
        PhilippineRegion(
            code = "NCR",
            name = "National Capital Region (NCR)",
            fullName = "Metro Manila (NCR)",
            rdrrmcHotline = "(02) 8421-1918",
            altHotline = "(02) 8911-5061",
            policeHotline = "(02) 8838-0099",
            fireHotline = "(02) 8728-6601",
            regionalOffice = "Office of Civil Defense - NCR Operations Center, Camp Aguinaldo, Quezon City"
        ),
        PhilippineRegion(
            code = "CAR",
            name = "Cordillera Administrative Region (CAR)",
            fullName = "Cordillera Administrative Region (CAR)",
            rdrrmcHotline = "(074) 444-5298",
            altHotline = "(074) 304-2256",
            policeHotline = "(074) 422-5418",
            fireHotline = "(074) 442-2222",
            regionalOffice = "OCD CAR Regional Operations Center, Baguio City"
        ),
        PhilippineRegion(
            code = "Region I",
            name = "Region I – Ilocos Region",
            fullName = "Ilocos Region (Region I)",
            rdrrmcHotline = "(072) 607-6528",
            altHotline = "(072) 700-4747",
            policeHotline = "(072) 607-6582",
            fireHotline = "(072) 888-2566",
            regionalOffice = "OCD Regional Center I, San Fernando City, La Union"
        ),
        PhilippineRegion(
            code = "Region II",
            name = "Region II – Cagayan Valley",
            fullName = "Cagayan Valley (Region II)",
            rdrrmcHotline = "(078) 304-1630",
            altHotline = "(078) 304-1631",
            policeHotline = "(078) 304-1729",
            fireHotline = "(078) 844-1111",
            regionalOffice = "OCD Regional Center II, Tuguegarao City, Cagayan"
        ),
        PhilippineRegion(
            code = "Region III",
            name = "Region III – Central Luzon",
            fullName = "Central Luzon (Region III)",
            rdrrmcHotline = "(045) 455-1526",
            altHotline = "(045) 455-0033",
            policeHotline = "(045) 860-2941",
            fireHotline = "(045) 961-2222",
            regionalOffice = "OCD Regional Center III, Diosdado Macapagal Govt Center, City of San Fernando, Pampanga"
        ),
        PhilippineRegion(
            code = "Region IV-A",
            name = "Region IV-A – CALABARZON",
            fullName = "CALABARZON (Region IV-A)",
            rdrrmcHotline = "(049) 531-7266",
            altHotline = "(049) 834-4244",
            policeHotline = "(049) 530-9856",
            fireHotline = "(049) 545-1234",
            regionalOffice = "OCD Regional Center IV-A, Camp Vicente Lim, Calamba City, Laguna"
        ),
        PhilippineRegion(
            code = "Region IV-B",
            name = "Region IV-B – MIMAROPA",
            fullName = "MIMAROPA (Region IV-B)",
            rdrrmcHotline = "(043) 723-4248",
            altHotline = "(02) 8911-1406",
            policeHotline = "(043) 288-2366",
            fireHotline = "(043) 288-7111",
            regionalOffice = "OCD MIMAROPA Regional Operations Center, Batangas / Calapan City"
        ),
        PhilippineRegion(
            code = "Region V",
            name = "Region V – Bicol Region",
            fullName = "Bicol Region (Region V)",
            rdrrmcHotline = "(052) 481-1656",
            altHotline = "(052) 742-1176",
            policeHotline = "(052) 480-8777",
            fireHotline = "(052) 480-1234",
            regionalOffice = "OCD Regional Center V, Camp General Simeon Ola, Legazpi City, Albay"
        ),
        PhilippineRegion(
            code = "Region VI",
            name = "Region VI – Western Visayas",
            fullName = "Western Visayas (Region VI)",
            rdrrmcHotline = "(033) 337-6671",
            altHotline = "(033) 336-9353",
            policeHotline = "(033) 337-9289",
            fireHotline = "(033) 337-4444",
            regionalOffice = "OCD Regional Center VI, Camp Martin Delgado, Iloilo City"
        ),
        PhilippineRegion(
            code = "Region VII",
            name = "Region VII – Central Visayas",
            fullName = "Central Visayas (Region VII)",
            rdrrmcHotline = "(032) 416-5025",
            altHotline = "(032) 253-8762",
            policeHotline = "(032) 253-5636",
            fireHotline = "(032) 256-0541",
            regionalOffice = "OCD Regional Center VII, Pier 3 Area, Cebu City"
        ),
        PhilippineRegion(
            code = "Region VIII",
            name = "Region VIII – Eastern Visayas",
            fullName = "Eastern Visayas (Region VIII)",
            rdrrmcHotline = "(053) 323-8453",
            altHotline = "(053) 323-4554",
            policeHotline = "(053) 325-5488",
            fireHotline = "(053) 321-2222",
            regionalOffice = "OCD Regional Center VIII, Miralles Building, Tacloban City, Leyte"
        ),
        PhilippineRegion(
            code = "Region IX",
            name = "Region IX – Zamboanga Peninsula",
            fullName = "Zamboanga Peninsula (Region IX)",
            rdrrmcHotline = "(062) 991-6869",
            altHotline = "(062) 991-6870",
            policeHotline = "(062) 991-3004",
            fireHotline = "(062) 991-1111",
            regionalOffice = "OCD Regional Center IX, Pagadian City / Zamboanga City"
        ),
        PhilippineRegion(
            code = "Region X",
            name = "Region X – Northern Mindanao",
            fullName = "Northern Mindanao (Region X)",
            rdrrmcHotline = "(088) 857-3988",
            altHotline = "(088) 857-3907",
            policeHotline = "(088) 856-4444",
            fireHotline = "(088) 857-2222",
            regionalOffice = "OCD Regional Center X, Camp Evangelista, Cagayan de Oro City"
        ),
        PhilippineRegion(
            code = "Region XI",
            name = "Region XI – Davao Region",
            fullName = "Davao Region (Region XI)",
            rdrrmcHotline = "(082) 297-7479",
            altHotline = "(082) 297-7497",
            policeHotline = "(082) 224-1313",
            fireHotline = "(082) 227-2222",
            regionalOffice = "OCD Regional Center XI, Camp Felix Apolinario, Panacan, Davao City"
        ),
        PhilippineRegion(
            code = "Region XII",
            name = "Region XII – SOCCSKSARGEN",
            fullName = "SOCCSKSARGEN (Region XII)",
            rdrrmcHotline = "(083) 552-9759",
            altHotline = "(083) 553-2994",
            policeHotline = "(083) 552-3200",
            fireHotline = "(083) 552-2222",
            regionalOffice = "OCD Regional Center XII, Koronadal City / General Santos City"
        ),
        PhilippineRegion(
            code = "Region XIII",
            name = "Region XIII – Caraga",
            fullName = "Caraga Administrative Region (Region XIII)",
            rdrrmcHotline = "(085) 342-8753",
            altHotline = "(085) 815-6345",
            policeHotline = "(085) 342-9988",
            fireHotline = "(085) 341-2222",
            regionalOffice = "OCD Regional Center XIII, Camp Rafael Rodriguez, Butuan City"
        ),
        PhilippineRegion(
            code = "BARMM",
            name = "BARMM – Bangsamoro Autonomous Region",
            fullName = "Bangsamoro Autonomous Region in Muslim Mindanao (BARMM)",
            rdrrmcHotline = "(064) 559-0010",
            altHotline = "(064) 421-1406",
            policeHotline = "(064) 421-2555",
            fireHotline = "(064) 421-2222",
            regionalOffice = "OCD BARMM / Bangsamoro READi Operations Center, Cotabato City"
        )
    )

    val defaultChecklist: List<ChecklistItem> = listOf(
        ChecklistItem(
            id = "item_water",
            name = "Drinking water",
            category = "Hydration & Sustenance",
            description = "At least 1 gallon (4 liters) per person per day for a minimum of 3 days."
        ),
        ChecklistItem(
            id = "item_food",
            name = "Food",
            category = "Hydration & Sustenance",
            description = "Non-perishable canned goods (sardines, corned beef, tuna), biscuits, and ready-to-eat energy bars."
        ),
        ChecklistItem(
            id = "item_flashlight",
            name = "Flashlight",
            category = "Lighting & Power",
            description = "Durable waterproof LED flashlight or rechargeable torch."
        ),
        ChecklistItem(
            id = "item_batteries",
            name = "Extra batteries",
            category = "Lighting & Power",
            description = "Assorted spare batteries (AA, AAA, D) sealed tightly inside a waterproof ziplock bag."
        ),
        ChecklistItem(
            id = "item_firstaid",
            name = "First-aid kit",
            category = "Health & Medical",
            description = "Sterile gauze pads, adhesive bandages, povidone-iodine antiseptic, medical tape, and scissors."
        ),
        ChecklistItem(
            id = "item_medicines",
            name = "Medicines",
            category = "Health & Medical",
            description = "7-day supply of personal maintenance medications, plus paracetamol, oral rehydration salts (ORS), and antidiarrheals."
        ),
        ChecklistItem(
            id = "item_powerbank",
            name = "Power bank",
            category = "Communication & Electronics",
            description = "Fully charged high-capacity power bank (10,000–20,000 mAh) with matching USB charging cables."
        ),
        ChecklistItem(
            id = "item_documents",
            name = "Important documents",
            category = "Protection & Records",
            description = "Birth certificates, passports, government IDs, insurance policies, and land titles sealed in a waterproof envelope."
        ),
        ChecklistItem(
            id = "item_whistle",
            name = "Whistle",
            category = "Signaling & Rescue",
            description = "High-decibel pea-less emergency whistle to signal search and rescue teams when trapped."
        ),
        ChecklistItem(
            id = "item_clothes",
            name = "Extra clothes",
            category = "Personal & Wearables",
            description = "Sturdy clothes, raincoat/poncho, extra underwear, thermal socks, and durable walking shoes."
        ),
        ChecklistItem(
            id = "item_hygiene",
            name = "Hygiene supplies",
            category = "Personal & Hygiene",
            description = "Antibacterial soap, 70% ethyl alcohol, sanitary pads, wet wipes, toothbrush/toothpaste, and N95/surgical face masks."
        )
    )
}
